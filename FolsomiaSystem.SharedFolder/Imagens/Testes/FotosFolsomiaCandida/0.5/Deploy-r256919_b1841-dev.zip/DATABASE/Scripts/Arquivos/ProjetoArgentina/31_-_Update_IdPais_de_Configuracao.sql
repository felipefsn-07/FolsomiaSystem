USE UniCad
GO

IF EXISTS(SELECT 1 FROM sys.columns WHERE [object_id] = OBJECT_ID('[DBO].[Configuracao]') AND NAME = 'IdPais')
	BEGIN 
		IF (SELECT COUNT(1) FROM [DBO].Configuracao WHERE IdPais IS NOT NULL) <= 0
			BEGIN
				UPDATE [DBO].Configuracao
				SET IdPais = 1
				WHERE IdPais IS NULL
			END
	END
GO