USE [UniCad]
GO

/****** Object:  View [dbo].[VW_Motorista]    Script Date: 07/10/2019 12:23:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT 1 FROM sys.views WHERE OBJECT_ID=OBJECT_ID('VW_Motorista'))
	DROP VIEW VW_Motorista;
GO


CREATE VIEW [dbo].[VW_Motorista]
AS
SELECT        dbo.Motorista.ID, dbo.Motorista.IDEmpresa, dbo.Motorista.IDStatus, dbo.Motorista.IDMotorista, dbo.Motorista.IDTransportadora, dbo.Motorista.Nome, dbo.Motorista.Operacao, dbo.Motorista.Telefone, dbo.Motorista.Email, 
                         dbo.Motorista.Anexo, dbo.Motorista.CodigoEasyQuery, dbo.Motorista.DataAtualizazao, dbo.Motorista.Ativo, dbo.Motorista.Observacao, dbo.Motorista.LoginUsuario, dbo.Motorista.Justificativa, dbo.Motorista.PIS, 
                         dbo.Motorista.UsuarioAlterouStatus, dbo.Motorista.IdPais, dbo.MotoristaArgentina.Apellido, dbo.MotoristaArgentina.CUITTransportista, dbo.MotoristaArgentina.DNI, dbo.MotoristaBrasil.CPF, dbo.MotoristaBrasil.RG, 
                         dbo.MotoristaBrasil.OrgaoEmissor, dbo.MotoristaBrasil.Nascimento, dbo.MotoristaBrasil.LocalNascimento, dbo.MotoristaBrasil.CNH, dbo.MotoristaBrasil.CategoriaCNH, dbo.MotoristaBrasil.OrgaoEmissorCNH
FROM            dbo.Motorista LEFT OUTER JOIN
                         dbo.MotoristaArgentina ON dbo.Motorista.ID = dbo.MotoristaArgentina.IDMotorista LEFT OUTER JOIN
                         dbo.MotoristaBrasil ON dbo.Motorista.ID = dbo.MotoristaBrasil.IDMotorista
GO

