USE UniCad
GO

/*
	Padroniza os dados para que tragam as informa��es preenchidas de maneira correta nos dropdowns
*/
-- Define como "Sem a��o" para todos os documentos que possu�rem o bloqueio autom�tico como "SemBloqueio = 2"
UPDATE	TD
SET		TD.TipoAcaoVencimento = 0
--SELECT	*
FROM	TipoDocumento TD
WHERE	TD.BloqueioImediato = 2
-- 24
GO

-- Define como "Bloqueio" para todos os documentos que j� existem na base, pois esta � a a��o padr�o e �nica existente hoje
UPDATE	TD
SET		TD.TipoAcaoVencimento = 1
--SELECT	*
FROM	TipoDocumento TD
WHERE	TD.BloqueioImediato <> 2
-- 62
GO

/*

SELECT	BloqueioImediato, IDTipoAcaoVencimento
FROM	TipoDocumento

*/



