IF OBJECT_ID('dbo.[FK_UsuarioCliente_Usuario]', 'F') IS NOT NULL 
    ALTER TABLE dbo.[UsuarioCliente] DROP CONSTRAINT FK_UsuarioCliente_Usuario
ALTER TABLE [dbo].[UsuarioCliente]  WITH CHECK ADD  CONSTRAINT [FK_UsuarioCliente_Usuario] FOREIGN KEY([IDUsuario])
REFERENCES [dbo].[Usuario] ([ID])
ON DELETE CASCADE		
GO
IF OBJECT_ID('dbo.[FK_UsuarioTransportadora_Usuario]', 'F') IS NOT NULL 
    ALTER TABLE dbo.[UsuarioTransportadora] DROP CONSTRAINT FK_UsuarioTransportadora_Usuario
ALTER TABLE [dbo].[UsuarioTransportadora]  WITH CHECK ADD  CONSTRAINT [FK_UsuarioTransportadora_Usuario] FOREIGN KEY([IDUsuario])
REFERENCES [dbo].[Usuario] ([ID])
ON DELETE CASCADE		
GO