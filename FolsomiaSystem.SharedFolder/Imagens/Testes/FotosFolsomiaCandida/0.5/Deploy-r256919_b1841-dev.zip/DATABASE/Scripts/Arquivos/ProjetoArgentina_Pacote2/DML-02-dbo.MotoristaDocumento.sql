﻿USE UniCad
GO

-- [CSON-2698 - Inicio]

IF COL_LENGTH('dbo.MotoristaDocumento', 'Processado') IS NOT NULL
	AND NOT EXISTS (SELECT * FROM dbo.MotoristaDocumento WHERE Processado <> 0)
BEGIN
	UPDATE MD
	SET Processado = 1
	FROM dbo.MotoristaDocumento AS MD
	JOIN dbo.TipoDocumento AS TD ON MD.IDTipoDocumento = TD.ID
	WHERE 
		MD.Processado = 0
		AND ((MD.Vencido = 1 AND MD.Bloqueado = 1) 
			OR (MD.Vencido = 1 AND TD.TipoAcaoVencimento = 0))
END

-- [CSON-2698 - Fim]
