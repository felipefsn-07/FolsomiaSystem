Use UniCad

GO

--UPDATE CORRETIVO PARA REPREENCHER OS PAIS DOS TIPOS DE PRODUTO 
UPDATE TipoProduto SET IdPais = 1 WHERE ID = 1
UPDATE TipoProduto SET IdPais = 1 WHERE ID = 2
UPDATE TipoProduto SET IdPais = 1 WHERE ID = 3
UPDATE TipoProduto SET IdPais = 1 WHERE ID = 4
UPDATE TipoProduto SET IdPais = 1 WHERE ID = 5
UPDATE TipoProduto SET IdPais = 2 WHERE ID = 6
UPDATE TipoProduto SET IdPais = 2 WHERE ID = 7
UPDATE TipoProduto SET IdPais = 2 WHERE ID = 8
UPDATE TipoProduto SET IdPais = 2 WHERE ID = 9
UPDATE TipoProduto SET IdPais = 2 WHERE ID = 10

