/***********************************************************
* 0) SELECAO DA BASE E CONFIGURACOES INICAIS
************************************************************/
USE [UniCad]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/***********************************************************
* 1) AJUSTE NA PROCEDURE
************************************************************/

--1.1) Verifica se ja existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Existe_Placa')
    DROP PROCEDURE [Proc_Existe_Placa];
GO

--1.2) Recriar a procedure ajustada
CREATE PROCEDURE  [dbo].[Proc_Existe_Placa]
	@STATUS INT,
	@IDComposicao INT,
	@PLACA VARCHAR(7),
	@OPERACAO VARCHAR(10)
AS
BEGIN
	SELECT COUNT(1) FROM VW_Placa P
	INNER JOIN Composicao C ON (C.IDPlaca1 = P.ID) 
							OR (C.IDPlaca2 = P.ID)
							OR (C.IDPlaca3 = P.ID)
							OR (C.IDPlaca4 = P.ID)
    WHERE C.IDStatus = @STATUS
    AND P.PlacaVeiculo = @PLACA
    AND C.ID <> @IDComposicao
    AND C.Operacao = @OPERACAO   
END
GO

