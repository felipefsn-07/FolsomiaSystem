USE UniCad
GO

/*
	Padroniza os dados para que tragam as informa��es preenchidas de maneira correta nos dropdowns
*/

-- Define como "Bloqueio" para todos os documentos que j� existem na base, pois esta � a a��o padr�o e �nica existente hoje
UPDATE	PD
SET		PD.TipoAcaoVencimento = 1
--SELECT	*
FROM	PlacaDocumento PD
WHERE	PD.Bloqueado = 1
-- 0
GO

UPDATE	PD
SET		PD.TipoAcaoVencimento = 0
--SELECT	*
FROM	PlacaDocumento PD
WHERE	PD.Bloqueado = 0
-- 634068
GO


