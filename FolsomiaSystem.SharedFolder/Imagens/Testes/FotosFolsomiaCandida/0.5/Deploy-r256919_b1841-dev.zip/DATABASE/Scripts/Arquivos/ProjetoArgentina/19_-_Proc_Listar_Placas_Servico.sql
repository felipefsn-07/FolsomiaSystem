/***********************************************************
* 0) SELEÇÃO DA BASE E CONFIGURAÇÕES INICAIS
************************************************************/
USE [UniCad]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/***********************************************************
* 1) AJUSTE NA PROCEDURE
************************************************************/

--1.1) Verifica se já existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Listar_Placas_Servico')
    DROP PROCEDURE [Proc_Listar_Placas_Servico];
GO

--1.2) Recriar a procedure ajustada
CREATE PROCEDURE [dbo].[Proc_Listar_Placas_Servico]
	@LinhaNegocio INT = NULL,
	@Operacao VARCHAR(5) = NULL,
	@Placa VARCHAR(7) = NULL,
	@IDPlaca INT = NULL
AS
BEGIN
DECLARE @StrSQL VARCHAR(8000)

SET @StrSQL = '
	SELECT 
		P.id, 
		P.PlacaVeiculo as Placa,
		A.IDEmpresa	AS LinhaNegocio,
		P.Operacao,
		P.IDTipoVeiculo AS Tipo,
		P.Tara, 
		P.NumeroEixos as NumEixos, 
		CASE 
			WHEN P.IDTipoVeiculo = 1 THEN NULL 
			ELSE P.IDTipoProduto END 
		AS TipoProduto,
		P.EixosPneusDuplos,
		P.NumeroEixosPneusDuplos AS NumEixosPneusDuplos,
		P.EixosDistanciados,
		P.NumeroEixosDistanciados AS NumEixosPneusDistanciados,
		P.IDTipoCarregamento AS Carregamento,
		P.MultiSeta,
		P.Renavam,
		P.Marca,
		P.Modelo,
		P.Chassi,
		P.AnoFabricacao,
		P.AnoModelo,
		P.Cor,
		P.TipoRastreador,
		P.NumeroAntena AS NumAntena,
		P.Versao,
		P.CameraMonitoramento,
		P.BombaDescarga,
		P.PossuiAbs,
		P.CPFCNPJ  AS CnpjCpfTransportadorCrlv,
		P.RazaoSocial AS RazaoSocialNomeTransportadoraCrlv,
		P.DataNascimento AS DataNascimentoTransportador,
		P.IDCategoriaVeiculo AS Categoria,
		E.Nome AS Estado,
		P.Cidade,
		P.Observacao,
		P.DataAtualizacao
	FROM VW_Placa P 
	LEFT JOIN Estado E ON P.IDEstado = E.ID '
	IF @IDPlaca IS NULL
	BEGIN
		SET @StrSQL +=
		'INNER JOIN
		(
			SELECT TOP 1 a.id, b.Operacao,b.idEmpresa, MAX(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(idstatus,2,-9),1,-8),5,-7),4,-6),6,-5)) AS Status  
			FROM VW_Placa a inner join Composicao b on a.id = b.IDPlaca1 OR a.id = b.IDPlaca2 OR a.id = b.IDPlaca3 OR a.id = b.IDPlaca4 
			WHERE  idstatus in (2,5,1) '
			IF (@LinhaNegocio IS NOT NULL)
				SET @StrSQL+= 'AND (B.IDEmpresa = ' +  CONVERT(VARCHAR(10),@LinhaNegocio) +') '
			IF (@Operacao IS NOT NULL)
				SET @StrSql += 'AND (B.Operacao = '''  + @Operacao + ''') '	
			IF (@Placa IS NOT NULL)
				SET @StrSql += 'AND (A.PlacaVeiculo = ''' + CONVERT(VARCHAR(7),@Placa) + ''') '
			IF (@IDPlaca IS NOT NULL)
				SET @StrSql += 'AND (A.ID = ' + CONVERT(VARCHAR(10),@IDPlaca) + ') '
			SET @StrSql += '
			GROUP BY a.id,PlacaVeiculo, b.Operacao, b.IDEmpresa, a.DataAtualizacao
			ORDER BY MAX(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(idstatus,2,-9),1,-8),5,-7),4,-6),6,-5)) DESC
		) A ON P.ID = A.ID'
	END 
	ELSE 
	BEGIN
		SET @StrSql +=
		'INNER JOIN Composicao A ON A.idplaca1 = P.id OR A.idplaca2 = P.id OR A.idplaca3 = P.id OR A.idplaca4 = P.id
		WHERE P.id = ' + CONVERT(VARCHAR(10),@idplaca) + ' AND A.IdEmpresa = ' +  CONVERT(VARCHAR(10),@LinhaNegocio) + 'AND (A.Operacao = '''  + @Operacao + ''') '	
	END
	EXEC (@StrSQL)
	--tirar
	print @StrSQL
END


