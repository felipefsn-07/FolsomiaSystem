USE UniCad
GO

IF NOT EXISTS (
		SELECT 1
		FROM SYS.COLUMNS
		WHERE NAME = 'UsuarioAlterouStatus'
			AND OBJECT_ID = OBJECT_ID('Composicao')
		)
BEGIN

	BEGIN TRANSACTION

	ALTER TABLE dbo.Composicao ADD
			UsuarioAlterouStatus varchar(50) NULL

	COMMIT

END