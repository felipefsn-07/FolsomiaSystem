USE [UniCad]
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE  [object_id] = OBJECT_ID('[dbo].[MotoristaArgentina]') AND NAME = 'Tarjeta')
BEGIN
	ALTER TABLE [dbo].[MotoristaArgentina]
		ADD Tarjeta VARCHAR(30) NULL
END