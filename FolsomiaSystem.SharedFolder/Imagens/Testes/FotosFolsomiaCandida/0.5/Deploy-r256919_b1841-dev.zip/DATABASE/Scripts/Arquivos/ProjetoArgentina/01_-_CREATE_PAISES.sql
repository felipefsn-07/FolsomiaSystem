/***********************************************************
* 0) SELECAO DO BD                           
************************************************************/
USE [UniCad]

GO

/***********************************************************
* 1) CREATE DE OBJETOS SQL
************************************************************/

--1.1) Criacao da tabela caso ela NAO EXISTA
IF NOT EXISTS (SELECT 1 FROM SYS.TABLES WHERE NAME = 'Pais')
BEGIN
CREATE TABLE [dbo].[Pais](
	[ID] [int] NOT NULL,
	[Nome] [varchar](100) NOT NULL,
	[Sigla] [varchar](2) NOT NULL,
	[Bandeira] [varchar](100) NOT NULL,
	[LinguagemPadrao] [varchar](5) NOT NULL,
	[StAtivo] [bit] NOT NULL

 CONSTRAINT [PK_Pais_ID] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY];


	INSERT INTO [dbo].[Pais]
           ([ID]
           ,[Nome]
           ,[Sigla]
           ,[Bandeira]
           ,[LinguagemPadrao]
           ,[StAtivo])
     VALUES
           (1
           ,'Brasil'
           ,'BR'
           ,'Path do arquivo da bandeira do Brasil'
           ,'PT-BR'
           ,1);

	INSERT INTO [dbo].[Pais]
           ([ID]
           ,[Nome]
           ,[Sigla]
           ,[Bandeira]
           ,[LinguagemPadrao]
           ,[StAtivo])
     VALUES
           (2
           ,'Argentina'
           ,'AR'
           ,'Path do arquivo da bandeira da Argentina'
           ,'ES-AR'
           ,1);

END

GO

--1.3) Criacao da coluna caso ela NAO EXISTA
IF COL_LENGTH('dbo.TipoComposicao', 'IdPais') IS NULL
BEGIN
    ALTER TABLE dbo.TipoComposicao ADD IdPais INT NULL;
END

GO

IF OBJECT_ID('dbo.[FK_TipoComposicao_Pais]') IS NULL 
BEGIN
	ALTER TABLE dbo.TipoComposicao ADD CONSTRAINT FK_TipoComposicao_Pais FOREIGN KEY (IdPais) REFERENCES Pais(id);
END

GO

IF COL_LENGTH('dbo.TipoComposicao', 'IdPais') IS NOT NULL
BEGIN
	IF ((SELECT COUNT(*) FROM dbo.TipoComposicao) <= 4)
		UPDATE dbo.TipoComposicao SET IdPais = 1;

	IF ((SELECT COUNT(*) FROM dbo.TipoComposicao WHERE Id = 5) = 0)
		INSERT INTO dbo.TipoComposicao (Id, Nome, IdPais) VALUES (5, 'Semirremolque Chico (M�nimo 20 m� /M�ximo 29 m�)', 2);

	IF ((SELECT COUNT(*) FROM dbo.TipoComposicao WHERE Id = 6) = 0)
		INSERT INTO dbo.TipoComposicao (Id, Nome, IdPais) VALUES (6, 'Semirremolque Grande (M�nimo 30 m� /M�ximo 39 m�)', 2);

	IF ((SELECT COUNT(*) FROM dbo.TipoComposicao WHERE Id = 7) = 0)
		INSERT INTO dbo.TipoComposicao (Id, Nome, IdPais) VALUES (7, 'Escalado (M�nimo 40 m� /M�ximo 49 m�)', 2);

	IF ((SELECT COUNT(*) FROM dbo.TipoComposicao WHERE Id = 8) = 0)
		INSERT INTO dbo.TipoComposicao (Id, Nome, IdPais) VALUES (8, 'Bitren Chico  (M�nimo 45 m� /M�ximo 55 m�)', 2);

	IF ((SELECT COUNT(*) FROM dbo.TipoComposicao WHERE Id = 9) = 0)
		INSERT INTO dbo.TipoComposicao (Id, Nome, IdPais) VALUES (9, 'Bitren Grande  (M�nimo60 m� /M�ximo 70 m�)', 2);
END


--1.4) Criacao da coluna caso ela NAO EXISTA
GO

IF COL_LENGTH('dbo.TipoProduto', 'IdPais') IS NULL
BEGIN
	ALTER TABLE dbo.TipoProduto ADD IdPais INT NULL;
END

GO

IF OBJECT_ID('dbo.[FK_TipoProduto_Pais]') IS NULL 
BEGIN
	ALTER TABLE dbo.TipoProduto ADD CONSTRAINT FK_TipoProduto_Pais FOREIGN KEY (IdPais) REFERENCES Pais(id);
END

GO

IF COL_LENGTH('dbo.TipoProduto', 'IdPais') IS NOT NULL
BEGIN
	IF ((SELECT COUNT(*) FROM dbo.TipoComposicao) <= 5)
		UPDATE dbo.TipoProduto SET IdPais = 1;
	
	IF ((SELECT COUNT(*) FROM dbo.TipoProduto WHERE Id = 6) = 0)
		INSERT INTO dbo.TipoProduto (Id, Nome, IdPais) VALUES (6, 'Diesel/Nafta/Fame/Etanol/Kerosen', 2);

	IF ((SELECT COUNT(*) FROM dbo.TipoProduto WHERE Id = 7) = 0)
		INSERT INTO dbo.TipoProduto (Id, Nome, IdPais) VALUES (7, 'JET', 2);

	IF ((SELECT COUNT(*) FROM dbo.TipoProduto WHERE Id = 8) = 0)
		INSERT INTO dbo.TipoProduto (Id, Nome, IdPais) VALUES (8, 'Qu�micos', 2);

	IF ((SELECT COUNT(*) FROM dbo.TipoProduto WHERE Id = 9) = 0)
		INSERT INTO dbo.TipoProduto (Id, Nome, IdPais) VALUES (9, 'Asfaltos/Fuel Oil', 2);

	IF ((SELECT COUNT(*) FROM dbo.TipoProduto WHERE Id = 10) = 0)
		INSERT INTO dbo.TipoProduto (Id, Nome, IdPais) VALUES (10, 'Coque', 2);
END 
  