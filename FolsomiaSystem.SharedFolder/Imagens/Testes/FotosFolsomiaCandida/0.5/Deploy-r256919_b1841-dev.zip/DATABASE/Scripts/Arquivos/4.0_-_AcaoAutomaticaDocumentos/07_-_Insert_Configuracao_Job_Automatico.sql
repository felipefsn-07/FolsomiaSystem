USE UniCad
GO

IF COL_LENGTH('dbo.Configuracao', 'IdPais') IS NULL 
BEGIN
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'JustificativaBloqueioAutomatico')
		EXEC('INSERT INTO Configuracao VALUES
		(''JustificativaBloqueioAutomatico'', ''Justificativa do Job utilizada no bloqueio autom�tico'', 
		''Bloqueio realizado por causa de documento(s) vencido(s)'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'JustificativaReprovaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''JustificativaReprovaAutomatica'', ''Justificativa do Job utilizada na reprova autom�tica'', 
		 ''Reprova realizada por causa de documento(s) vencido(s)'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'habilitarReprovaDocPlacaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''habilitarReprovaDocPlacaAutomatica'', ''Habilitar flag para reprova��o do documento de placa no job'', 
		''1'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'habilitarReprovaPlacaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''habilitarReprovaPlacaAutomatica'', ''Habilitar flag para reprova��o de placa no job'', 
		''1'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'habilitarReprovaDocMotoristaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''habilitarReprovaDocMotoristaAutomatica'', ''Habilitar flag para reprova��o do documento do motorista no job'', 
		''1'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'habilitarReprovaMotoristaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''habilitarReprovaMotoristaAutomatica'', ''Habilitar flag para reprova��o do motorista no job'', 
		''1'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloEmailBloqueioAutomatico')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloEmailBloqueioAutomatico'', ''T�tulo do e-mail para bloqueios realizados pelo job'', 
		''Ra�zen - Bloqueio - Documenta��o Vencida'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoEmailBloqueioAutomatico')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoEmailBloqueioAutomatico'', ''Corpo do e-mail para bloqueios realizados pelo job'', 
		''Ol�, informamos que voc� possui {0} com documento(s) vencido(s) e ser�(�o) <b>bloqueado(s)</b> <br/><br/>
		{1} </br>
		Acesse o cadastro de seu {2} e envie a documenta��o v�lida. <br/><br/>
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')	
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloEmailReprovaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloEmailReprovaAutomatica'', ''T�tulo do e-mail para reprova��es realizadas pelo job'', 
		''Ra�zen - Reprova��o - Documenta��o Vencida'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoEmailReprovaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES	
		(''CorpoEmailReprovaAutomatica'', ''Corpo do e-mail para reprova��es realizadas pelo job'', 
		''Ol�, informamos que voc� possui {0} com documento(s) vencido(s) e ser�(�o) <b>reprovado(s)</b> <br/><br/>
		{1} </br>
		Acesse o cadastro de seu {2} e envie a documenta��o v�lida. <br/><br/>
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'JustificativaBloqueioAutomatico')
		EXEC('INSERT INTO Configuracao VALUES
		(''JustificativaBloqueioAutomatico'', ''Justificativa do Job utilizada no bloqueio autom�tico'', 
		''Bloqueio realizado por causa de documento(s) vencido(s)'', GETDATE(), GETDATE(), NULL, 1)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'JustificativaReprovaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''JustificativaReprovaAutomatica'', ''Justificativa do Job utilizada na reprova autom�tica'', 
		''Reprova realizada por causa de documento(s) vencido(s)'', GETDATE(), GETDATE(), NULL, 1)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'habilitarReprovaDocPlacaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''habilitarReprovaDocPlacaAutomatica'', ''Habilitar flag para reprova��o do documento de placa no job'', 
		''1'', GETDATE(), GETDATE(), NULL, 1)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'habilitarReprovaPlacaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''habilitarReprovaPlacaAutomatica'', ''Habilitar flag para reprova��o de placa no job'', 
		''1'', GETDATE(), GETDATE(), NULL, 1)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'habilitarReprovaDocMotoristaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''habilitarReprovaDocMotoristaAutomatica'', ''Habilitar flag para reprova��o do documento do motorista no job'', 
		''1'', GETDATE(), GETDATE(), NULL, 1)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'habilitarReprovaMotoristaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''habilitarReprovaMotoristaAutomatica'', ''Habilitar flag para reprova��o do motorista no job'', 
		''1'', GETDATE(), GETDATE(), NULL, 1)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloEmailBloqueioAutomatico')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloEmailBloqueioAutomatico'', ''T�tulo do e-mail para bloqueios realizados pelo job'', 
		''Ra�zen - Bloqueio - Documenta��o Vencida'', GETDATE(), GETDATE(), NULL, 1)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoEmailBloqueioAutomatico')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoEmailBloqueioAutomatico'', ''Corpo do e-mail para bloqueios realizados pelo job'', 
		''Ol�, informamos que voc� possui {0} com documento(s) vencido(s) e ser�(�o) <b>bloqueado(s)</b> <br/><br/>
		{1} </br>
		Acesse o cadastro de seu {2} e envie a documenta��o v�lida. <br/><br/>
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL, 1)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloEmailReprovaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloEmailReprovaAutomatica'', ''T�tulo do e-mail para reprova��es realizadas pelo job'', 
		''Ra�zen - Reprova��o - Documenta��o Vencida'', GETDATE(), GETDATE(), NULL, 1)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoEmailReprovaAutomatica')
		EXEC('INSERT INTO Configuracao VALUES	
		(''CorpoEmailReprovaAutomatica'', ''Corpo do e-mail para reprova��es realizadas pelo job'', 
		''Ol�, informamos que voc� possui {0} com documento(s) vencido(s) e ser�(�o) <b>reprovado(s)</b> <br/><br/>
		{1} </br>
		Acesse o cadastro de seu {2} e envie a documenta��o v�lida. <br/><br/>
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL, 1)')
END