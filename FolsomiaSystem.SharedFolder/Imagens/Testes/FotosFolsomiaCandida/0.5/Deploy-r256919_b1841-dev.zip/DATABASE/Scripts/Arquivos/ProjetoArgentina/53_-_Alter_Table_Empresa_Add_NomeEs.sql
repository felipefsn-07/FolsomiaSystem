USE UniCad
GO

IF NOT EXISTS(SELECT * FROM sys.columns WHERE [object_id] = OBJECT_ID('[dbo].[Empresa]') AND UPPER(NAME) = 'NOMEES') BEGIN
	ALTER TABLE [dbo].[Empresa] ADD NomeEs VARCHAR(200) NULL;
END

GO

/* Inclus�o dos Nomes em Espanhol na tabela */
IF EXISTS (SELECT * FROM [Empresa] WHERE ID = 1 AND UPPER(Nome) = 'EAB') BEGIN
	UPDATE [Empresa] SET NomeEs = 'EAB' WHERE ID = 1;
END

GO

IF EXISTS (SELECT * FROM [Empresa] WHERE ID = 2 AND UPPER(Nome) = 'Combust�veis') BEGIN
	UPDATE [Empresa] SET NomeEs = 'Combustibles' WHERE ID = 2;
END

GO

IF EXISTS (SELECT * FROM [Empresa] WHERE ID = 3 AND UPPER(Nome) = 'Ambas') BEGIN
	UPDATE [Empresa] SET NomeEs = 'Ambas' WHERE ID = 3;
END

