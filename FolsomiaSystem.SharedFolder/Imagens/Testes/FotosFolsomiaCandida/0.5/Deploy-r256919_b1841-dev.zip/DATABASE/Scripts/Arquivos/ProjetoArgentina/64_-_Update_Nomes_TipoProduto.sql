USE UniCad

GO

UPDATE TipoProduto SET Nome = '�leo Combust�vel' WHERE ID = 2	
UPDATE TipoProduto SET Nome = 'Qu�micos' WHERE ID = 8
