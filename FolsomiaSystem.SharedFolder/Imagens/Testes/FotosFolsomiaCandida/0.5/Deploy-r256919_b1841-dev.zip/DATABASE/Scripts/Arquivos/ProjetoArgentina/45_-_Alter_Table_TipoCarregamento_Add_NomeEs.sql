USE UniCad
GO

/* Inclui a coluna "NomeEs" respons�vel por manter a tradu��o dos nomes no idioma Espanhol */
IF NOT EXISTS(SELECT * FROM sys.columns WHERE [object_id] = OBJECT_ID('[dbo].[TipoCarregamento]') AND UPPER(NAME) = 'NOMEES') BEGIN
	ALTER TABLE [dbo].[TipoCarregamento] ADD NomeEs VARCHAR(100) NULL;
END

GO

/* Inclus�o dos Nomes em Espanhol na tabela */
IF EXISTS (SELECT * FROM [TipoCarregamento] WHERE ID = 1 AND UPPER(Nome) = 'POR BAIXO') BEGIN
	UPDATE [TipoCarregamento] SET NomeEs = 'Por Abajo' WHERE ID = 1;
END

IF EXISTS (SELECT * FROM [TipoCarregamento] WHERE ID = 2 AND UPPER(Nome) = 'Por Cima') BEGIN
	UPDATE [TipoCarregamento] SET NomeEs = 'Por Encima' WHERE ID = 2;
END

IF EXISTS (SELECT * FROM [TipoCarregamento] WHERE ID = 3 AND UPPER(Nome) = 'POR AMBOS OS LADOS') BEGIN
	UPDATE [TipoCarregamento] SET NomeEs = 'En ambos lados' WHERE ID = 3;
END