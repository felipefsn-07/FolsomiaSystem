USE [UniCad]
GO

IF OBJECT_ID('dbo.[FK_TipoDocumentoTipoVeiculo_TipoDocumento]', 'F') IS NOT NULL 
    ALTER TABLE dbo.[TipoDocumentoTipoVeiculo] DROP CONSTRAINT FK_TipoDocumentoTipoVeiculo_TipoDocumento
GO
ALTER TABLE [dbo].[TipoDocumentoTipoVeiculo]  WITH CHECK ADD  CONSTRAINT [FK_TipoDocumentoTipoVeiculo_TipoDocumento] FOREIGN KEY([IDTipoDocumento])
REFERENCES [dbo].[TipoDocumento] ([ID])
ON DELETE CASCADE		
GO

IF OBJECT_ID('dbo.[FK_TipoDocumentoTipoProduto_TipoDocumento]', 'F') IS NOT NULL 
    ALTER TABLE dbo.[TipoDocumentoTipoProduto] DROP CONSTRAINT FK_TipoDocumentoTipoProduto_TipoDocumento
ALTER TABLE [dbo].[TipoDocumentoTipoProduto]  WITH CHECK ADD  CONSTRAINT [FK_TipoDocumentoTipoProduto_TipoDocumento] FOREIGN KEY([IDTipoDocumento])
REFERENCES [dbo].[TipoDocumento] ([ID])
ON DELETE CASCADE		
GO

IF OBJECT_ID('dbo.[FK_TipoDocumentoTipoComposicao_TipoDocumento]', 'F') IS NOT NULL 
    ALTER TABLE dbo.[TipoDocumentoTipoComposicao] DROP CONSTRAINT FK_TipoDocumentoTipoComposicao_TipoDocumento
ALTER TABLE [dbo].[TipoDocumentoTipoComposicao]  WITH CHECK ADD  CONSTRAINT [FK_TipoDocumentoTipoComposicao_TipoDocumento] FOREIGN KEY([IDTipoDocumento])
REFERENCES [dbo].[TipoDocumento] ([ID])
ON DELETE CASCADE		
GO




