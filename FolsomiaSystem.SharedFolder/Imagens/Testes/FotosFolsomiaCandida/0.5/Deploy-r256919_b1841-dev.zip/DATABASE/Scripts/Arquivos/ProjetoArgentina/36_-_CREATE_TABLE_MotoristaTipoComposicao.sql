USE [UniCad]

IF NOT EXISTS (SELECT 1 FROM SYS.TABLES WHERE NAME = 'MotoristaTipoComposicao')
BEGIN
	CREATE TABLE dbo.MotoristaTipoComposicao
		(
		ID int NOT NULL IDENTITY (1, 1),
		IDMotorista int NOT NULL,
		IDTipoComposicao int NOT NULL
		)  ON [PRIMARY]

	ALTER TABLE dbo.MotoristaTipoComposicao ADD CONSTRAINT
		FK_MotoristaTipoComposicao_Motorista FOREIGN KEY
		(
		IDMotorista
		) REFERENCES dbo.Motorista
		(
		ID
		) ON UPDATE  NO ACTION 
		 ON DELETE  NO ACTION 
	
	ALTER TABLE dbo.MotoristaTipoComposicao ADD CONSTRAINT
		FK_MotoristaTipoComposicao_TipoComposicao FOREIGN KEY
		(
		IDTipoComposicao
		) REFERENCES dbo.TipoComposicao
		(
		ID
		) ON UPDATE  NO ACTION 
		 ON DELETE  NO ACTION 
	
	ALTER TABLE dbo.MotoristaTipoComposicao SET (LOCK_ESCALATION = TABLE)
END
