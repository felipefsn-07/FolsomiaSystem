/***********************************************************
* 0) SELECAO DO BD
************************************************************/
USE [UniCad]

GO

/***********************************************************
* 1) CREATE DE OBJETOS SQL
************************************************************/

--1.1) Criacao da coluna caso ela NAO EXISTA
IF COL_LENGTH('dbo.TipoComposicao', 'NumeroPlacas') IS NULL 
BEGIN 
	ALTER TABLE TipoComposicao ADD NumeroPlacas INT NOT NULL DEFAULT 1;
END 

GO

--1.2) Preecnhe o valor correto da nova coluna criada
IF COL_LENGTH('dbo.TipoComposicao', 'NumeroPlacas') IS NOT NULL 
BEGIN
	UPDATE TipoComposicao SET NumeroPlacas = 1 WHERE ID = 1;
	UPDATE TipoComposicao SET NumeroPlacas = 2 WHERE ID = 2;
	UPDATE TipoComposicao SET NumeroPlacas = 3 WHERE ID = 3;
	UPDATE TipoComposicao SET NumeroPlacas = 4 WHERE ID = 4;
	UPDATE TipoComposicao SET NumeroPlacas = 2 WHERE ID = 5;
	UPDATE TipoComposicao SET NumeroPlacas = 2 WHERE ID = 6;
	UPDATE TipoComposicao SET NumeroPlacas = 2 WHERE ID = 7;
	UPDATE TipoComposicao SET NumeroPlacas = 3 WHERE ID = 8;
	UPDATE TipoComposicao SET NumeroPlacas = 3 WHERE ID = 9;
END
