/***********************************************************
* 0) SELEÇÃO DA BASE E CONFIGURAÇÕES INICAIS
************************************************************/
USE Unicad
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/***********************************************************
* 1) AJUSTE NA PROCEDURE
************************************************************/

--1.1) Verifica se já existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Listar_Composicoes_Servico')
    DROP PROCEDURE [Proc_Listar_Composicoes_Servico];
GO

--1.2) Recriar a procedure ajustada
CREATE PROCEDURE [dbo].[Proc_Listar_Composicoes_Servico]
	@LinhaNegocio INT = NULL,
	@Operacao VARCHAR(3) = NULL,
	@Placa VARCHAR(7) = NULL,
	@DataAtualizacao DATETIME
AS
BEGIN
DECLARE @StrSQL VARCHAR(8000)

SET @StrSQL = '
	SELECT 
	Co.Id,
	Co.IdEmpresa AS LinhaNegocio,
	Co.Operacao,
	Co.IdTipoComposicao AS TipoComposicao,
	Co.Placa1 AS PlacaVeiculoCavaloTruck,
	Co.Placa2 AS PlacaVeiculoCarreta1,
	Co.Placa3 AS PlacaVeiculoDollyCarreta2,
	Co.Placa4 AS PlacaVeiculoCarreta2,
	Co.IdPlaca1,
	Co.IdPlaca2,
	Co.IdPlaca3,
	Co.IdPlaca4,
	Co.Arrendamento,
	Co.CPFCNPJArrendamento AS CpfCnpjTransportadorArrendamento,
	Co.RazaoSocialArrendamento AS NomeRazaoSocialArrendamento,
	Co.PBTC,
	Co.DataAtualizacao,
	Co.IDStatus AS Status
FROM(
SELECT 
		C.id,
		C.idEmpresa,
		C.Operacao,
		C.IDTipoComposicao,
		(
			SELECT PlacaVeiculo FROM VW_Placa WHERE ID = C.IDPlaca1
		) AS Placa1,
		(
			SELECT PlacaVeiculo FROM VW_Placa WHERE ID = C.IDPlaca2
		) AS Placa2,
		(
			SELECT PlacaVeiculo FROM VW_Placa WHERE ID = C.IDPlaca3
		) AS Placa3,
		(
			SELECT PlacaVeiculo FROM VW_Placa WHERE ID = C.IDPlaca4
		) AS Placa4,
		C.idPlaca1,
		C.idPlaca2,
		C.idPlaca3,
		C.idPlaca4,
		(
			SELECT PlacaVeiculo 
			FROM VW_Placa 
			WHERE ID = 
			CASE 
				WHEN C.IDTipoComposicao = 1 OR C.IDEmpresa = 1 THEN C.IdPlaca1 --se for EAB ou TRUCK a placa chave é a primeira
				ELSE C.IDPlaca2 END
		) AS PlacaChave,
		CONVERT(BIT,CASE
			WHEN C.CPFCNPJArrendamento IS NULL THEN 0
			ELSE 1 END)
		AS Arrendamento,
		C.CPFCNPJArrendamento,
		C.RazaoSocialArrendamento,
		C.PBTC,
		C.DataAtualizacao,
		C.IDStatus
	FROM Composicao C
) Co INNER JOIN
(
	SELECT P.PlacaVeiculo, Comp.Operacao, Comp.idEmpresa, MAX(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(idstatus,2,-9),1,-8),5,-7),4,-6),6,-5)) AS Status  
	FROM Composicao Comp
	INNER JOIN VW_Placa P ON Comp.IDPlaca1 = P.ID 
	WHERE  Comp.idstatus in (2,1,5,4,6)  
	AND Comp.IDTipoComposicao = 1 '
	IF (@DataAtualizacao IS NOT NULL)
		SET @StrSQL += ' AND  (Comp.DataAtualizacao >= ''' + CONVERT(VARCHAR(19),@DataAtualizacao) + ''') '
	SET @StrSQL += '
	GROUP BY P.PlacaVeiculo,Comp.Operacao, Comp.IDEmpresa		
	UNION
	SELECT P.PlacaVeiculo, Comp.Operacao, Comp.idEmpresa, MAX(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(idstatus,2,-9),1,-8),5,-7),4,-6),6,-5)) AS Status  
	FROM Composicao Comp
	INNER JOIN VW_Placa P ON Comp.IDPlaca1 = P.ID 
	WHERE  Comp.idstatus in (2,1,5,4,6)  
	AND Comp.IDEmpresa = 1 '
	IF (@DataAtualizacao IS NOT NULL)
		SET @StrSQL += ' AND  (Comp.DataAtualizacao >= ''' + CONVERT(VARCHAR(19),@DataAtualizacao) + ''') '
	SET @StrSQL += '
	GROUP BY P.PlacaVeiculo,Comp.Operacao, Comp.IDEmpresa		
	UNION
	SELECT P.PlacaVeiculo, Comp.Operacao, Comp.idEmpresa, MAX(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(idstatus,2,-9),1,-8),5,-7),4,-6),6,-5)) AS Status  
	FROM Composicao Comp
	INNER JOIN VW_Placa P ON Comp.IDPlaca2 = P.ID 
	WHERE  Comp.idstatus in (2,1,5,4,6) 
	AND Comp.IDEmpresa = 2 
	AND Comp.IDTipoComposicao <> 1 '
	IF (@DataAtualizacao IS NOT NULL)
		SET @StrSQL += ' AND  (Comp.DataAtualizacao >= ''' + CONVERT(VARCHAR(19),@DataAtualizacao) + ''') '
	SET @StrSQL += '
	GROUP BY P.PlacaVeiculo,Comp.Operacao, Comp.IDEmpresa		
) A ON Co.PlacaChave = A.PlacaVeiculo 
	AND Co.Operacao = A.Operacao 
	AND Co.IDEmpresa = A.IDEmpresa 
	WHERE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(co.idstatus,2,-9),1,-8),5,-7),4,-6),6,-5) = A.Status	'
	IF (@LinhaNegocio IS NOT NULL)
		SET @StrSQL +=' AND (Co.IDEmpresa = ' + CONVERT(VARCHAR(1),@LinhaNegocio) + ') '
	IF (@Operacao IS NOT NULL)
		SET @StrSQL +=' AND (Co.Operacao = ''' + CONVERT(VARCHAR(3),@Operacao) + ''') '			
	IF (@Placa IS NOT NULL)
		SET @StrSQL +=' AND (Co.Placa1 = ''' + CONVERT(VARCHAR(11),@Placa) + ''' 
			OR Co.Placa2 = ''' + CONVERT(VARCHAR(11),@Placa) + '''
			OR Co.Placa3 = ''' + CONVERT(VARCHAR(11),@Placa) + '''
			OR Co.Placa4 = ''' + CONVERT(VARCHAR(11),@Placa) + ''')'
	
	--tirar
	print @StrSQL
	EXEC (@StrSQL)
END

