/***********************************************************
* 0) SELECAO DO BD
************************************************************/
USE Unicad

GO

/***********************************************************
* 1) CREATE DE OBJETOS SQL
************************************************************/

-- --1.1) Criacao da tabela [PlacaBrasil] caso ela NAO EXISTA
IF NOT EXISTS (SELECT 1 FROM SYS.TABLES WHERE NAME = 'PlacaBrasil') BEGIN
	CREATE TABLE [PlacaBrasil] (
		[IDPlaca] [int] NOT NULL, -- FK Placa
		[Renavam] [varchar](20) NULL,
		[CPFCNPJ] [varchar](20) NULL,
		[IDEstado] [int] NOT NULL,
		[Cidade] [varchar](400)

		CONSTRAINT [PK_PlacaBrasil_ID] PRIMARY KEY ([IDPlaca]),
		CONSTRAINT [FK_PlacaBrasil_PlacaID] FOREIGN KEY ([IDPlaca]) REFERENCES Placa(ID) ON DELETE CASCADE,
		CONSTRAINT [FK_PlacaBrasil_IDEstado] FOREIGN KEY ([IDEstado]) REFERENCES Estado(ID)
	);
END

GO

--1.2) Criacao da tabela [PlacaArgentina] caso ela NAO EXISTA
IF NOT EXISTS (SELECT 1 FROM SYS.TABLES WHERE NAME = 'PlacaArgentina') BEGIN
	CREATE TABLE [PlacaArgentina] (
		[IDPlaca] [int] NOT NULL, -- FK Placa
		[CUIT] [varchar](20) NULL,
		[PBTC] [float] NOT NULL,
		[Material] [varchar](80) NULL,
		[NrMotor] [varchar](80) NULL,
        [SatelitalMarca] [varchar](80) NULL,
        [SatelitalModelo] [varchar](80) NULL,
        [SatelitalNrInterno] [varchar](80) NULL,
        [SatelitalEmpresa] [varchar](80) NULL,
        [Vencimento] [varchar](80) NULL,
		[Potencia] [varchar](80) NULL
		
		CONSTRAINT [PK_PlacaArgentina_ID] PRIMARY KEY ([IDPlaca]),
		CONSTRAINT [FK_PlacaArgentina_PlacaID] FOREIGN KEY ([IDPlaca]) REFERENCES Placa(ID) ON DELETE CASCADE
	);
END

GO

--1.3) Inclusao da coluna "IdPais" na tabela [TipoVeiculo] caso ela NAO EXISTA
IF COL_LENGTH('dbo.TipoVeiculo', 'IdPais') IS NULL BEGIN
	ALTER TABLE dbo.TipoVeiculo ADD IdPais INT NULL;
	ALTER TABLE dbo.TipoVeiculo ADD CONSTRAINT [FK_TipoVeiculo_Pais] FOREIGN KEY (IdPais) REFERENCES Pais(id);
END

GO

--1.4) Inclusao da coluna "IdPais" na tabela [Placa] caso ela NAO EXISTA
IF COL_LENGTH('dbo.Placa', 'IdPais') IS NULL BEGIN
	ALTER TABLE dbo.Placa ADD IdPais INT NULL;
	ALTER TABLE dbo.Placa ADD CONSTRAINT [FK_Placa_Pais] FOREIGN KEY (IdPais) REFERENCES Pais(id);
END

GO

/***********************************************************
* 2) INSERT E UPDATE DE REGISTROS
************************************************************/

--2.1) Setando um valor da nova coluna "IdPais" de todos os registros para Brasil
IF COL_LENGTH('dbo.Placa', 'IdPais') IS NOT NULL BEGIN 
	UPDATE dbo.Placa SET IdPais = 1 WHERE IdPais IS NULL;
END

GO

--2.2) Setando um valor da nova coluna "IdPais" de todos os registros para Brasil e incluindo os registros referente a Argentina
IF COL_LENGTH('dbo.TipoVeiculo', 'IdPais') IS NOT NULL BEGIN
	UPDATE dbo.TipoVeiculo SET IdPais = 1 WHERE IdPais IS NULL;

	IF NOT EXISTS(SELECT 1 FROM dbo.TipoVeiculo WHERE ID = 5) BEGIN
		INSERT INTO [dbo].[TipoVeiculo] (ID, Nome, IdPais) VALUES (5, 'Caballo', 2);
	END ELSE BEGIN
		UPDATE dbo.TipoVeiculo SET IdPais = 2 WHERE ID = 5;
	END

	IF NOT EXISTS(SELECT 1 FROM dbo.TipoVeiculo WHERE ID = 6) BEGIN
		INSERT INTO [dbo].[TipoVeiculo] (ID, Nome, IdPais) VALUES (6, 'Remolque', 2);
	END ELSE BEGIN
		UPDATE dbo.TipoVeiculo SET IdPais = 2 WHERE ID = 6;
	END

	IF NOT EXISTS(SELECT 1 FROM dbo.TipoVeiculo WHERE ID = 7) BEGIN
		INSERT INTO [dbo].[TipoVeiculo] (ID, Nome, IdPais) VALUES (7, 'Dolly', 2);
	END ELSE BEGIN
		UPDATE dbo.TipoVeiculo SET IdPais = 2 WHERE ID = 7;
	END

	IF NOT EXISTS(SELECT 1 FROM dbo.TipoVeiculo WHERE ID = 8) BEGIN
		INSERT INTO [dbo].[TipoVeiculo] (ID, Nome, IdPais) VALUES (8, 'Cami�n', 2);
	END ELSE BEGIN
		UPDATE dbo.TipoVeiculo SET IdPais = 2 WHERE ID = 8;
	END
END

GO


/***********************************************************
* 3) TRANSFERENCIA DE DADOS ENTRE AS TABELAS REFATORADAS
************************************************************/

--3.1) Popula [PlacaBrasil] com as informacoes existentes na tabela [Placa]

IF ((COL_LENGTH('dbo.Placa', 'ID') IS NOT NULL)
AND (COL_LENGTH('dbo.Placa', 'Renavam') IS NOT NULL)
AND (COL_LENGTH('dbo.Placa', 'CPFCNPJ') IS NOT NULL)
AND (COL_LENGTH('dbo.Placa', 'IDEstado') IS NOT NULL)
AND (COL_LENGTH('dbo.Placa', 'Cidade') IS NOT NULL)
) BEGIN
	EXEC ('INSERT INTO dbo.PlacaBrasil (IDPlaca, Renavam, CPFCNPJ, IDEstado, Cidade) 
		      SELECT ID, Renavam, CPFCNPJ, IDEstado, Cidade FROM Placa ');
END

GO

/***********************************************************
* 4) DROP DE OBJETOS 
************************************************************/
-- 4.1) Dropando as colunas que foram transferida da tabela Placa para PlacaBrasil
IF COL_LENGTH('dbo.Placa', 'Renavam') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Placa] DROP COLUMN [Renavam];
END

GO

IF COL_LENGTH('dbo.Placa', 'CPFCNPJ') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Placa] DROP COLUMN [CPFCNPJ];
END

GO

IF COL_LENGTH('dbo.Placa', 'IDEstado') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Placa] DROP COLUMN [IDEstado];
END

GO

IF COL_LENGTH('dbo.Placa', 'Cidade') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Placa] DROP COLUMN [Cidade];
END

GO


/***********************************************************
* 5) AJUSTES FINAIS
************************************************************/

-- 5.1) Alteracoes da coluna "IdPais" da tabela [TipoVeiculo] para NOT NULL
IF COL_LENGTH('dbo.TipoVeiculo', 'IdPais') IS NOT NULL BEGIN 
	ALTER TABLE [dbo].[TipoVeiculo] ALTER COLUMN [IdPais] INT NOT NULL
END

GO

-- 5.2) Alteracao da coluna "IdPais" da tabela [Placa] para NOT NULL
IF COL_LENGTH('dbo.Placa', 'IdPais') IS NOT NULL BEGIN 
	ALTER TABLE [dbo].[Placa] ALTER COLUMN [IdPais] INT NOT NULL
END

GO