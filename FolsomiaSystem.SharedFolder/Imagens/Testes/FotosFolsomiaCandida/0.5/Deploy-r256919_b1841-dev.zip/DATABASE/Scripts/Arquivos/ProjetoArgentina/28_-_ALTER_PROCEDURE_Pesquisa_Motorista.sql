/***********************************************************
* 0) SELEÇÃO DA BASE E CONFIGURAÇÕES INICAIS
************************************************************/
USE [UniCad]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/***********************************************************
* 1) AJUSTE NA PROCEDURE
************************************************************/

--1.1) Verifica se já existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Pesquisa_Motorista')
    DROP PROCEDURE [Proc_Pesquisa_Motorista];
GO

--1.2) Recriar a procedure ajustada
CREATE PROCEDURE  [dbo].[Proc_Pesquisa_Motorista]
	@IsCount BIT = 0,
	@IsExportar BIT = 0,
	@PrimeiraPagina INT = NULL,
	@UltimaPagina INT = NULL,
	@Nome VARCHAR(100) = NULL,
	@IDEmpresa INT = NULL,
	@IDStatus INT = NULL,
	@Operacao VARCHAR(10) = NULL,
	@IsAtivo BIT = NULL,
	@CNH VARCHAR(23) = NULL,
	@CPF VARCHAR(13) = NULL,
	@RG VARCHAR(18) = NULL,
	@DataInicio DATETIME = NULL,
	@DataFim DATETIME = NULL,
	@IDUsuarioCliente INT = NULL,
	@IDUsuarioTransportadora INT = NULL,
	@Chamado VARCHAR(23) = NULL,
	@IDTransportadora INT = NULL
AS
BEGIN
	DECLARE @StrSQL VARCHAR(6000)
	DECLARE @StrSQLSelect VARCHAR(4000)
	IF (@Nome IS NOT NULL)
		SET @Nome = '%' + @Nome + '%'
	IF (@CNH IS NOT NULL)
		SET @CNH = '%' + @CNH + '%'
	IF (@CPF IS NOT NULL)
		SET @CPF = '%' + @CPF + '%'
	IF (@RG IS NOT NULL)
		SET @RG = '%' + @RG + '%'
	IF (@Chamado IS NOT NULL)
		SET @Chamado = '%' + @Chamado + '%'
	IF @DataFim IS NOT NULL
		SET @DataFim = DATEADD(MS, -1, DATEADD(D, 1, CONVERT(DATETIME2, @DataFim)))

	
	IF (@IsExportar = 0)
	BEGIN
		IF (@IsCount = 1) 
		BEGIN
			SET @strSQL = 
			'SELECT COUNT(*) AS Linhas '
		END
		ELSE
			SET @StrSQL = 
			'SELECT
				RowNum,
				Nome,
				Anexo,
				Ativo,
				CategoriaCNH,
				CNH ,
				CodigoEasyQuery,
				CPF,
				DataAtualizazao,
				Email,
				ID,
				IDEmpresa,
				IDMotorista,
				IDStatus,
				IDTransportadora,
				LocalNascimento,
				LoginUsuario,
				Nascimento,
				Operacao,
				OrgaoEmissor,
				OrgaoEmissorCNH,
				RG,
				Telefone,
				Justificativa,
				Observacao,
				UsuarioAlterouStatus '
		SET @strSQL += '
			FROM
			(
				SELECT  
					ROW_NUMBER() OVER (ORDER BY M.DataAtualizazao DESC) AS RowNum,
					M.Nome,
					M.Anexo,
					M.Ativo,
					M.CategoriaCNH,
					M.CNH ,
					M.CodigoEasyQuery,
					M.CPF,
					M.DataAtualizazao,
					M.Email,
					M.ID,
					M.IDEmpresa,
					M.IDMotorista,
					M.IDStatus,
					M.IDTransportadora,
					M.LocalNascimento,
					M.LoginUsuario,
					M.Nascimento,
					M.Operacao,
					M.OrgaoEmissor,
					M.OrgaoEmissorCNH,
					M.RG,
					M.Telefone,
					M.Justificativa,
					M.Observacao,
					M.UsuarioAlterouStatus
					FROM VW_Motorista M
					LEFT JOIN UsuarioTransportadora UT ON M.IDTransportadora = UT.IDTransportadora
					LEFT JOIN MotoristaCliente MC on M.ID = MC.IDMotorista
					LEFT JOIN UsuarioCliente UC on MC.IDCliente = UC.IDCliente
					WHERE (IDStatus != 3) '
	END
	ELSE
	BEGIN
		--exportação
		DECLARE @cols AS NVARCHAR(400)
		SET @cols = STUFF((SELECT distinct ',' + QUOTENAME(t.Sigla) 
				FROM TipoDocumento T WHERE T.TipoCadastro = 2 
				FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(400)') 
			,1,1,'')

		SET @StrSQLSelect =
			'SELECT '+ @cols + ',
				Nome,
				Anexo,
				Ativo,
				CategoriaCNH,
				CNHMotorista ,
				CodigoEasyQuery,
				CPF,
				DataAtualizazao,
				Email,
				ID,
				IDEmpresa,
				IDMotorista,
				IDStatus,
				IDTransportadora,
				LocalNascimento,
				LoginUsuario,
				Nascimento,
				Operacao,
				OrgaoEmissor,
				OrgaoEmissorCNH,
				RG,
				Telefone,
				Justificativa,
				Observacao, 
				IBM,
				NomeCliente,
				DataValidadeTreinamentoTeorico,
				TreinamentoAprovadoTreinamentoTeorico,
				DataValidadeTreinamentoPratico,
				TerminalTreinamentoPratico,
				PISCampo,
				UsuarioAlterouStatus 
				FROM
				(
					SELECT  
						MT.Nome,
						MT.Anexo,
						MT.Ativo,
						MT.CategoriaCNH,
						MT.CNHMotorista ,
						MT.CodigoEasyQuery,
						MT.CPF,
						MT.DataAtualizazao,
						MT.Email,
						MT.ID,
						MT.IDEmpresa,
						MT.IDMotorista,
						MT.IDStatus,
						MT.IDTransportadora,
						MT.LocalNascimento,
						MT.LoginUsuario,
						MT.Nascimento,
						MT.Operacao,
						MT.OrgaoEmissor,
						MT.OrgaoEmissorCNH,
						MT.RG,
						MT.Telefone,
						MT.Justificativa,
						MT.Observacao,
						MT.IBM,
						MT.NomeCliente,
						MT.DataVencimento as DataVencimento,
						MT.Sigla,
						MT.DataValidadeTreinamentoTeorico,
						MT.TreinamentoAprovadoTreinamentoTeorico,
						MT.DataValidadeTreinamentoPratico,
						MT.TerminalTreinamentoPratico,
						MT.IDUsuarioTransportadora,
						MT.IDUsuarioCliente,
						MT.PIS AS PisCampo,
						MT.UsuarioAlterouStatus 
						FROM(
							SELECT  MO.Nome,
								MO.Anexo,
								MO.Ativo,
								MO.CategoriaCNH,
								MO.CNH AS CNHMotorista,
								MO.CodigoEasyQuery,
								MO.CPF,
								MO.DataAtualizazao,
								MO.Email,
								MO.ID,
								MO.IDEmpresa,
								MO.IDMotorista,
								MO.IDStatus,
								MO.IDTransportadora,
								MO.LocalNascimento,
								MO.LoginUsuario,
								MO.Nascimento,
								MO.Operacao,
								MO.OrgaoEmissor,
								MO.OrgaoEmissorCNH,
								MO.RG,
								MO.Telefone,
								MO.Justificativa,
								MO.Observacao,
								MO.PIS,
								MO.UsuarioAlterouStatus,
								T.IBM,	
								T.RazaoSocial as NomeCliente,				
								PC.DataVencimento as DataVencimento,
								TD.Sigla,
								TreinamentoTeorico.Data AS DataValidadeTreinamentoTeorico,
								TreinamentoTeorico.TreinamentoAprovado AS TreinamentoAprovadoTreinamentoTeorico,
								TreinamentoPratico.DataValidade AS DataValidadeTreinamentoPratico,
								TreinamentoPratico.Nome AS TerminalTreinamentoPratico,
								UT.IDUsuario AS IDUsuarioTransportadora,
								NULL AS IDUsuarioCliente '
							Set @StrSQL =
							'FROM VW_Motorista MO 
							INNER JOIN Transportadora t on MO.IDTransportadora = t.id
							LEFT JOIN UsuarioTransportadora UT ON MO.IDTransportadora = UT.IDTransportadora
							INNER JOIN MotoristaDocumento PC ON MO.ID = PC.IDMotorista
							INNER JOIN TipoDocumento TD ON PC.IDTipoDocumento = TD.ID
							OUTER APPLY (
								SELECT TOP 1 H.Data, H.TreinamentoAprovado FROM HistoricoTreinamentoTeoricoMotorista H WHERE H.IDMotorista = MO.ID ORDER BY DATA DESC) AS TreinamentoTeorico
							OUTER APPLY (
								SELECT TOP 1 MT.DataValidade, T.Nome  FROM MotoristaTreinamentoTerminal MT INNER JOIN Terminal T ON MT.IDTerminal = T.ID 
									WHERE MT.IDMotorista = MO.ID ORDER BY DATA DESC) AS TreinamentoPratico
							WHERE MO.Operacao = ''CIF''
							UNION 
							SELECT  MO.Nome,
									MO.Anexo,
									MO.Ativo,
									MO.CategoriaCNH,
									MO.CNH AS CNHMotorista,
									MO.CodigoEasyQuery,
									MO.CPF,
									MO.DataAtualizazao,
									MO.Email,
									MO.ID,
									MO.IDEmpresa,
									MO.IDMotorista,
									MO.IDStatus,
									MO.IDTransportadora,
									MO.LocalNascimento,
									MO.LoginUsuario,
									MO.Nascimento,
									MO.Operacao,
									MO.OrgaoEmissor,
									MO.OrgaoEmissorCNH,
									MO.RG,
									MO.Telefone,
									MO.Justificativa,
									MO.Observacao,
									MO.PIS,
									MO.UsuarioAlterouStatus,
									CLI.IBM,
									CLI.RazaoSocial as NomeCliente,	
									PC.DataVencimento as DataVencimento,
									TD.Sigla,
									TreinamentoTeorico.Data AS DataValidadeTreinamentoTeorico,
									TreinamentoTeorico.TreinamentoAprovado AS TreinamentoAprovadoTreinamentoTeorico,
									TreinamentoPratico.DataValidade AS DataValidadeTreinamentoPratico,
									TreinamentoPratico.Nome AS TerminalTreinamentoPratico,
									NULL AS IDUsuarioTransportadora,
									UC.IDUsuario AS IDUsuarioCliente
							FROM VW_Motorista MO 
							INNER JOIN MotoristaCliente MC on MO.id = MC.idMotorista
							INNER JOIN Cliente cli on MC.IDCliente = cli.ID
							LEFT JOIN UsuarioCliente UC on MC.IDCliente = UC.IDCliente
							INNER JOIN MotoristaDocumento PC ON MO.ID = PC.IDMotorista
							INNER JOIN TipoDocumento TD ON PC.IDTipoDocumento = TD.ID
							OUTER APPLY (
								SELECT TOP 1 H.Data, H.TreinamentoAprovado FROM HistoricoTreinamentoTeoricoMotorista H WHERE H.IDMotorista = MO.ID ORDER BY DATA DESC) AS TreinamentoTeorico
							OUTER APPLY (
								SELECT TOP 1 MT.DataValidade, T.Nome  FROM MotoristaTreinamentoTerminal MT INNER JOIN Terminal T ON MT.IDTerminal = T.ID 
									WHERE MT.IDMotorista = MO.ID ORDER BY DATA DESC) AS TreinamentoPratico
							WHERE MO.Operacao = ''FOB''							
						) MT 
					) M 		
			PIVOT
			(
				MAX(M.DataVencimento)
				FOR M.Sigla IN (' + @cols + ')
			) P  WHERE (IDStatus != 3) '
	END		
		IF (@Nome IS NOT NULL)
			SET @StrSQL += ' AND (Nome LIKE ''' +  CONVERT(VARCHAR(100),@Nome) +''') '
		IF (@IDEmpresa IS NOT NULL)
			SET @StrSQL += ' AND (IDEmpresa = ' + CONVERT(VARCHAR(1),@IDEmpresa) +') '
		IF (@IDStatus IS NOT NULL)
			SET @StrSQL += ' AND (IDStatus = ' + CONVERT(VARCHAR(1),@IDStatus) +') '
		IF (@Operacao IS NOT NULL)
			SET @StrSQL += ' AND (Operacao = ''' + @Operacao +''') '
		IF (@IsAtivo IS NOT NULL)
			SET @StrSQL += ' AND (Ativo = ' + CONVERT(VARCHAR(1),@IsAtivo) +') '
		IF (@CNH IS NOT NULL)
			IF (@IsExportar = 0)
				SET @StrSQL += 'AND (CNH LIKE ''' +@CNH +''') '
			ELSE
				SET @StrSQL += 'AND (CNHMotorista LIKE ''' +@CNH +''') '
		IF (@CPF IS NOT NULL)
			SET @StrSQL += 'AND (CPF LIKE ''' + @CPF +''') '
		IF (@RG IS NOT NULL)
			SET @StrSQL += 'AND (RG LIKE ''' + @RG +''') '
		IF (@Chamado IS NOT NULL)
			SET @StrSQL += 'AND (CodigoEasyQuery LIKE ''' + @Chamado +''') '
		IF (@IDUsuarioTransportadora IS NOT NULL)
			IF (@IsExportar = 0)
				SET @StrSQL += 'AND (UT.IDUsuario = ' + CONVERT(VARCHAR(8),@IDUsuarioTransportadora) +') '
			ELSE
				SET @StrSQL += 'AND (IDUsuarioTransportadora = ' + CONVERT(VARCHAR(8),@IDUsuarioTransportadora) +') '
		IF (@IDUsuarioCliente IS NOT NULL)
			IF (@IsExportar = 0)
				SET @StrSQL += 'AND (UC.IDUsuario = ' + CONVERT(VARCHAR(8),@IDUsuarioCliente) +') '
				
			ELSE
				SET @StrSQL += 'AND (IDUsuarioCliente = ' + CONVERT(VARCHAR(8),@IDUsuarioCliente) +') '
		IF (@DataInicio IS NOT NULL)
			SET @StrSQL += ' AND (DataAtualizazao >= ''' + CONVERT(VARCHAR(19),@DataInicio) +''') '
		IF (@DataFim IS NOT NULL)
			SET @StrSQL += ' AND (DataAtualizazao  <= ''' + CONVERT(VARCHAR(19),@DataFim) +''') '
		IF (@IDTransportadora IS NOT NULL)
			IF (@IsExportar = 0)
				SET @StrSQL += ' AND (M.IDTransportadora =  ' + CONVERT(VARCHAR(10),@IDTransportadora) +')'
			ELSE
				SET @StrSQL += ' AND (IDTransportadora =  ' + CONVERT(VARCHAR(10),@IDTransportadora) +')'
		IF (@IsExportar = 0)	
		BEGIN	
			SET @StrSQL += '
			GROUP BY
				M.Nome,
				M.Anexo,
				M.Ativo,
				M.CategoriaCNH,
				M.CNH,
				M.CodigoEasyQuery,
				M.CPF,
				M.DataAtualizazao,
				M.Email,
				M.ID,
				M.IDEmpresa,
				M.IDMotorista,
				M.IDStatus,
				M.IDTransportadora,
				M.LocalNascimento,
				M.LoginUsuario,
				M.Nascimento,
				M.Operacao,
				M.OrgaoEmissor,
				M.OrgaoEmissorCNH,
				M.RG,
				M.Telefone,
				M.Justificativa,
				M.Observacao,
				M.UsuarioAlterouStatus '	
		END 
		ELSE
		BEGIN
			SET @StrSQL += '
				GROUP BY 
				' +@cols + ',
				Nome,
				Anexo,
				Ativo,
				CategoriaCNH,
				CNHMotorista ,
				CodigoEasyQuery,
				CPF,
				DataAtualizazao,
				Email,
				ID,
				IDEmpresa,
				IDMotorista,
				IDStatus,
				IDTransportadora,
				LocalNascimento,
				LoginUsuario,
				Nascimento,
				Operacao,
				OrgaoEmissor,
				OrgaoEmissorCNH,
				RG,
				Telefone,
				Justificativa,
				Observacao, 
				IBM,
				PISCampo,
				NomeCliente,
				DataValidadeTreinamentoTeorico,
				TreinamentoAprovadoTreinamentoTeorico,
				DataValidadeTreinamentoPratico,
				TerminalTreinamentoPratico,
				UsuarioAlterouStatus
				ORDER BY DataAtualizazao DESC '
		END
	IF (@IsExportar = 0)
	BEGIN
	SET @StrSQL += ' ) Motorista'
	IF (@PrimeiraPagina IS NOT NULL)
		SET @StrSQL += ' WHERE Motorista.RowNum > ' + CONVERT(VARCHAR(5),@PrimeiraPagina) 
	IF (@UltimaPagina IS NOT NULL)
		SET @StrSQL += ' AND Motorista.RowNum <= '  + CONVERT(VARCHAR(5),@UltimaPagina)	
		EXEC (@StrSQL)
	END
	ELSE
		EXEC (@StrSQLSelect + @StrSQL)
END
