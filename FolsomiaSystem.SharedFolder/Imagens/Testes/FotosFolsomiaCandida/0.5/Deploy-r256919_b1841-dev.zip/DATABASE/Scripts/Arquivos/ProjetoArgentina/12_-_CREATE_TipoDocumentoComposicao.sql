USE [unicad]
GO

IF NOT EXISTS (SELECT 1 FROM SYS.TABLES WHERE NAME = 'TipoDocumentoTipoComposicao')
BEGIN
    CREATE TABLE [dbo].[TipoDocumentoTipoComposicao](
        [ID] [int] IDENTITY(1,1) NOT NULL,
        [IDTipoComposicao] [int] NOT NULL,
		[IDTipoDocumento] [int] NOT NULL,
        [Placa1] [bit] NULL,
        [Placa2] [bit] NULL,
        [Placa3] [bit] NULL,
        [Placa4] [bit] NULL,
     CONSTRAINT [PK_TipoDocumentoTipoComposicao_ID] PRIMARY KEY CLUSTERED 
    (
        [ID] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY];

 

    ALTER TABLE [dbo].[TipoDocumentoTipoComposicao]  WITH CHECK ADD CONSTRAINT [FK_TipoDocumentoTipoComposicao_TipoComposicao] FOREIGN KEY([IDTipoComposicao])
    REFERENCES [dbo].[TipoComposicao] ([ID]);
	
	ALTER TABLE [dbo].[TipoDocumentoTipoComposicao]  WITH CHECK ADD CONSTRAINT [FK_TipoDocumentoTipoComposicao_TipoDocumento] FOREIGN KEY([IDTipoDocumento])
    REFERENCES [dbo].[TipoDocumento] ([ID]);
END