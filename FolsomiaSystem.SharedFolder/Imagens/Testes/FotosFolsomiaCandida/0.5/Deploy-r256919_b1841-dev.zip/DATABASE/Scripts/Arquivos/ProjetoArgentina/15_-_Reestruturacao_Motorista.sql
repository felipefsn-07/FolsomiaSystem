/***********************************************************
* 0) SELECAO DO BD
************************************************************/
USE [UniCad]

GO

/***********************************************************
* 1) CREATE DE OBJETOS SQL
************************************************************/

--1.1) Criacao da tabela [MotoristaBrasil] caso ela NAO EXISTA
IF NOT EXISTS (SELECT 1 FROM SYS.TABLES WHERE NAME = 'MotoristaBrasil') BEGIN
	CREATE TABLE [MotoristaBrasil] (
		[IDMotorista] INT NOT NULL, -- FK Motorista (1 x 1)
		[CPF] [varchar](11) NOT NULL,
		[RG] [varchar](15) NOT NULL,
		[OrgaoEmissor] [varchar](10) NULL,
		[Nascimento] [date] NOT NULL,
		[LocalNascimento] [varchar](100) NOT NULL,
		[CNH] [varchar](20) NOT NULL,
		[CategoriaCNH] [varchar](3) NOT NULL,
		[OrgaoEmissorCNH] [varchar](10) NOT NULL,

		CONSTRAINT [PK_MotoristaBrasil_ID] PRIMARY KEY ([IDMotorista]),
		CONSTRAINT [FK_MotoristaBrasil_MotoristaID] FOREIGN KEY ([IDMotorista]) REFERENCES Motorista(ID)
	);
END

GO

--1.2) Criacao da tabela [MotoristaArgentina] caso ela NAO EXISTA
IF NOT EXISTS (SELECT 1 FROM SYS.TABLES WHERE NAME = 'MotoristaArgentina') BEGIN
	CREATE TABLE [MotoristaArgentina] (
		[IDMotorista] INT NOT NULL, -- FK Motorista (1 x 1)
		[DNI] [char](8) NOT NULL,
		[Apellido] [varchar](100) NOT NULL,
		[CUITTransportista] [char](11) NOT NULL,

		CONSTRAINT [PK_MotoristaArgentina_ID] PRIMARY KEY ([IDMotorista]),
		CONSTRAINT [FK_MotoristaArgentina_MotoristaID] FOREIGN KEY ([IDMotorista]) REFERENCES Motorista(ID)
	);
END

GO

--1.3) Inclusao da coluna "IdPais" na tabela [Transportadora] caso ela NAO EXISTA
IF COL_LENGTH('dbo.Transportadora', 'IdPais') IS NULL BEGIN
	ALTER TABLE dbo.Transportadora ADD IdPais INT NOT NULL DEFAULT 1;
	ALTER TABLE dbo.Transportadora ADD CONSTRAINT [FK_Transportadora_Pais] FOREIGN KEY (IdPais) REFERENCES Pais(id);
END

GO

-- 1.4) Inclusao da coluna "IdPais" na tabela [Cliente] caso ela NAO EXISTA
IF COL_LENGTH('dbo.Cliente', 'IdPais') IS NULL BEGIN
	ALTER TABLE dbo.Cliente ADD IdPais INT NOT NULL DEFAULT 1;
	ALTER TABLE dbo.Cliente ADD CONSTRAINT [FK_Cliente_Pais] FOREIGN KEY (IdPais) REFERENCES Pais(id);
END

GO

--1.5) Inclusão da coluna "IdPais" na tabela [Motorista] caso ela NÃO EXISTA
IF COL_LENGTH('dbo.Motorista', 'IdPais') IS NULL BEGIN
	ALTER TABLE dbo.Motorista ADD IdPais INT NULL;
	ALTER TABLE dbo.Motorista ADD CONSTRAINT [FK_Motorista_Pais] FOREIGN KEY (IdPais) REFERENCES Pais(id);
END

GO


/***********************************************************
* 2) INSERT E UPDATE DE REGISTROS
************************************************************/

--2.1) Inclusão da coluna "IdPais" na tabela [Motorista] caso ela NÃO EXISTA
IF COL_LENGTH('dbo.Motorista', 'IdPais') IS NOT NULL BEGIN
	UPDATE dbo.Motorista SET IdPais = 1 WHERE IdPais IS NULL;
END

GO

/***********************************************************
* 3) TRANSFER�NCIA DE DADOS ENTRE AS TABELAS REFATORADAS
************************************************************/

-- 3.1) Popula [MotoristaBrasil] com as informacoes existentes na tabela [Motorista]
IF (    (COL_LENGTH('dbo.Motorista', 'ID') IS NOT NULL)
	AND (COL_LENGTH('dbo.Motorista', 'IDMotorista') IS NOT NULL)
	AND (COL_LENGTH('dbo.Motorista', 'CPF') IS NOT NULL)
	AND (COL_LENGTH('dbo.Motorista', 'RG') IS NOT NULL)
	AND (COL_LENGTH('dbo.Motorista', 'OrgaoEmissor') IS NOT NULL)
	AND (COL_LENGTH('dbo.Motorista', 'Nascimento') IS NOT NULL)
	AND (COL_LENGTH('dbo.Motorista', 'LocalNascimento') IS NOT NULL)
	AND (COL_LENGTH('dbo.Motorista', 'CNH') IS NOT NULL)
	AND (COL_LENGTH('dbo.Motorista', 'CategoriaCNH') IS NOT NULL)
	AND (COL_LENGTH('dbo.Motorista', 'OrgaoEmissorCNH') IS NOT NULL))
BEGIN
	EXEC ('INSERT INTO dbo.MotoristaBrasil (IDMotorista, CPF, RG, OrgaoEmissor, Nascimento, LocalNascimento, CNH, CategoriaCNH, OrgaoEmissorCNH) 
		     SELECT ID, CPF, RG, OrgaoEmissor, Nascimento, LocalNascimento, CNH, CategoriaCNH, OrgaoEmissorCNH FROM Motorista');
END

GO

/***********************************************************
* 4) DROP DE OBJETOS 
************************************************************/

-- 4.1) Dropando as colunas que foram transferida da tabela Motorista para MotoristaBrasil
IF COL_LENGTH('dbo.Motorista', 'CPF') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Motorista] DROP COLUMN [CPF];
END

GO

IF COL_LENGTH('dbo.Motorista', 'RG') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Motorista] DROP COLUMN [RG];
END

GO

IF COL_LENGTH('dbo.Motorista', 'OrgaoEmissor') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Motorista] DROP COLUMN [OrgaoEmissor];
END

GO

IF COL_LENGTH('dbo.Motorista', 'Nascimento') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Motorista] DROP COLUMN [Nascimento];
END

GO

IF COL_LENGTH('dbo.Motorista', 'LocalNascimento') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Motorista] DROP COLUMN [LocalNascimento];
END

GO

IF COL_LENGTH('dbo.Motorista', 'CNH') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Motorista] DROP COLUMN [CNH];
END

GO

IF COL_LENGTH('dbo.Motorista', 'CategoriaCNH') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Motorista] DROP COLUMN [CategoriaCNH];
END

GO

IF COL_LENGTH('dbo.Motorista', 'OrgaoEmissorCNH') IS NOT NULL BEGIN
	ALTER TABLE [dbo].[Motorista] DROP COLUMN [OrgaoEmissorCNH];
END

GO

/***********************************************************
* 5) AJUSTES FINAIS
************************************************************/

-- 5.1) Alteração da coluna "IdPais" da tabela [Motorista] para NOT NULL
IF COL_LENGTH('dbo.Motorista', 'IdPais') IS NOT NULL BEGIN 
	ALTER TABLE [dbo].[Motorista] ALTER COLUMN [IdPais] INT NOT NULL
END

