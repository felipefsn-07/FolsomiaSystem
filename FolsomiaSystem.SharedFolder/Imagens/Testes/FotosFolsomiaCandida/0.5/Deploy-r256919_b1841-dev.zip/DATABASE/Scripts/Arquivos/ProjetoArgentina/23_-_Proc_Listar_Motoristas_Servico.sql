/***********************************************************
* 0) SELE��O DA BASE E CONFIGURA��ES INICAIS
************************************************************/
USE Unicad
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/***********************************************************
* 1) AJUSTE NA PROCEDURE
************************************************************/

--1.1) Verifica se j� existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Listar_Motoristas_Servico')
    DROP PROCEDURE [Proc_Listar_Motoristas_Servico];
GO

--1.2) Recriar a procedure ajustada
CREATE PROCEDURE [dbo].[Proc_Listar_Motoristas_Servico]
	@LinhaNegocio INT = NULL,
	@Operacao VARCHAR(3) = NULL,
	@CPF VARCHAR(11) = NULL,
	@Terminal VARCHAR(10) = NULL,
	@DataAtualizacao DATETIME
AS
BEGIN
DECLARE @StrSQL VARCHAR(8000)

SET @StrSQL = '
	SELECT 
		M.id,
		M.CPF,
		M.Nome,
		M.IDEmpresa AS LinhaNegocio,
		M.Operacao,
		M.RG,
		M.OrgaoEmissor,
		M.CNH,
		M.CategoriaCNH,
		M.OrgaoEmissorCNH AS emissorCNH,
		M.LocalNascimento,
		M.Telefone,
		M.Email,
		M.Observacao,
		M.DataAtualizazao AS DataAtualizacao,
		M.IDStatus AS Status,
		M.Nascimento,
		M.PIS,
		TreinamentoTeorico.Data AS DataTreinamentoTeorico,
		TreinamentoTeorico.TreinamentoAprovado AS IsTreinamentoTeoricoAprovado,
		TreinamentoTeorico.Usuario AS UsuarioTreinamentoTeorico,
		TreinamentoPratico.Usuario AS UsuarioTreinamentoPratico
	FROM VW_Motorista M 
	OUTER APPLY (
		SELECT TOP 1 H.Data, H.TreinamentoAprovado,H.Usuario FROM HistoricoTreinamentoTeoricoMotorista H WHERE H.IDMotorista = M.ID ORDER BY DATA DESC
	) AS TreinamentoTeorico
	OUTER APPLY (
		SELECT TOP 1 MT.DataValidade,MT.Usuario, T.Nome, T.Sigla  FROM MotoristaTreinamentoTerminal MT INNER JOIN Terminal T ON MT.IDTerminal = T.ID 
	WHERE MT.IDMotorista = M.ID '
	IF (@TERMINAL IS NOT NULL)
		SET @StrSQL += ' AND (T.Sigla = ''' + @Terminal + ''')'
	SET @StrSQL += ' ORDER BY DATA DESC
	) AS TreinamentoPratico
	INNER JOIN
	(
		SELECT cpf, Operacao, idEmpresa, MAX(REPLACE(REPLACE(REPLACE(REPLACE(idstatus,2,-8),1,-7),5,-6),3,-5)) AS Status  
		FROM VW_Motorista 
		
		WHERE  VW_Motorista.idstatus in (2,1,5,3) '
		IF (@LinhaNegocio IS NOT NULL)
			SET @StrSQL +=' AND (VW_Motorista.IDEmpresa = ' + CONVERT(VARCHAR(1),@LinhaNegocio) + ') '
		IF (@Operacao IS NOT NULL)
			SET @StrSQL +=' AND (VW_Motorista.Operacao = ''' + CONVERT(VARCHAR(3),@Operacao) + ''') '			
		IF (@CPF IS NOT NULL)
			SET @StrSQL +=' AND (VW_Motorista.CPF = ''' + CONVERT(VARCHAR(11),@CPF) + ''') '
		IF (@DataAtualizacao IS NOT NULL)
			SET @StrSQL += ' AND  (VW_Motorista.DataAtualizazao >= ''' + CONVERT(VARCHAR(19),@DataAtualizacao) + ''') '
		SET @StrSQL +='
		GROUP BY cpf,Operacao, Operacao, IDEmpresa		
	) A ON M.CPF = A.CPF AND M.Operacao = A.Operacao AND M.IDEmpresa = A.IDEmpresa	AND REPLACE(REPLACE(REPLACE(REPLACE(idstatus,2,-8),1,-7),5,-6),3,-5) = A.Status	'
	
	EXEC (@StrSQL)	
END
GO
