USE UniCad
GO

---------- Criação da coluna IDPais 
IF NOT EXISTS(
  SELECT *
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE 
    TABLE_NAME = 'TipoVeiculo'
    AND COLUMN_NAME = 'IDPais')
BEGIN
  ALTER TABLE TipoVeiculo
    ADD IDPais int NULL
END;
----------------------------------

GO

--------- Criação da FK_Pais_TipoVeiculo
IF (OBJECT_ID('dbo.FK_Pais_TipoVeiculo', 'F') IS NULL)
BEGIN
   ALTER TABLE TipoVeiculo
	ADD CONSTRAINT FK_Pais_TipoVeiculo FOREIGN KEY (IDPais) REFERENCES Pais(ID);
END
----------------------------------

GO

-------- Carga dos Tipos de Veículos com seus respectivos países
UPDATE TipoVeiculo SET IDPais = 1 WHERE ID in (1,2,3,4);

IF NOT EXISTS (SELECT 1 FROM TipoVeiculo WHERE Nome = 'Tractor')
INSERT INTO TipoVeiculo VALUES (5,'Tractor',2)

IF NOT EXISTS (SELECT 1 FROM TipoVeiculo WHERE Nome = 'Semiremolque')
INSERT INTO TipoVeiculo VALUES (6,'Semiremolque',2)
--------------------------------------

GO