﻿USE UniCad
GO

DECLARE @jobID int

SELECT
	@jobID = MAX(ID)
FROM
	dbo.Job

-- [CSON-2698 - Inicio]

IF NOT EXISTS(SELECT 1 FROM dbo.Job WHERE Nome = 'COMPOSICAO_DOCUMENTO_ALERTA') BEGIN
	INSERT INTO dbo.Job
		(ID, Nome, NrPeriodicidadeMinutos, DtUltimaExecucao, DtInicioJob, EmExecucao, StAtivo)
	VALUES
		(@jobID + 1, 'COMPOSICAO_DOCUMENTO_ALERTA', 1440, '2019-11-25', '2019-11-25', 1, 1);
END

IF NOT EXISTS(SELECT 1 FROM dbo.Job WHERE Nome = 'COMPOSICAO_DOCUMENTO_VENCIDO') BEGIN
	INSERT INTO dbo.Job
		(ID, Nome, NrPeriodicidadeMinutos, DtUltimaExecucao, DtInicioJob, EmExecucao, StAtivo)
	VALUES
		(@jobID + 2, 'COMPOSICAO_DOCUMENTO_VENCIDO', 1440, '2019-11-25', '2019-11-25', 1, 1);
END

IF NOT EXISTS(SELECT 1 FROM dbo.Job WHERE Nome = 'MOTORISTA_DOCUMENTO_ALERTA') BEGIN
	INSERT INTO dbo.Job
		(ID, Nome, NrPeriodicidadeMinutos, DtUltimaExecucao, DtInicioJob, EmExecucao, StAtivo)
	VALUES
		(@jobID + 3, 'MOTORISTA_DOCUMENTO_ALERTA', 1440, '2019-11-25', '2019-11-25', 1, 1);
END

IF NOT EXISTS(SELECT 1 FROM dbo.Job WHERE Nome = 'MOTORISTA_DOCUMENTO_VENCIDO') BEGIN
	INSERT INTO dbo.Job
		(ID, Nome, NrPeriodicidadeMinutos, DtUltimaExecucao, DtInicioJob, EmExecucao, StAtivo)
	VALUES
		(@jobID + 4, 'MOTORISTA_DOCUMENTO_VENCIDO', 1440, '2019-11-25', '2019-11-25', 1, 1);
END

-- [CSON-2698 - Fim]
