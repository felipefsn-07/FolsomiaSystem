USE UniCad

IF NOT EXISTS(SELECT 1 FROM sys.columns WHERE Name = 'LicenciaNacionalConducir'
          AND Object_ID = Object_ID('dbo.MotoristaArgentina'))
BEGIN
    ALTER TABLE MotoristaArgentina ADD LicenciaNacionalConducir varchar(20)
END


IF NOT EXISTS(SELECT 1 FROM sys.columns WHERE Name = 'LicenciaNacionalHabilitante'
          AND Object_ID = Object_ID('dbo.MotoristaArgentina'))
BEGIN
    ALTER TABLE MotoristaArgentina ADD LicenciaNacionalHabilitante varchar(20)
END