/***********************************************************
* 0) SELEÇÃO DA BASE E CONFIGURAÇÕES INICAIS
************************************************************/
USE Unicad
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/***********************************************************
* 1) AJUSTE NA PROCEDURE
************************************************************/

--1.1) Verifica se já existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Pesquisa_Composicao')
    DROP PROCEDURE [Proc_Pesquisa_Composicao];
GO

--1.2) Recriar a procedure ajustada
CREATE PROCEDURE  [dbo].[Proc_Pesquisa_Composicao]
	@IsCount BIT = 0,
	@PrimeiraPagina INT = NULL,
	@UltimaPagina INT = NULL,
	@IDEmpresa INT = NULL,
	@IDStatus INT = NULL,
	@Operacao VARCHAR(3) = NULL,
	@IDTipoComposicao INT = NULL,
	@Chamado VARCHAR(23) = NULL,
	@DataInicio DATE = NULL,
	@DataFim DATE = NULL,
	@Placa VARCHAR(10) = NULL,
	@IDTransportadora INT = NULL,
	@IDUsuarioTransportadora INT = NULL,	
	@IDCliente INT = NULL,
	@IDUsuarioCliente INT = NULL
AS
BEGIN
	--Utilização de query dinâmica conforme sugestão de melhoria do DBA
	DECLARE @StrSQL VARCHAR(8000)  
	DECLARE @DtInicio DATETIME = NULL
	DECLARE @DtFim DATETIME = NULL

	IF @DataInicio IS NOT NULL
		SET @DtInicio = @DataInicio
	IF @DataFim IS NOT NULL
		SET @DtFim = DATEADD(MS, -1, DATEADD(D, 1, CONVERT(DATETIME2, @DataFim)))	
	IF (@IsCount = 1) 
	BEGIN
		SET @strSQL = 
		'SELECT COUNT(*) AS Linhas '
	END
	ELSE
	BEGIN
		SET @StrSQL = 
		'SELECT 
			RowNum,
			ID, 
			EmpresaNome,
			Operacao, 				
			IDStatus,
			TipoComposicao,
			TipoComposicaoEixo,
			CategoriaVeiculo,
			Placa1,
			Placa2,
			Placa3,
			Placa4,
			CPFCNPJ,
			DataNascimento,
			RazaoSocial,
			DataAtualizacao,
			Observacao,
			CodigoEasyQuery,	
			CPFCNPJArrendamento,
			RazaoSocialArrendamento,
			LoginUsuario,
			PBTC,	
			UsuarioAlterouStatus,
			CAST(CASE WHEN MultiSeta1 <> 0 OR MultiSeta2 <> 0 OR MultiSeta3 <> 0 OR MultiSeta4 <> 0 THEN 1 ELSE 0 END AS BIT) AS Multiseta,
			CAST(CASE WHEN MultiCompartimento <> 0  THEN 1 ELSE 0 END AS BIT) AS MultiCompartimento'
	END
	SET @StrSQL +='
		 FROM (
			SELECT 
				ROW_NUMBER() OVER ( ORDER BY Comp.DataAtualizacao DESC ) AS RowNum,
				Comp.ID, 
				Emp.Nome AS EmpresaNome,
				Comp.Operacao, 				
				Comp.IDStatus,
				TC.Nome AS TipoComposicao,
				CE.Codigo AS TipoComposicaoEixo,
				CV.Nome AS CategoriaVeiculo,
				Placa1.PlacaVeiculo AS Placa1,
				Placa2.PlacaVeiculo AS Placa2,
				Placa3.PlacaVeiculo AS Placa3,
				Placa4.PlacaVeiculo AS Placa4,
				Comp.CPFCNPJ,
				Comp.DataNascimento,
				Comp.RazaoSocial,
				Comp.DataAtualizacao,
				Comp.Observacao,
				Comp.CodigoEasyQuery,	
				Comp.CPFCNPJArrendamento,
				Comp.RazaoSocialArrendamento,
				Comp.LoginUsuario,
				Comp.PBTC,
				Comp.UsuarioAlterouStatus,
				Placa1.MultiSeta AS MultiSeta1,
				Placa2.MultiSeta AS MultiSeta2,
				Placa3.MultiSeta AS MultiSeta3,
				Placa4.MultiSeta AS MultiSeta4,
				MultiCompartimento = CASE WHEN EXISTS
									(SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca1
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca2
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca3
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca4) THEN 1 ELSE 0 END
			FROM Composicao Comp WITH (NOLOCK) 
			INNER JOIN Empresa Emp WITH (NOLOCK) ON Comp.IDEmpresa = Emp.ID
			INNER JOIN TipoComposicao TC WITH (NOLOCK) ON Comp.IDTipoComposicao = TC.ID
			LEFT JOIN ComposicaoEixo CE WITH (NOLOCK) ON Comp.IDTipoComposicaoEixo = CE.ID
			INNER JOIN CategoriaVeiculo CV WITH (NOLOCK) ON Comp.IDCategoriaVeiculo = CV.ID
			LEFT JOIN VW_Placa Placa1 WITH (NOLOCK) ON Comp.IDPlaca1 = Placa1.ID
			LEFT JOIN VW_Placa Placa2 WITH (NOLOCK) ON Comp.IDPlaca2 = Placa2.ID
			LEFT JOIN VW_Placa Placa3 WITH (NOLOCK) ON Comp.IDPlaca3 = Placa3.ID
			LEFT JOIN VW_Placa Placa4 WITH (NOLOCK) ON Comp.IDPlaca4 = Placa4.ID'
	
	-- #JoinSegregacaoTransportadora
	-- Caso o usuario seja do tipo transportadora, valida o acesso na tabela que relaciona usuario X transportadora
	IF (@IDUsuarioTransportadora IS NOT NULL)
	BEGIN
		-- Cada Join abaixo tem a funcao de trazer a relacao de cada transportadora de cada placa com o usuario
		-- Como o usuario precisa ter acesso somente a uma das placas, a segregacao do acesso sera feita no where (ver #WhereSegregacaoTransportadora)
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT1 WITH (NOLOCK) ON Placa1.IDTransportadora = UT1.IDTransportadora AND UT1.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT2 WITH (NOLOCK) ON Placa2.IDTransportadora = UT2.IDTransportadora AND UT2.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT3 WITH (NOLOCK) ON Placa3.IDTransportadora = UT3.IDTransportadora AND UT3.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT4 WITH (NOLOCK) ON Placa4.IDTransportadora = UT4.IDTransportadora AND UT4.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT5 WITH (NOLOCK) ON Placa1.IDTransportadora2 = UT5.IDTransportadora AND UT5.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT6 WITH (NOLOCK) ON Placa2.IDTransportadora2 = UT6.IDTransportadora AND UT6.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT7 WITH (NOLOCK) ON Placa3.IDTransportadora2 = UT7.IDTransportadora AND UT7.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT8 WITH (NOLOCK) ON Placa4.IDTransportadora2 = UT8.IDTransportadora AND UT8.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
	END

	-- #JoinSegregacaoCliente
	-- Caso o usuario seja do tipo cliente ou o cliente tenha sido filtrado, valida a relacao entre o cliente e as placas e valida o acesso na tabela que relaciona usuario X cliente
	IF (@IDCliente IS NOT NULL) OR (@IDUsuarioCliente IS NOT NULL)
	BEGIN
		-- O join abaixo monta a relacao da placa com o cliente e, se necessario, do cliente com o usuario (para validar acesso).
		-- O mesmo join sera feito para as 4 placas.
		-- Como o usuario precisa ter acesso somente a uma das placas, a segregacao do acesso sera feita no where (ver #WhereSegregacaoCliente)
		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC1 ON Comp.IDPlaca1 = PC1.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC2 ON Comp.IDPlaca2 = PC2.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC3 ON Comp.IDPlaca3 = PC3.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC4 ON Comp.IDPlaca4 = PC4.IDPlaca'
	END

	SET @StrSQL += ' WHERE (Comp.IDStatus <> 3)'
			
	IF (@IDEmpresa IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDEmpresa = ' +  CONVERT(VARCHAR(1),@IDEmpresa) +')'
	IF (@IDStatus IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDStatus =  ' + CONVERT(VARCHAR(1),@IDStatus) + ')'
	IF (@Operacao IS NOT NULL)
		SET @StrSQL += ' AND (Comp.Operacao = '''  + @Operacao + ''')'
	IF (@IDTipoComposicao IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDTipoComposicao =  ' + CONVERT(VARCHAR(1),@IDTipoComposicao) +')'
	IF (@Chamado IS NOT NULL)
		SET @StrSQL += ' AND (Comp.CodigoEasyQuery LIKE ''%' +  @Chamado + '%'')'
	IF (@DtInicio IS NOT NULL)
		SET @StrSQL += ' AND (Comp.DataAtualizacao >= ''' + CONVERT(VARCHAR(19),@DtInicio) +''')'
	IF (@DtFim IS NOT NULL)
		SET @StrSQL += ' AND (Comp.DataAtualizacao  <= ''' + CONVERT(VARCHAR(19),@DtFim) +''')'
	IF (@Placa IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (Placa1.PlacaVeiculo =  ''' + @Placa +''''
		SET @StrSQL += '	OR Placa2.PlacaVeiculo = ''' + @Placa +''''
		SET @StrSQL += '	OR Placa3.PlacaVeiculo = ''' + @Placa +''''
		SET @StrSQL += '	OR Placa4.PlacaVeiculo = ''' + @Placa +''')'
	END
	IF (@IDTransportadora IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (Placa1.IDTransportadora =  ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa2.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa3.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa4.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora) +')'
	END

	-- #WhereSegregacaoTransportadora
	-- Se o usuario for do tipo cliente, exige que exista a relacao entre placa X transportadora
	-- Essa relacao esta no Join (ver #JoinSegregacaoTransportadora)
	IF(@IDUsuarioTransportadora IS NOT NULL)
	BEGIN
		-- O usuario precisa ter acesso a primeira transportadora de pelo menos uma das placas
		SET @StrSQL += ' AND (UT1.ID IS NOT NULL OR UT2.ID IS NOT NULL OR UT3.ID IS NOT NULL OR UT4.ID IS NOT NULL)'

		-- Se a placa for do tipo ambas (IDEmpresa = 3) o usuario também precisa ter acesso a segunda transportadora de pelo menos uma das placas
		SET @StrSQL += ' AND ((Comp.IDEmpresa = 3'
		SET @StrSQL += ' AND  (UT1.ID IS NOT NULL OR UT2.ID IS NOT NULL OR UT3.ID IS NOT NULL OR UT4.ID IS NOT NULL))'
		SET @StrSQL += '	OR Comp.IDEmpresa <> 3)'
	END

	-- #WhereSegregacaoCliente
	-- Se o cliente for filtrado ou for um usuario do tipo cliente, exige que exista a relacao entre placa X cliente X usuario seja valida.
	-- Essa relacao esta no Join (ver #JoinSegregacaoCliente)
	IF (@IDCliente IS NOT NULL OR @IDUsuarioCliente IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (PC1.IDPlaca IS NOT NULL OR PC2.IDPlaca IS NOT NULL OR PC3.IDPlaca IS NOT NULL OR PC4.IDPlaca IS NOT NULL)'
	END

	SET @StrSQL += ')  AS Composicao '
	
	IF (@PrimeiraPagina IS NOT NULL)
		SET @StrSQL += 'WHERE Composicao.RowNum > ' + CONVERT(VARCHAR(5),@PrimeiraPagina) 
	IF (@UltimaPagina IS NOT NULL)
		SET @StrSQL += 'AND Composicao.RowNum <= '  + CONVERT(VARCHAR(5),@UltimaPagina)

	EXEC (@StrSQL)
END
GO