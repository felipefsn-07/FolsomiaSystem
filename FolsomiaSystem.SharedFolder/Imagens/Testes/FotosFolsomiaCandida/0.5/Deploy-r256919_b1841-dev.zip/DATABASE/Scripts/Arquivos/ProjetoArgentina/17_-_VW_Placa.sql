/***********************************************************
* 0) SELECAO DA BASE
************************************************************/
USE [Unicad]
GO

/***********************************************************
* 1) CRIACAO DA VIEW PRINCIPAL
************************************************************/

--1.1) Se a VIEW ja existir, dropa a mesma
IF EXISTS(select 1 FROM sys.views where name = 'VW_Placa')
	DROP VIEW [VW_Placa]

GO

--1.2) Cria a VIEW
CREATE VIEW [dbo].[VW_Placa] 
AS
	SELECT        Placa.ID, Placa.PlacaVeiculo, Placa.Operacao, Placa.IDTipoVeiculo, Placa.IDTransportadora, Placa.Marca, Placa.Modelo, Placa.Chassi, Placa.AnoFabricacao, Placa.AnoModelo, Placa.Cor, Placa.TipoRastreador, 
                         Placa.NumeroAntena, Placa.Versao, Placa.CameraMonitoramento, Placa.BombaDescarga, Placa.Tara, Placa.NumeroEixos, Placa.EixosPneusDuplos, Placa.NumeroEixosPneusDuplos, Placa.EixosDistanciados, 
                         Placa.NumeroEixosDistanciados, Placa.IDTipoProduto, Placa.MultiSeta, Placa.IDTipoCarregamento, Placa.DataNascimento, Placa.RazaoSocial, Placa.IDCategoriaVeiculo, Placa.DataAtualizacao, Placa.Observacao, Placa.Status, 
                         Placa.Principal, Placa.PossuiAbs, Placa.Anexo, Placa.IDTransportadora2, Placa.IdPais, PlacaBrasil.Renavam, PlacaBrasil.CPFCNPJ, PlacaBrasil.IDEstado, PlacaBrasil.Cidade, PlacaArgentina.CUIT, PlacaArgentina.PBTC, 
                         PlacaArgentina.Material, PlacaArgentina.NrMotor, PlacaArgentina.SatelitalMarca, PlacaArgentina.SatelitalModelo, PlacaArgentina.SatelitalNrInterno, PlacaArgentina.SatelitalEmpresa, PlacaArgentina.Vencimento, 
                         PlacaArgentina.Potencia
FROM            Placa LEFT OUTER JOIN
                         PlacaArgentina ON Placa.ID = PlacaArgentina.IDPlaca LEFT OUTER JOIN
                         PlacaBrasil ON Placa.ID = PlacaBrasil.IDPlaca


GO
