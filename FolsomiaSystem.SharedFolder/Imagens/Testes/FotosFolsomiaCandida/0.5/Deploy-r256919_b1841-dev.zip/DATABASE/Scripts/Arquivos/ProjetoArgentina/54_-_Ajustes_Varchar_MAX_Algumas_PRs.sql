/***********************************************************
* 0) SELE��O DA BASE E CONFIGURA��ES INICAIS
************************************************************/
USE [UniCad]
GO
/****** Object:  StoredProcedure [dbo].[Proc_Pesquisa_Motorista]    Script Date: 10/23/2019 3:52:49 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/***********************************************************
* 1) AJUSTE NA PROCEDURE [Proc_Pesquisa_Motorista]
************************************************************/

--1.1) Verifica se j� existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Pesquisa_Motorista')
    DROP PROCEDURE [Proc_Pesquisa_Motorista];
GO

--1.2) Recriar a procedure ajustada
CREATE PROCEDURE  [dbo].[Proc_Pesquisa_Motorista]
	@IsCount BIT = 0,
	@IsExportar BIT = 0,
	@PrimeiraPagina INT = NULL,
	@UltimaPagina INT = NULL,
	@Nome VARCHAR(100) = NULL,
	@IDEmpresa INT = NULL,
	@IDStatus INT = NULL,
	@Operacao VARCHAR(10) = NULL,
	@IsAtivo BIT = NULL,
	@CNH VARCHAR(23) = NULL,
	@CPF VARCHAR(13) = NULL,
	@RG VARCHAR(18) = NULL,
	@DataInicio DATETIME = NULL,
	@DataFim DATETIME = NULL,
	@IDUsuarioCliente INT = NULL,
	@IDUsuarioTransportadora INT = NULL,
	@Chamado VARCHAR(23) = NULL,
	@IDTransportadora INT = NULL,
	@IdPais INT = NULL,
	@DNI VARCHAR(8) = NULL,
	@Apellido VARCHAR(100) = NULL,
    @IDCliente INT = NULL

AS
BEGIN

	DECLARE @StrSQL VARCHAR(max)
	DECLARE @StrSQLSelect VARCHAR(max)
	IF (@Nome IS NOT NULL)
		SET @Nome = '%' + @Nome + '%'
	IF (@CNH IS NOT NULL)
		SET @CNH = '%' + @CNH + '%'
	IF (@CPF IS NOT NULL)
		SET @CPF = '%' + @CPF + '%'
	IF (@DNI IS NOT NULL)
		SET @DNI = '%' + @DNI + '%'
	IF (@RG IS NOT NULL)
		SET @RG = '%' + @RG + '%'
	IF (@Apellido IS NOT NULL)
		SET @Apellido = '%' + @Apellido + '%'
	IF (@Chamado IS NOT NULL)
		SET @Chamado = '%' + @Chamado + '%'
	IF @DataFim IS NOT NULL
		SET @DataFim = DATEADD(MS, -1, DATEADD(D, 1, CONVERT(DATETIME2, @DataFim)))

	
	IF (@IsExportar = 0)
	BEGIN
		IF (@IsCount = 1) 
		BEGIN
			SET @strSQL = 
			'SELECT COUNT(*) AS Linhas '
		END
		ELSE
			SET @StrSQL = 
			'SELECT
				RowNum,
				Nome,
				Anexo,
				Ativo,
				CategoriaCNH,
				CNH ,
				CodigoEasyQuery,
				CPF,
				DNI,
			    Apellido,
				CUITTransportista,
				DataAtualizazao,
				Email,
				ID,
				IDEmpresa,
				IdPais,
				IDMotorista,
				IDStatus,
				IDTransportadora,
				LocalNascimento,
				LoginUsuario,
				Nascimento,
				Operacao,
				OrgaoEmissor,
				OrgaoEmissorCNH,
				RG,
				Telefone,
				Justificativa,
				Observacao,
				UsuarioAlterouStatus '
		SET @strSQL += '
			FROM
			(
				SELECT  
					ROW_NUMBER() OVER (ORDER BY M.DataAtualizazao DESC) AS RowNum,
					M.Nome,
					M.Anexo,
					M.Ativo,
					M.CategoriaCNH,
					M.CNH ,
					M.CodigoEasyQuery,
					M.CPF,
					M.DNI,
					M.Apellido,
					M.CUITTransportista,
					M.DataAtualizazao,
					M.Email,
					M.ID,
					M.IDEmpresa,
					M.IdPais,
					M.IDMotorista,
					M.IDStatus,
					M.IDTransportadora,
					M.LocalNascimento,
					M.LoginUsuario,
					M.Nascimento,
					M.Operacao,
					M.OrgaoEmissor,
					M.OrgaoEmissorCNH,
					M.RG,
					M.Telefone,
					M.Justificativa,
					M.Observacao,
					M.UsuarioAlterouStatus
					FROM VW_Motorista M
					LEFT JOIN UsuarioTransportadora UT ON M.IDTransportadora = UT.IDTransportadora
					LEFT JOIN MotoristaCliente MC on M.ID = MC.IDMotorista
					LEFT JOIN UsuarioCliente UC on MC.IDCliente = UC.IDCliente
					WHERE (IDStatus != 3) '
	END
	ELSE
	BEGIN
		--exporta��o
		DECLARE @cols AS NVARCHAR(400)
		SET @cols = STUFF((SELECT distinct ',' + QUOTENAME(t.Sigla) 
				FROM TipoDocumento T WHERE T.TipoCadastro = 2 
				FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(400)') 
			,1,1,'')

		SET @StrSQLSelect =
			'SELECT '+ @cols + ',
				Nome,
				Anexo,
				Ativo,
				CategoriaCNH,
				CNHMotorista ,
				CodigoEasyQuery,
				CPF,
				DNI,
				CUITTransportista,
				Apellido,
				DataAtualizazao,
				Email,
				ID,
				IDEmpresa,
				IDPais,
				IDMotorista,
				IDStatus,
				IDTransportadora,
				LocalNascimento,
				LoginUsuario,
				Nascimento,
				Operacao,
				OrgaoEmissor,
				OrgaoEmissorCNH,
				RG,
				Telefone,
				Justificativa,
				Observacao, 
				IBM,
				NomeCliente,
				DataValidadeTreinamentoTeorico,
				TreinamentoAprovadoTreinamentoTeorico,
				DataValidadeTreinamentoPratico,
				TerminalTreinamentoPratico,
				PISCampo,
				UsuarioAlterouStatus 
				FROM
				(
					SELECT  
						MT.Nome,
						MT.Anexo,
						MT.Ativo,
						MT.CategoriaCNH,
						MT.CNHMotorista ,
						MT.CodigoEasyQuery,
						MT.CPF,
						MT.DNI,
						MT.CUITTransportista,
						MT.Apellido,
						MT.DataAtualizazao,
						MT.Email,
						MT.ID,
						MT.IDEmpresa,
						MT.IdPais,
						MT.IDMotorista,
						MT.IDStatus,
						MT.IDTransportadora,
						MT.LocalNascimento,
						MT.LoginUsuario,
						MT.Nascimento,
						MT.Operacao,
						MT.OrgaoEmissor,
						MT.OrgaoEmissorCNH,
						MT.RG,
						MT.Telefone,
						MT.Justificativa,
						MT.Observacao,
						MT.IBM,
						MT.NomeCliente,
						MT.DataVencimento as DataVencimento,
						MT.Sigla,
						MT.DataValidadeTreinamentoTeorico,
						MT.TreinamentoAprovadoTreinamentoTeorico,
						MT.DataValidadeTreinamentoPratico,
						MT.TerminalTreinamentoPratico,
						MT.IDUsuarioTransportadora,
						MT.IDUsuarioCliente,
						MT.PIS AS PisCampo,
						MT.UsuarioAlterouStatus 
						FROM(
							SELECT  MO.Nome,
								MO.Anexo,
								MO.Ativo,
								MO.CategoriaCNH,
								MO.CNH AS CNHMotorista,
								MO.CodigoEasyQuery,
								MO.CPF,
								MO.DNI,
								MO.CUITTransportista,
								MO.Apellido,
								MO.DataAtualizazao,
								MO.Email,
								MO.ID,
								MO.IDEmpresa,
								MO.IdPais,
								MO.IDMotorista,
								MO.IDStatus,
								MO.IDTransportadora,
								MO.LocalNascimento,
								MO.LoginUsuario,
								MO.Nascimento,
								MO.Operacao,
								MO.OrgaoEmissor,
								MO.OrgaoEmissorCNH,
								MO.RG,
								MO.Telefone,
								MO.Justificativa,
								MO.Observacao,
								MO.PIS,
								MO.UsuarioAlterouStatus,
								T.IBM,	
								T.RazaoSocial as NomeCliente,				
								PC.DataVencimento as DataVencimento,
								TD.Sigla,
								TreinamentoTeorico.Data AS DataValidadeTreinamentoTeorico,
								TreinamentoTeorico.TreinamentoAprovado AS TreinamentoAprovadoTreinamentoTeorico,
								TreinamentoPratico.DataValidade AS DataValidadeTreinamentoPratico,
								TreinamentoPratico.Nome AS TerminalTreinamentoPratico,
								UT.IDUsuario AS IDUsuarioTransportadora,
								NULL AS IDUsuarioCliente '
							Set @StrSQL =
							'FROM VW_Motorista MO 
							INNER JOIN Transportadora t on MO.IDTransportadora = t.id
							LEFT JOIN UsuarioTransportadora UT ON MO.IDTransportadora = UT.IDTransportadora
							INNER JOIN MotoristaDocumento PC ON MO.ID = PC.IDMotorista
							INNER JOIN TipoDocumento TD ON PC.IDTipoDocumento = TD.ID
							OUTER APPLY (
								SELECT TOP 1 H.Data, H.TreinamentoAprovado FROM HistoricoTreinamentoTeoricoMotorista H WHERE H.IDMotorista = MO.ID ORDER BY DATA DESC) AS TreinamentoTeorico
							OUTER APPLY (
								SELECT TOP 1 MT.DataValidade, T.Nome  FROM MotoristaTreinamentoTerminal MT INNER JOIN Terminal T ON MT.IDTerminal = T.ID 
									WHERE MT.IDMotorista = MO.ID ORDER BY DATA DESC) AS TreinamentoPratico
							WHERE MO.Operacao = ''CIF''
							UNION 
							SELECT  MO.Nome,
									MO.Anexo,
									MO.Ativo,
									MO.CategoriaCNH,
									MO.CNH AS CNHMotorista,
									MO.CodigoEasyQuery,
									MO.CPF,
									MO.DNI,
									MO.CUITTransportista,
									MO.Apellido,
									MO.DataAtualizazao,
									MO.Email,
									MO.ID,
									MO.IDEmpresa,
									MO.IdPais,
									MO.IDMotorista,
									MO.IDStatus,
									MO.IDTransportadora,
									MO.LocalNascimento,
									MO.LoginUsuario,
									MO.Nascimento,
									MO.Operacao,
									MO.OrgaoEmissor,
									MO.OrgaoEmissorCNH,
									MO.RG,
									MO.Telefone,
									MO.Justificativa,
									MO.Observacao,
									MO.PIS,
									MO.UsuarioAlterouStatus,
									CLI.IBM,
									CLI.RazaoSocial as NomeCliente,	
									PC.DataVencimento as DataVencimento,
									TD.Sigla,
									TreinamentoTeorico.Data AS DataValidadeTreinamentoTeorico,
									TreinamentoTeorico.TreinamentoAprovado AS TreinamentoAprovadoTreinamentoTeorico,
									TreinamentoPratico.DataValidade AS DataValidadeTreinamentoPratico,
									TreinamentoPratico.Nome AS TerminalTreinamentoPratico,
									NULL AS IDUsuarioTransportadora,
									UC.IDUsuario AS IDUsuarioCliente
							FROM VW_Motorista MO 
							INNER JOIN MotoristaCliente MC on MO.id = MC.idMotorista
							INNER JOIN Cliente cli on MC.IDCliente = cli.ID
							LEFT JOIN UsuarioCliente UC on MC.IDCliente = UC.IDCliente
							INNER JOIN MotoristaDocumento PC ON MO.ID = PC.IDMotorista
							INNER JOIN TipoDocumento TD ON PC.IDTipoDocumento = TD.ID
							OUTER APPLY (
								SELECT TOP 1 H.Data, H.TreinamentoAprovado FROM HistoricoTreinamentoTeoricoMotorista H WHERE H.IDMotorista = MO.ID ORDER BY DATA DESC) AS TreinamentoTeorico
							OUTER APPLY (
								SELECT TOP 1 MT.DataValidade, T.Nome  FROM MotoristaTreinamentoTerminal MT INNER JOIN Terminal T ON MT.IDTerminal = T.ID 
									WHERE MT.IDMotorista = MO.ID ORDER BY DATA DESC) AS TreinamentoPratico
							WHERE MO.Operacao = ''FOB''							
						) MT 
					) M 		
			PIVOT
			(
				MAX(M.DataVencimento)
				FOR M.Sigla IN (' + @cols + ')
			) P  WHERE (IDStatus != 3) '
	END		
		IF (@Nome IS NOT NULL)
			SET @StrSQL += ' AND (Nome LIKE ''' +  CONVERT(VARCHAR(100),@Nome) +''') '
		IF (@IDEmpresa IS NOT NULL)
			SET @StrSQL += ' AND (IDEmpresa = ' + CONVERT(VARCHAR(1),@IDEmpresa) +') '
		IF (@IdPais IS NOT NULL)
			IF(@IsExportar = 0)
				SET @StrSQL += ' AND (M.IdPais = ' + CONVERT(VARCHAR(1),@IdPais) +') '
			ELSE
				SET @StrSQL += ' AND (IDPais = ' + CONVERT(VARCHAR(1), @IdPais) + ') '
		IF (@IDStatus IS NOT NULL)
			SET @StrSQL += ' AND (IDStatus = ' + CONVERT(VARCHAR(1),@IDStatus) +') '
		IF (@Operacao IS NOT NULL)
			SET @StrSQL += ' AND (Operacao = ''' + @Operacao +''') '
		IF (@IsAtivo IS NOT NULL)
			SET @StrSQL += ' AND (Ativo = ' + CONVERT(VARCHAR(1),@IsAtivo) +') '
		IF (@CNH IS NOT NULL)
			IF (@IsExportar = 0)
				SET @StrSQL += 'AND (CNH LIKE ''' +@CNH +''') '
			ELSE
				SET @StrSQL += 'AND (CNHMotorista LIKE ''' +@CNH +''') '
		IF (@CPF IS NOT NULL)
			SET @StrSQL += 'AND (CPF LIKE ''' + @CPF +''') '
		IF (@RG IS NOT NULL)
			SET @StrSQL += 'AND (RG LIKE ''' + @RG +''') '
		IF (@DNI IS NOT NULL)
			SET @StrSQL += 'AND (DNI LIKE ''' + @DNI +''') '
		IF (@Apellido IS NOT NULL)
			SET @StrSQL += 'AND (Apellido LIKE ''' + @Apellido +''') '
		IF (@Chamado IS NOT NULL)
			SET @StrSQL += 'AND (CodigoEasyQuery LIKE ''' + @Chamado +''') '
		IF (@IDUsuarioTransportadora IS NOT NULL)
			IF (@IsExportar = 0)
				SET @StrSQL += 'AND (UT.IDUsuario = ' + CONVERT(VARCHAR(8),@IDUsuarioTransportadora) +') '
			ELSE
				SET @StrSQL += 'AND (IDUsuarioTransportadora = ' + CONVERT(VARCHAR(8),@IDUsuarioTransportadora) +') '
		IF (@IDUsuarioCliente IS NOT NULL)
			IF (@IsExportar = 0)
				SET @StrSQL += 'AND (UC.IDUsuario = ' + CONVERT(VARCHAR(8),@IDUsuarioCliente) +') '
				
			ELSE
				SET @StrSQL += 'AND (IDUsuarioCliente = ' + CONVERT(VARCHAR(8),@IDUsuarioCliente) +') '
		IF (@DataInicio IS NOT NULL)
			SET @StrSQL += ' AND (DataAtualizazao >= ''' + CONVERT(VARCHAR(19),@DataInicio) +''') '
		IF (@DataFim IS NOT NULL)
			SET @StrSQL += ' AND (DataAtualizazao  <= ''' + CONVERT(VARCHAR(19),@DataFim) +''') '
		IF (@IDTransportadora IS NOT NULL)
			IF (@IsExportar = 0)
				SET @StrSQL += ' AND (M.IDTransportadora =  ' + CONVERT(VARCHAR(10),@IDTransportadora) +')'
			ELSE
				SET @StrSQL += ' AND (IDTransportadora =  ' + CONVERT(VARCHAR(10),@IDTransportadora) +')'
		IF (@IDCliente IS NOT NULL)
				SET @StrSQL += ' AND (MC.IDCliente =  ' + CONVERT(VARCHAR(10),@IDCliente) +')'

		IF (@IsExportar = 0)	
		BEGIN	
			SET @StrSQL += '
			GROUP BY
				M.Nome,
				M.Anexo,
				M.Ativo,
				M.CategoriaCNH,
				M.CNH,
				M.CodigoEasyQuery,
				M.CPF,
				M.DNI,
				M.Apellido,
				M.CUITTransportista,
				M.DataAtualizazao,
				M.Email,
				M.ID,
				M.IDEmpresa,
				M.IdPais,
				M.IDMotorista,
				M.IDStatus,
				M.IDTransportadora,
				M.LocalNascimento,
				M.LoginUsuario,
				M.Nascimento,
				M.Operacao,
				M.OrgaoEmissor,
				M.OrgaoEmissorCNH,
				M.RG,
				M.Telefone,
				M.Justificativa,
				M.Observacao,
				M.UsuarioAlterouStatus '	
		END 
		ELSE
		BEGIN
			SET @StrSQL += '
				GROUP BY 
				' +@cols + ',
				Nome,
				Anexo,
				Ativo,
				CategoriaCNH,
				CNHMotorista ,
				CodigoEasyQuery,
				CPF,
				DNI,
				Apellido,
				CUITTransportista,
				DataAtualizazao,
				Email,
				ID,
				IDEmpresa,
				IdPais,
				IDMotorista,
				IDStatus,
				IDTransportadora,
				LocalNascimento,
				LoginUsuario,
				Nascimento,
				Operacao,
				OrgaoEmissor,
				OrgaoEmissorCNH,
				RG,
				Telefone,
				Justificativa,
				Observacao, 
				IBM,
				PISCampo,
				NomeCliente,
				DataValidadeTreinamentoTeorico,
				TreinamentoAprovadoTreinamentoTeorico,
				DataValidadeTreinamentoPratico,
				TerminalTreinamentoPratico,
				UsuarioAlterouStatus
				ORDER BY DataAtualizazao DESC '
		END
	IF (@IsExportar = 0)
	BEGIN
	SET @StrSQL += ' ) VW_Motorista'
	IF (@PrimeiraPagina IS NOT NULL)
		SET @StrSQL += ' WHERE VW_Motorista.RowNum > ' + CONVERT(VARCHAR(5),@PrimeiraPagina) 
	IF (@UltimaPagina IS NOT NULL)
		SET @StrSQL += ' AND VW_Motorista.RowNum <= '  + CONVERT(VARCHAR(5),@UltimaPagina)	
		EXEC (@StrSQL)
	END
	ELSE
		EXEC (@StrSQLSelect + @StrSQL)
END
GO

/***********************************************************
* 2) AJUSTE NA PROCEDURE [Proc_Pesquisa_Composicao_Excel]
************************************************************/

--2.1) Verifica se j� existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Pesquisa_Composicao_Excel')
    DROP PROCEDURE [Proc_Pesquisa_Composicao_Excel];
GO

--2.2) Recriar a procedure ajustada
CREATE PROCEDURE  [dbo].[Proc_Pesquisa_Composicao_Excel]
	@IsCount BIT = 0,
	@PrimeiraPagina INT = NULL,
	@UltimaPagina INT = NULL,
	@IDEmpresa INT = NULL,
	@IDStatus INT = NULL,
	@Operacao VARCHAR(3) = NULL,
	@IDTipoComposicao INT = NULL,
	@Chamado VARCHAR(23) = NULL,
	@DataInicio DATE = NULL,
	@DataFim DATE = NULL,
	@Placa VARCHAR(10) = NULL,
	@IDTransportadora INT = NULL,
	@IDUsuarioTransportadora INT = NULL,
	@IDCliente INT = NULL,
	@IDUsuarioCliente INT = NULL,
	@IdPais INT = 1
AS
BEGIN
	--Utilização de query dinâmica conforme sugestão de melhoria do DBA
	DECLARE @StrSQL VARCHAR(max)  
	DECLARE @DtInicio DATETIME = NULL
	DECLARE @DtFim DATETIME = NULL

	IF @DataInicio IS NOT NULL
		SET @DtInicio = @DataInicio
	IF @DataFim IS NOT NULL
		SET @DtFim = DATEADD(MS, -1, DATEADD(D, 1, CONVERT(DATETIME2, @DataFim)))	
	IF (@IsCount = 1) 
	BEGIN
		SET @strSQL = 
		'SELECT COUNT(*) AS Linhas '
	END
	ELSE
	BEGIN
		SET @StrSQL = 
		'SELECT 
			RowNum,
			ID, 
			EmpresaNome,
			Operacao, 				
			IDStatus,
			TipoComposicao,
			TipoComposicaoEixo,
			CategoriaVeiculo,
			CategoriaVeiculoEs,
			Placa1,
			Placa2,
			Placa3,
			Placa4,
			CPFCNPJ,
			DataNascimento,
			RazaoSocial,
			DataAtualizacao,
			Observacao,
			CodigoEasyQuery,	
			CPFCNPJArrendamento,
			RazaoSocialArrendamento,
			LoginUsuario,
			PBTC,		
			CAST(CASE WHEN MultiSeta1 <> 0 OR MultiSeta2 <> 0 OR MultiSeta3 <> 0 OR MultiSeta4 <> 0 THEN 1 ELSE 0 END AS BIT) AS Multiseta,
			CAST(CASE WHEN MultiCompartimento <> 0  THEN 1 ELSE 0 END AS BIT) AS MultiCompartimento,
			NumCompartimentos,
			Bloqueado,
			CheckListData,
			CheckListAprovado,
			CapacidadeMinima,
			CapacidadeMaxima,
			UsuarioAlterouStatus '
			
	END
	SET @StrSQL +='
		 FROM (
			SELECT 
				ROW_NUMBER() OVER ( ORDER BY Comp.DataAtualizacao DESC ) AS RowNum,
				Comp.ID, 
				Emp.Nome AS EmpresaNome,
				Comp.Operacao, 				
				Comp.IDStatus,
				TC.Nome AS TipoComposicao,
				CE.Codigo AS TipoComposicaoEixo,
				CV.Nome AS CategoriaVeiculo,
				CV.NomeEs AS CategoriaVeiculoEs,
				Placa1.PlacaVeiculo AS Placa1,
				Placa2.PlacaVeiculo AS Placa2,
				Placa3.PlacaVeiculo AS Placa3,
				Placa4.PlacaVeiculo AS Placa4,
				Comp.CPFCNPJ,
				Comp.DataNascimento,
				Comp.RazaoSocial,
				Comp.DataAtualizacao,
				Comp.Observacao,
				Comp.CodigoEasyQuery,	
				Comp.CPFCNPJArrendamento,
				Comp.RazaoSocialArrendamento,
				Comp.LoginUsuario,
				Comp.PBTC,
				Comp.IdPais,
				Comp.UsuarioAlterouStatus,
				Placa1.MultiSeta AS MultiSeta1,
				Placa2.MultiSeta AS MultiSeta2,
				Placa3.MultiSeta AS MultiSeta3,
				Placa4.MultiSeta AS MultiSeta4,
				MultiCompartimento = CASE WHEN EXISTS
									(SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca1
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca2
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca3
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca4) THEN 1 ELSE 0 END,
				(ISNULL(SNC1.NumCompartimentos, 0) + ISNULL(SNC2.NumCompartimentos, 0) + ISNULL(SNC3.NumCompartimentos, 0) + ISNULL(SNC4.NumCompartimentos, 0)) AS NumCompartimentos,
				CASE 
					WHEN Comp.IDStatus = 5 THEN convert(bit, 1)
					ELSE convert(bit, 0)
				END AS Bloqueado,
				CC.Data CheckListData,
				CC.Aprovado CheckListAprovado,
				ISNULL(VWSM1.SomaVolumeMinimo, 0) + ISNULL(VWSM2.SomaVolumeMinimo, 0) + ISNULL(VWSM3.SomaVolumeMinimo, 0) + ISNULL(VWSM4.SomaVolumeMinimo, 0) AS CapacidadeMinima,
				ISNULL(VWMA1.SomaVolumeMaximo, 0) + ISNULL(VWMA2.SomaVolumeMaximo, 0) + ISNULL(VWMA3.SomaVolumeMaximo, 0) + ISNULL(VWMA4.SomaVolumeMaximo, 0) AS CapacidadeMaxima
			FROM Composicao Comp WITH (NOLOCK) 
			INNER JOIN Empresa Emp WITH (NOLOCK) ON Comp.IDEmpresa = Emp.ID
			INNER JOIN TipoComposicao TC WITH (NOLOCK) ON Comp.IDTipoComposicao = TC.ID
			LEFT JOIN ComposicaoEixo CE WITH (NOLOCK) ON Comp.IDTipoComposicaoEixo = CE.ID
			INNER JOIN CategoriaVeiculo CV WITH (NOLOCK) ON Comp.IDCategoriaVeiculo = CV.ID
			LEFT JOIN VW_Placa Placa1 WITH (NOLOCK) ON Comp.IDPlaca1 = Placa1.ID
			LEFT JOIN VW_Placa Placa2 WITH (NOLOCK) ON Comp.IDPlaca2 = Placa2.ID
			LEFT JOIN VW_Placa Placa3 WITH (NOLOCK) ON Comp.IDPlaca3 = Placa3.ID
			LEFT JOIN VW_Placa Placa4 WITH (NOLOCK) ON Comp.IDPlaca4 = Placa4.ID
			LEFT JOIN VW_SelecionaNumCompartimentos SNC1 ON SNC1.IdPlaca = IDPlaca1
			LEFT JOIN VW_SelecionaNumCompartimentos SNC2 ON SNC2.IdPlaca = IDPlaca2
			LEFT JOIN VW_SelecionaNumCompartimentos SNC3 ON SNC3.IdPlaca = IDPlaca3
			LEFT JOIN VW_SelecionaNumCompartimentos SNC4 ON SNC4.IdPlaca = IDPlaca4
			LEFT JOIN (
				SELECT Top 1
				IDComposicao, 
				DataCadastro,
				Data,
				Aprovado 
				FROM ChecklistComposicao WITH (NOLOCK)
				Order by DataCadastro Desc
			) CC ON CC.IDComposicao = Comp.ID
			LEFT JOIN VW_SomaVolumeMinimoPlaca VWSM1 on VWSM1.IdPlaca = IDPlaca1
			LEFT JOIN VW_SomaVolumeMinimoPlaca VWSM2 on VWSM2.IdPlaca = IDPlaca2
			LEFT JOIN VW_SomaVolumeMinimoPlaca VWSM3 on VWSM3.IdPlaca = IDPlaca3
			LEFT JOIN VW_SomaVolumeMinimoPlaca VWSM4 on VWSM4.IdPlaca = IDPlaca4
			LEFT JOIN VW_SomaVolumeMaximoPlaca VWMA1 on VWMA1.IdPlaca = IDPlaca1
			LEFT JOIN VW_SomaVolumeMaximoPlaca VWMA2 on VWMA2.IdPlaca = IDPlaca2
			LEFT JOIN VW_SomaVolumeMaximoPlaca VWMA3 on VWMA3.IdPlaca = IDPlaca3
			LEFT JOIN VW_SomaVolumeMaximoPlaca VWMA4 on VWMA4.IdPlaca = IDPlaca4'
	
	-- #JoinSegregacaoTransportadora
	-- Caso o usuario seja do tipo transportadora, valida o acesso na tabela que relaciona usuario X transportadora
	IF (@IDUsuarioTransportadora IS NOT NULL)
	BEGIN
		-- Cada Join abaixo tem a funcao de trazer a relacao de cada transportadora de cada placa com o usuario
		-- Como o usuario precisa ter acesso somente a uma das placas, a segregacao do acesso sera feita no where (ver #WhereSegregacaoTransportadora)
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT1 WITH (NOLOCK) ON Placa1.IDTransportadora = UT1.IDTransportadora AND UT1.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT2 WITH (NOLOCK) ON Placa2.IDTransportadora = UT2.IDTransportadora AND UT2.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT3 WITH (NOLOCK) ON Placa3.IDTransportadora = UT3.IDTransportadora AND UT3.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT4 WITH (NOLOCK) ON Placa4.IDTransportadora = UT4.IDTransportadora AND UT4.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT5 WITH (NOLOCK) ON Placa1.IDTransportadora2 = UT5.IDTransportadora AND UT5.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT6 WITH (NOLOCK) ON Placa2.IDTransportadora2 = UT6.IDTransportadora AND UT6.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT7 WITH (NOLOCK) ON Placa3.IDTransportadora2 = UT7.IDTransportadora AND UT7.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT8 WITH (NOLOCK) ON Placa4.IDTransportadora2 = UT8.IDTransportadora AND UT8.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
	END

	-- #JoinSegregacaoCliente
	-- Caso o usuario seja do tipo cliente ou o cliente tenha sido filtrado, valida a relacao entre o cliente e as placas e valida o acesso na tabela que relaciona usuario X cliente
	IF (@IDCliente IS NOT NULL) OR (@IDUsuarioCliente IS NOT NULL)
	BEGIN
		-- O join abaixo monta a relacao da placa com o cliente e, se necessario, do cliente com o usuario (para validar acesso).
		-- O mesmo join sera feito para as 4 placas.
		-- Como o usuario precisa ter acesso somente a uma das placas, a segregacao do acesso sera feita no where (ver #WhereSegregacaoCliente)
		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC1 ON Comp.IDPlaca1 = PC1.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC2 ON Comp.IDPlaca2 = PC2.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC3 ON Comp.IDPlaca3 = PC3.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC4 ON Comp.IDPlaca4 = PC4.IDPlaca'
	END

	SET @StrSQL += ' WHERE (Comp.IDStatus <> 3)'
			
	IF (@IDEmpresa IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDEmpresa = ' +  CONVERT(VARCHAR(1),@IDEmpresa) +')'
	IF (@IDStatus IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDStatus =  ' + CONVERT(VARCHAR(1),@IDStatus) + ')'
	IF (@Operacao IS NOT NULL)
		SET @StrSQL += ' AND (Comp.Operacao = '''  + @Operacao + ''')'
	IF (@IDTipoComposicao IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDTipoComposicao =  ' + CONVERT(VARCHAR(1),@IDTipoComposicao) +')'
	IF (@Chamado IS NOT NULL)
		SET @StrSQL += ' AND (Comp.CodigoEasyQuery LIKE ''%' +  @Chamado + '%'')'
	IF (@DtInicio IS NOT NULL)
		SET @StrSQL += ' AND (Comp.DataAtualizacao >= ''' + CONVERT(VARCHAR(19),@DtInicio) +''')'
	IF (@DtFim IS NOT NULL)
		SET @StrSQL += ' AND (Comp.DataAtualizacao  <= ''' + CONVERT(VARCHAR(19),@DtFim) +''')'
	IF (@Placa IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (Placa1.PlacaVeiculo =  ''' + @Placa +''''
		SET @StrSQL += '	OR Placa2.PlacaVeiculo = ''' + @Placa +''''
		SET @StrSQL += '	OR Placa3.PlacaVeiculo = ''' + @Placa +''''
		SET @StrSQL += '	OR Placa4.PlacaVeiculo = ''' + @Placa +''')'
	END
	IF (@IDTransportadora IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (Placa1.IDTransportadora =  ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa2.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa3.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa4.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora) +')'
	END

	-- #WhereSegregacaoTransportadora
	-- Se o usuario for do tipo cliente, exige que exista a relacao entre placa X transportadora
	-- Essa relacao esta no Join (ver #JoinSegregacaoTransportadora)
	IF(@IDUsuarioTransportadora IS NOT NULL)
	BEGIN
		-- O usuario precisa ter acesso a primeira transportadora de pelo menos uma das placas
		SET @StrSQL += ' AND (UT1.ID IS NOT NULL OR UT2.ID IS NOT NULL OR UT3.ID IS NOT NULL OR UT4.ID IS NOT NULL)'

		-- Se a placa for do tipo ambas (IDEmpresa = 3) o usuario também precisa ter acesso a segunda transportadora de pelo menos uma das placas
		SET @StrSQL += ' AND ((Comp.IDEmpresa = 3'
		SET @StrSQL += ' AND  (UT1.ID IS NOT NULL OR UT2.ID IS NOT NULL OR UT3.ID IS NOT NULL OR UT4.ID IS NOT NULL))'
		SET @StrSQL += '	OR Comp.IDEmpresa <> 3)'
	END

	-- #WhereSegregacaoCliente
	-- Se o cliente for filtrado ou for um usuario do tipo cliente, exige que exista a relacao entre placa X cliente X usuario seja valida.
	-- Essa relacao esta no Join (ver #JoinSegregacaoCliente)
	IF (@IDCliente IS NOT NULL OR @IDUsuarioCliente IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (PC1.IDPlaca IS NOT NULL OR PC2.IDPlaca IS NOT NULL OR PC3.IDPlaca IS NOT NULL OR PC4.IDPlaca IS NOT NULL)'
	END

	SET @StrSQL += ')  AS Composicao '
	
	SET @StrSQL += ' WHERE 1=1 ';

	IF (@PrimeiraPagina IS NOT NULL)
		SET @StrSQL += ' AND Composicao.RowNum > ' + CONVERT(VARCHAR(5),@PrimeiraPagina) 
	IF (@UltimaPagina IS NOT NULL)
		SET @StrSQL += 'AND Composicao.RowNum <= '  + CONVERT(VARCHAR(5),@UltimaPagina)

	SET @StrSQL += ' AND Composicao.IdPais = ' + CONVERT(VARCHAR(5), @IdPais);

	--print @StrSql;
	EXEC (@StrSQL)
END

GO



/***********************************************************
* 3) AJUSTE NA PROCEDURE [Proc_Pesquisa_Composicao]
************************************************************/

--3.1) Verifica se j� existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Pesquisa_Composicao')
    DROP PROCEDURE [Proc_Pesquisa_Composicao];
GO

--3.2) Recriar a procedure ajustada
CREATE PROCEDURE  [dbo].[Proc_Pesquisa_Composicao]
	@IsCount BIT = 0,
	@PrimeiraPagina INT = NULL,
	@UltimaPagina INT = NULL,
	@IDEmpresa INT = NULL,
	@IDStatus INT = NULL,
	@Operacao VARCHAR(3) = NULL,
	@IDTipoComposicao INT = NULL,
	@Chamado VARCHAR(23) = NULL,
	@DataInicio DATE = NULL,
	@DataFim DATE = NULL,
	@Placa VARCHAR(10) = NULL,
	@IDTransportadora INT = NULL,
	@IDUsuarioTransportadora INT = NULL,	
	@IDCliente INT = NULL,
	@IDUsuarioCliente INT = NULL,
	@IdPais INT = 1
AS
BEGIN
	--Utilização de query dinâmica conforme sugestão de melhoria do DBA
	DECLARE @StrSQL VARCHAR(max)  
	DECLARE @DtInicio DATETIME = NULL
	DECLARE @DtFim DATETIME = NULL

	IF @DataInicio IS NOT NULL
		SET @DtInicio = @DataInicio
	IF @DataFim IS NOT NULL
		SET @DtFim = DATEADD(MS, -1, DATEADD(D, 1, CONVERT(DATETIME2, @DataFim)))	
	IF (@IsCount = 1) 
	BEGIN
		SET @strSQL = 
		'SELECT COUNT(*) AS Linhas '
	END
	ELSE
	BEGIN
		SET @StrSQL = 
		'SELECT 
			RowNum,
			ID, 
			EmpresaNome,
			Operacao, 				
			IDStatus,
			TipoComposicao,
			TipoComposicaoEixo,
			CategoriaVeiculo,
			CategoriaVeiculoEs,
			Placa1,
			Placa2,
			Placa3,
			Placa4,
			CPFCNPJ,
			DataNascimento,
			RazaoSocial,
			DataAtualizacao,
			Observacao,
			CodigoEasyQuery,	
			CPFCNPJArrendamento,
			RazaoSocialArrendamento,
			LoginUsuario,
			PBTC,	
			UsuarioAlterouStatus,
			CAST(CASE WHEN MultiSeta1 <> 0 OR MultiSeta2 <> 0 OR MultiSeta3 <> 0 OR MultiSeta4 <> 0 THEN 1 ELSE 0 END AS BIT) AS Multiseta,
			CAST(CASE WHEN MultiCompartimento <> 0  THEN 1 ELSE 0 END AS BIT) AS MultiCompartimento'
	END
	SET @StrSQL +='
		 FROM (
			SELECT 
				ROW_NUMBER() OVER ( ORDER BY Comp.DataAtualizacao DESC ) AS RowNum,
				Comp.ID, 
				Emp.Nome AS EmpresaNome,
				Comp.Operacao, 				
				Comp.IDStatus,
				TC.Nome AS TipoComposicao,
				CE.Codigo AS TipoComposicaoEixo,
				CV.Nome AS CategoriaVeiculo,
				CV.NomeEs AS CategoriaVeiculoEs,
				Placa1.PlacaVeiculo AS Placa1,
				Placa2.PlacaVeiculo AS Placa2,
				Placa3.PlacaVeiculo AS Placa3,
				Placa4.PlacaVeiculo AS Placa4,
				Comp.CPFCNPJ,
				Comp.DataNascimento,
				Comp.RazaoSocial,
				Comp.DataAtualizacao,
				Comp.Observacao,
				Comp.CodigoEasyQuery,	
				Comp.CPFCNPJArrendamento,
				Comp.RazaoSocialArrendamento,
				Comp.LoginUsuario,
				Comp.PBTC,
				Comp.UsuarioAlterouStatus,
				Placa1.MultiSeta AS MultiSeta1,
				Placa2.MultiSeta AS MultiSeta2,
				Placa3.MultiSeta AS MultiSeta3,
				Placa4.MultiSeta AS MultiSeta4,
				MultiCompartimento = CASE WHEN EXISTS
									(SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca1
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca2
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca3
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca4) THEN 1 ELSE 0 END
			FROM Composicao Comp WITH (NOLOCK) 
			INNER JOIN Empresa Emp WITH (NOLOCK) ON Comp.IDEmpresa = Emp.ID
			INNER JOIN TipoComposicao TC WITH (NOLOCK) ON Comp.IDTipoComposicao = TC.ID
			LEFT JOIN ComposicaoEixo CE WITH (NOLOCK) ON Comp.IDTipoComposicaoEixo = CE.ID
			INNER JOIN CategoriaVeiculo CV WITH (NOLOCK) ON Comp.IDCategoriaVeiculo = CV.ID
			LEFT JOIN VW_Placa Placa1 WITH (NOLOCK) ON Comp.IDPlaca1 = Placa1.ID
			LEFT JOIN VW_Placa Placa2 WITH (NOLOCK) ON Comp.IDPlaca2 = Placa2.ID
			LEFT JOIN VW_Placa Placa3 WITH (NOLOCK) ON Comp.IDPlaca3 = Placa3.ID
			LEFT JOIN VW_Placa Placa4 WITH (NOLOCK) ON Comp.IDPlaca4 = Placa4.ID'
	

	-- #JoinSegregacaoTransportadora
	-- Caso o usuario seja do tipo transportadora, valida o acesso na tabela que relaciona usuario X transportadora
	IF (@IDUsuarioTransportadora IS NOT NULL)
	BEGIN
		-- Cada Join abaixo tem a funcao de trazer a relacao de cada transportadora de cada placa com o usuario
		-- Como o usuario precisa ter acesso somente a uma das placas, a segregacao do acesso sera feita no where (ver #WhereSegregacaoTransportadora)
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT1 WITH (NOLOCK) ON Placa1.IDTransportadora = UT1.IDTransportadora AND UT1.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT2 WITH (NOLOCK) ON Placa2.IDTransportadora = UT2.IDTransportadora AND UT2.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT3 WITH (NOLOCK) ON Placa3.IDTransportadora = UT3.IDTransportadora AND UT3.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT4 WITH (NOLOCK) ON Placa4.IDTransportadora = UT4.IDTransportadora AND UT4.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT5 WITH (NOLOCK) ON Placa1.IDTransportadora2 = UT5.IDTransportadora AND UT5.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT6 WITH (NOLOCK) ON Placa2.IDTransportadora2 = UT6.IDTransportadora AND UT6.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT7 WITH (NOLOCK) ON Placa3.IDTransportadora2 = UT7.IDTransportadora AND UT7.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT8 WITH (NOLOCK) ON Placa4.IDTransportadora2 = UT8.IDTransportadora AND UT8.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
	END

	-- #JoinSegregacaoCliente
	-- Caso o usuario seja do tipo cliente ou o cliente tenha sido filtrado, valida a relacao entre o cliente e as placas e valida o acesso na tabela que relaciona usuario X cliente
	IF (@IDCliente IS NOT NULL) OR (@IDUsuarioCliente IS NOT NULL)
	BEGIN
		-- O join abaixo monta a relacao da placa com o cliente e, se necessario, do cliente com o usuario (para validar acesso).
		-- O mesmo join sera feito para as 4 placas.
		-- Como o usuario precisa ter acesso somente a uma das placas, a segregacao do acesso sera feita no where (ver #WhereSegregacaoCliente)
		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC1 ON Comp.IDPlaca1 = PC1.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC2 ON Comp.IDPlaca2 = PC2.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC3 ON Comp.IDPlaca3 = PC3.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC4 ON Comp.IDPlaca4 = PC4.IDPlaca'
	END

	SET @StrSQL += ' WHERE (Comp.IDStatus <> 3)'
	SET @StrSQL += ' AND Comp.IdPais = ' + CONVERT(VARCHAR(1), @IdPais);

	IF (@IDEmpresa IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDEmpresa = ' +  CONVERT(VARCHAR(1),@IDEmpresa) +')'
	IF (@IDStatus IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDStatus =  ' + CONVERT(VARCHAR(1),@IDStatus) + ')'
	IF (@Operacao IS NOT NULL)
		SET @StrSQL += ' AND (Comp.Operacao = '''  + @Operacao + ''')'
	IF (@IDTipoComposicao IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDTipoComposicao =  ' + CONVERT(VARCHAR(1),@IDTipoComposicao) +')'
	IF (@Chamado IS NOT NULL)
		SET @StrSQL += ' AND (Comp.CodigoEasyQuery LIKE ''%' +  @Chamado + '%'')'
	IF (@DtInicio IS NOT NULL)
		SET @StrSQL += ' AND (Comp.DataAtualizacao >= ''' + CONVERT(VARCHAR(19),@DtInicio) +''')'
	IF (@DtFim IS NOT NULL)
		SET @StrSQL += ' AND (Comp.DataAtualizacao  <= ''' + CONVERT(VARCHAR(19),@DtFim) +''')'
	IF (@Placa IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (Placa1.PlacaVeiculo =  ''' + @Placa +''''
		SET @StrSQL += '	OR Placa2.PlacaVeiculo = ''' + @Placa +''''
		SET @StrSQL += '	OR Placa3.PlacaVeiculo = ''' + @Placa +''''
		SET @StrSQL += '	OR Placa4.PlacaVeiculo = ''' + @Placa +''')'
	END
	IF (@IDTransportadora IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (Placa1.IDTransportadora =  ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa2.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa3.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa4.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora) +')'
	END

	-- #WhereSegregacaoTransportadora
	-- Se o usuario for do tipo cliente, exige que exista a relacao entre placa X transportadora
	-- Essa relacao esta no Join (ver #JoinSegregacaoTransportadora)
	IF(@IDUsuarioTransportadora IS NOT NULL)
	BEGIN
		-- O usuario precisa ter acesso a primeira transportadora de pelo menos uma das placas
		SET @StrSQL += ' AND (UT1.ID IS NOT NULL OR UT2.ID IS NOT NULL OR UT3.ID IS NOT NULL OR UT4.ID IS NOT NULL)'

		-- Se a placa for do tipo ambas (IDEmpresa = 3) o usuario também precisa ter acesso a segunda transportadora de pelo menos uma das placas
		SET @StrSQL += ' AND ((Comp.IDEmpresa = 3'
		SET @StrSQL += ' AND  (UT1.ID IS NOT NULL OR UT2.ID IS NOT NULL OR UT3.ID IS NOT NULL OR UT4.ID IS NOT NULL))'
		SET @StrSQL += '	OR Comp.IDEmpresa <> 3)'
	END

	-- #WhereSegregacaoCliente
	-- Se o cliente for filtrado ou for um usuario do tipo cliente, exige que exista a relacao entre placa X cliente X usuario seja valida.
	-- Essa relacao esta no Join (ver #JoinSegregacaoCliente)
	IF (@IDCliente IS NOT NULL OR @IDUsuarioCliente IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (PC1.IDPlaca IS NOT NULL OR PC2.IDPlaca IS NOT NULL OR PC3.IDPlaca IS NOT NULL OR PC4.IDPlaca IS NOT NULL)'
	END

	SET @StrSQL += ')  AS Composicao '
	
	IF (@PrimeiraPagina IS NOT NULL)
		SET @StrSQL += 'WHERE Composicao.RowNum > ' + CONVERT(VARCHAR(5),@PrimeiraPagina) 
	IF (@UltimaPagina IS NOT NULL)
		SET @StrSQL += 'AND Composicao.RowNum <= '  + CONVERT(VARCHAR(5),@UltimaPagina)

	EXEC (@StrSQL)
END

GO


/***********************************************************
* 4) AJUSTE NA PROCEDURE [Proc_Pesquisa_Composicao_Excel]
************************************************************/

--4.1) Verifica se j� existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Pesquisa_Composicao_Excel')
    DROP PROCEDURE [Proc_Pesquisa_Composicao_Excel];
GO

--4.2) Recriar a procedure ajustada
CREATE PROCEDURE  [dbo].[Proc_Pesquisa_Composicao_Excel]
	@IsCount BIT = 0,
	@PrimeiraPagina INT = NULL,
	@UltimaPagina INT = NULL,
	@IDEmpresa INT = NULL,
	@IDStatus INT = NULL,
	@Operacao VARCHAR(3) = NULL,
	@IDTipoComposicao INT = NULL,
	@Chamado VARCHAR(23) = NULL,
	@DataInicio DATE = NULL,
	@DataFim DATE = NULL,
	@Placa VARCHAR(10) = NULL,
	@IDTransportadora INT = NULL,
	@IDUsuarioTransportadora INT = NULL,
	@IDCliente INT = NULL,
	@IDUsuarioCliente INT = NULL,
	@IdPais INT = 1
AS
BEGIN
	--Utilização de query dinâmica conforme sugestão de melhoria do DBA
	DECLARE @StrSQL VARCHAR(MAX)  
	DECLARE @DtInicio DATETIME = NULL
	DECLARE @DtFim DATETIME = NULL

	IF @DataInicio IS NOT NULL
		SET @DtInicio = @DataInicio
	IF @DataFim IS NOT NULL
		SET @DtFim = DATEADD(MS, -1, DATEADD(D, 1, CONVERT(DATETIME2, @DataFim)))	
	IF (@IsCount = 1) 
	BEGIN
		SET @strSQL = 
		'SELECT COUNT(*) AS Linhas '
	END
	ELSE
	BEGIN
		SET @StrSQL = 
		'SELECT 
			RowNum,
			ID, 
			EmpresaNome,
			Operacao, 				
			IDStatus,
			TipoComposicao,
			TipoComposicaoEixo,
			CategoriaVeiculo,
			CategoriaVeiculoEs,
			Placa1,
			Placa2,
			Placa3,
			Placa4,
			CPFCNPJ,
			DataNascimento,
			RazaoSocial,
			DataAtualizacao,
			Observacao,
			CodigoEasyQuery,	
			CPFCNPJArrendamento,
			RazaoSocialArrendamento,
			LoginUsuario,
			PBTC,		
			CAST(CASE WHEN MultiSeta1 <> 0 OR MultiSeta2 <> 0 OR MultiSeta3 <> 0 OR MultiSeta4 <> 0 THEN 1 ELSE 0 END AS BIT) AS Multiseta,
			CAST(CASE WHEN MultiCompartimento <> 0  THEN 1 ELSE 0 END AS BIT) AS MultiCompartimento,
			NumCompartimentos,
			Bloqueado,
			CheckListData,
			CheckListAprovado,
			CapacidadeMinima,
			CapacidadeMaxima,
			UsuarioAlterouStatus '
			
	END
	SET @StrSQL +='
		 FROM (
			SELECT 
				ROW_NUMBER() OVER ( ORDER BY Comp.DataAtualizacao DESC ) AS RowNum,
				Comp.ID, 
				Emp.Nome AS EmpresaNome,
				Comp.Operacao, 				
				Comp.IDStatus,
				TC.Nome AS TipoComposicao,
				CE.Codigo AS TipoComposicaoEixo,
				CV.Nome AS CategoriaVeiculo,
				CV.NomeEs AS CategoriaVeiculoEs,
				Placa1.PlacaVeiculo AS Placa1,
				Placa2.PlacaVeiculo AS Placa2,
				Placa3.PlacaVeiculo AS Placa3,
				Placa4.PlacaVeiculo AS Placa4,
				Comp.CPFCNPJ,
				Comp.DataNascimento,
				Comp.RazaoSocial,
				Comp.DataAtualizacao,
				Comp.Observacao,
				Comp.CodigoEasyQuery,	
				Comp.CPFCNPJArrendamento,
				Comp.RazaoSocialArrendamento,
				Comp.LoginUsuario,
				Comp.PBTC,
				Comp.IdPais,
				Comp.UsuarioAlterouStatus,
				Placa1.MultiSeta AS MultiSeta1,
				Placa2.MultiSeta AS MultiSeta2,
				Placa3.MultiSeta AS MultiSeta3,
				Placa4.MultiSeta AS MultiSeta4,
				MultiCompartimento = CASE WHEN EXISTS
									(SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca1
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca2
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca3
									  UNION ALL
									  SELECT 1 FROM PlacaSeta PS WHERE VolumeCompartimento2 IS NOT NULL AND PS.IDPlaca = IDPlaca4) THEN 1 ELSE 0 END,
				(ISNULL(SNC1.NumCompartimentos, 0) + ISNULL(SNC2.NumCompartimentos, 0) + ISNULL(SNC3.NumCompartimentos, 0) + ISNULL(SNC4.NumCompartimentos, 0)) AS NumCompartimentos,
				CASE 
					WHEN Comp.IDStatus = 5 THEN convert(bit, 1)
					ELSE convert(bit, 0)
				END AS Bloqueado,
				CC.Data CheckListData,
				CC.Aprovado CheckListAprovado,
				ISNULL(VWSM1.SomaVolumeMinimo, 0) + ISNULL(VWSM2.SomaVolumeMinimo, 0) + ISNULL(VWSM3.SomaVolumeMinimo, 0) + ISNULL(VWSM4.SomaVolumeMinimo, 0) AS CapacidadeMinima,
				ISNULL(VWMA1.SomaVolumeMaximo, 0) + ISNULL(VWMA2.SomaVolumeMaximo, 0) + ISNULL(VWMA3.SomaVolumeMaximo, 0) + ISNULL(VWMA4.SomaVolumeMaximo, 0) AS CapacidadeMaxima
			FROM Composicao Comp WITH (NOLOCK) 
			INNER JOIN Empresa Emp WITH (NOLOCK) ON Comp.IDEmpresa = Emp.ID
			INNER JOIN TipoComposicao TC WITH (NOLOCK) ON Comp.IDTipoComposicao = TC.ID
			LEFT JOIN ComposicaoEixo CE WITH (NOLOCK) ON Comp.IDTipoComposicaoEixo = CE.ID
			INNER JOIN CategoriaVeiculo CV WITH (NOLOCK) ON Comp.IDCategoriaVeiculo = CV.ID
			LEFT JOIN VW_Placa Placa1 WITH (NOLOCK) ON Comp.IDPlaca1 = Placa1.ID
			LEFT JOIN VW_Placa Placa2 WITH (NOLOCK) ON Comp.IDPlaca2 = Placa2.ID
			LEFT JOIN VW_Placa Placa3 WITH (NOLOCK) ON Comp.IDPlaca3 = Placa3.ID
			LEFT JOIN VW_Placa Placa4 WITH (NOLOCK) ON Comp.IDPlaca4 = Placa4.ID
			LEFT JOIN VW_SelecionaNumCompartimentos SNC1 ON SNC1.IdPlaca = IDPlaca1
			LEFT JOIN VW_SelecionaNumCompartimentos SNC2 ON SNC2.IdPlaca = IDPlaca2
			LEFT JOIN VW_SelecionaNumCompartimentos SNC3 ON SNC3.IdPlaca = IDPlaca3
			LEFT JOIN VW_SelecionaNumCompartimentos SNC4 ON SNC4.IdPlaca = IDPlaca4
			LEFT JOIN (
				SELECT Top 1
				IDComposicao, 
				DataCadastro,
				Data,
				Aprovado 
				FROM ChecklistComposicao WITH (NOLOCK)
				Order by DataCadastro Desc
			) CC ON CC.IDComposicao = Comp.ID
			LEFT JOIN VW_SomaVolumeMinimoPlaca VWSM1 on VWSM1.IdPlaca = IDPlaca1
			LEFT JOIN VW_SomaVolumeMinimoPlaca VWSM2 on VWSM2.IdPlaca = IDPlaca2
			LEFT JOIN VW_SomaVolumeMinimoPlaca VWSM3 on VWSM3.IdPlaca = IDPlaca3
			LEFT JOIN VW_SomaVolumeMinimoPlaca VWSM4 on VWSM4.IdPlaca = IDPlaca4
			LEFT JOIN VW_SomaVolumeMaximoPlaca VWMA1 on VWMA1.IdPlaca = IDPlaca1
			LEFT JOIN VW_SomaVolumeMaximoPlaca VWMA2 on VWMA2.IdPlaca = IDPlaca2
			LEFT JOIN VW_SomaVolumeMaximoPlaca VWMA3 on VWMA3.IdPlaca = IDPlaca3
			LEFT JOIN VW_SomaVolumeMaximoPlaca VWMA4 on VWMA4.IdPlaca = IDPlaca4'
	
	-- #JoinSegregacaoTransportadora
	-- Caso o usuario seja do tipo transportadora, valida o acesso na tabela que relaciona usuario X transportadora
	IF (@IDUsuarioTransportadora IS NOT NULL)
	BEGIN
		-- Cada Join abaixo tem a funcao de trazer a relacao de cada transportadora de cada placa com o usuario
		-- Como o usuario precisa ter acesso somente a uma das placas, a segregacao do acesso sera feita no where (ver #WhereSegregacaoTransportadora)
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT1 WITH (NOLOCK) ON Placa1.IDTransportadora = UT1.IDTransportadora AND UT1.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT2 WITH (NOLOCK) ON Placa2.IDTransportadora = UT2.IDTransportadora AND UT2.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT3 WITH (NOLOCK) ON Placa3.IDTransportadora = UT3.IDTransportadora AND UT3.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT4 WITH (NOLOCK) ON Placa4.IDTransportadora = UT4.IDTransportadora AND UT4.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT5 WITH (NOLOCK) ON Placa1.IDTransportadora2 = UT5.IDTransportadora AND UT5.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT6 WITH (NOLOCK) ON Placa2.IDTransportadora2 = UT6.IDTransportadora AND UT6.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT7 WITH (NOLOCK) ON Placa3.IDTransportadora2 = UT7.IDTransportadora AND UT7.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
		SET @StrSQL += ' LEFT JOIN UsuarioTransportadora UT8 WITH (NOLOCK) ON Placa4.IDTransportadora2 = UT8.IDTransportadora AND UT8.IDUsuario = '+ CONVERT(VARCHAR(10),ISNULL(@IDUsuarioTransportadora,0))
	END

	-- #JoinSegregacaoCliente
	-- Caso o usuario seja do tipo cliente ou o cliente tenha sido filtrado, valida a relacao entre o cliente e as placas e valida o acesso na tabela que relaciona usuario X cliente
	IF (@IDCliente IS NOT NULL) OR (@IDUsuarioCliente IS NOT NULL)
	BEGIN
		-- O join abaixo monta a relacao da placa com o cliente e, se necessario, do cliente com o usuario (para validar acesso).
		-- O mesmo join sera feito para as 4 placas.
		-- Como o usuario precisa ter acesso somente a uma das placas, a segregacao do acesso sera feita no where (ver #WhereSegregacaoCliente)
		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC1 ON Comp.IDPlaca1 = PC1.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC2 ON Comp.IDPlaca2 = PC2.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC3 ON Comp.IDPlaca3 = PC3.IDPlaca'

		SET @StrSQL += ' LEFT JOIN ('
		SET @StrSQL += '	SELECT DISTINCT PC.IDPlaca'
		SET @StrSQL += '	FROM PlacaCliente PC WITH (NOLOCK)'
		IF (@IDUsuarioCliente IS NOT NULL)
			SET @StrSQL += '	JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente AND UC.IDUsuario =' + CONVERT(VARCHAR(10),ISNULL(@IDUsuarioCliente,0))
		IF (@IDCliente IS NOT NULL)
			SET @StrSQL += ' WHERE PC.IDCliente = ' + CONVERT(VARCHAR(10),@IDCliente)
		SET @StrSQL += ' ) PC4 ON Comp.IDPlaca4 = PC4.IDPlaca'
	END

	SET @StrSQL += ' WHERE (Comp.IDStatus <> 3)'
			
	IF (@IDEmpresa IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDEmpresa = ' +  CONVERT(VARCHAR(1),@IDEmpresa) +')'
	IF (@IDStatus IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDStatus =  ' + CONVERT(VARCHAR(1),@IDStatus) + ')'
	IF (@Operacao IS NOT NULL)
		SET @StrSQL += ' AND (Comp.Operacao = '''  + @Operacao + ''')'
	IF (@IDTipoComposicao IS NOT NULL)
		SET @StrSQL += ' AND (Comp.IDTipoComposicao =  ' + CONVERT(VARCHAR(1),@IDTipoComposicao) +')'
	IF (@Chamado IS NOT NULL)
		SET @StrSQL += ' AND (Comp.CodigoEasyQuery LIKE ''%' +  @Chamado + '%'')'
	IF (@DtInicio IS NOT NULL)
		SET @StrSQL += ' AND (Comp.DataAtualizacao >= ''' + CONVERT(VARCHAR(19),@DtInicio) +''')'
	IF (@DtFim IS NOT NULL)
		SET @StrSQL += ' AND (Comp.DataAtualizacao  <= ''' + CONVERT(VARCHAR(19),@DtFim) +''')'
	IF (@Placa IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (Placa1.PlacaVeiculo =  ''' + @Placa +''''
		SET @StrSQL += '	OR Placa2.PlacaVeiculo = ''' + @Placa +''''
		SET @StrSQL += '	OR Placa3.PlacaVeiculo = ''' + @Placa +''''
		SET @StrSQL += '	OR Placa4.PlacaVeiculo = ''' + @Placa +''')'
	END
	IF (@IDTransportadora IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (Placa1.IDTransportadora =  ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa2.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa3.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora)
		SET @StrSQL += '	OR Placa4.IDTransportadora = ' + CONVERT(VARCHAR(10),@IDTransportadora) +')'
	END

	-- #WhereSegregacaoTransportadora
	-- Se o usuario for do tipo cliente, exige que exista a relacao entre placa X transportadora
	-- Essa relacao esta no Join (ver #JoinSegregacaoTransportadora)
	IF(@IDUsuarioTransportadora IS NOT NULL)
	BEGIN
		-- O usuario precisa ter acesso a primeira transportadora de pelo menos uma das placas
		SET @StrSQL += ' AND (UT1.ID IS NOT NULL OR UT2.ID IS NOT NULL OR UT3.ID IS NOT NULL OR UT4.ID IS NOT NULL)'

		-- Se a placa for do tipo ambas (IDEmpresa = 3) o usuario também precisa ter acesso a segunda transportadora de pelo menos uma das placas
		SET @StrSQL += ' AND ((Comp.IDEmpresa = 3'
		SET @StrSQL += ' AND  (UT1.ID IS NOT NULL OR UT2.ID IS NOT NULL OR UT3.ID IS NOT NULL OR UT4.ID IS NOT NULL))'
		SET @StrSQL += '	OR Comp.IDEmpresa <> 3)'
	END

	-- #WhereSegregacaoCliente
	-- Se o cliente for filtrado ou for um usuario do tipo cliente, exige que exista a relacao entre placa X cliente X usuario seja valida.
	-- Essa relacao esta no Join (ver #JoinSegregacaoCliente)
	IF (@IDCliente IS NOT NULL OR @IDUsuarioCliente IS NOT NULL)
	BEGIN
		SET @StrSQL += ' AND (PC1.IDPlaca IS NOT NULL OR PC2.IDPlaca IS NOT NULL OR PC3.IDPlaca IS NOT NULL OR PC4.IDPlaca IS NOT NULL)'
	END

	SET @StrSQL += ')  AS Composicao '
	
	SET @StrSQL += ' WHERE 1=1 ';

	IF (@PrimeiraPagina IS NOT NULL)
		SET @StrSQL += ' AND Composicao.RowNum > ' + CONVERT(VARCHAR(5),@PrimeiraPagina) 
	IF (@UltimaPagina IS NOT NULL)
		SET @StrSQL += 'AND Composicao.RowNum <= '  + CONVERT(VARCHAR(5),@UltimaPagina)

	SET @StrSQL += ' AND Composicao.IdPais = ' + CONVERT(VARCHAR(5), @IdPais);

	--print @StrSql;
	EXEC (@StrSQL)
END


