USE UniCad
GO

/* Inclui a coluna "NomeEs" respons�vel por manter a tradu��o dos nomes no idioma Espanhol */
IF NOT EXISTS(SELECT * FROM sys.columns WHERE [object_id] = OBJECT_ID('[dbo].[CategoriaVeiculo]') AND UPPER(NAME) = 'NOMEES') BEGIN
	ALTER TABLE [dbo].[CategoriaVeiculo] ADD NomeEs VARCHAR(100) NULL;
END

GO

/* Inclus�o dos Nomes em Espanhol na tabela */
IF EXISTS (SELECT * FROM [CategoriaVeiculo] WHERE ID = 1 AND UPPER(Nome) = 'PARTICULAR') BEGIN
	UPDATE [CategoriaVeiculo] SET NomeEs = 'Privado' WHERE ID = 1;
END

IF EXISTS (SELECT * FROM [CategoriaVeiculo] WHERE ID = 2 AND UPPER(Nome) = 'ALUGUEL') BEGIN
	UPDATE [CategoriaVeiculo] SET NomeEs = 'En Alquiler' WHERE ID = 2;
END

IF EXISTS (SELECT * FROM [CategoriaVeiculo] WHERE ID = 3 AND UPPER(Nome) = 'TODOS') BEGIN
	UPDATE [CategoriaVeiculo] SET NomeEs = 'Todos' WHERE ID = 3;
END

IF EXISTS (SELECT * FROM [CategoriaVeiculo] WHERE ID = 4 AND UPPER(Nome) = 'MOTORISTA') BEGIN
	UPDATE [CategoriaVeiculo] SET NomeEs = 'Conductor' WHERE ID = 4;
END

IF EXISTS (SELECT * FROM [CategoriaVeiculo] WHERE ID = 5 AND UPPER(Nome) = 'TREINAMENTO') BEGIN
	UPDATE [CategoriaVeiculo] SET NomeEs = 'Entrenamiento' WHERE ID = 5;
END