USE UniCad
GO

IF NOT EXISTS (
		SELECT 1
		FROM SYS.COLUMNS
		WHERE NAME = 'TipoAcaoVencimento'
			AND OBJECT_ID = OBJECT_ID('MotoristaDocumento')
		)
BEGIN

	BEGIN TRANSACTION

	ALTER TABLE dbo.MotoristaDocumento ADD
			TipoAcaoVencimento int NULL

	COMMIT

END

IF NOT EXISTS (
		SELECT 1
		FROM SYS.COLUMNS
		WHERE NAME = 'UsuarioAlterouStatus'
			AND OBJECT_ID = OBJECT_ID('MotoristaDocumento')
		)
BEGIN

	BEGIN TRANSACTION

	ALTER TABLE dbo.MotoristaDocumento ADD
			UsuarioAlterouStatus varchar(50) NULL

	COMMIT

END