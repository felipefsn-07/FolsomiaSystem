USE [UniCad]

IF NOT EXISTS (SELECT 1 FROM SYS.TABLES WHERE NAME = 'MotoristaTipoProduto')
BEGIN
	CREATE TABLE dbo.MotoristaTipoProduto
		(
		ID int NOT NULL  IDENTITY (1, 1),
		IDMotorista int NOT NULL,
		IDTipoProduto int NOT NULL
		)  ON [PRIMARY]

	ALTER TABLE dbo.MotoristaTipoProduto ADD CONSTRAINT
		PK_MotoristaTipoProduto PRIMARY KEY CLUSTERED 
		(
		ID
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


	ALTER TABLE dbo.MotoristaTipoProduto ADD CONSTRAINT
		FK_MotoristaTipoProduto_Motorista FOREIGN KEY
		(
		IDMotorista
		) REFERENCES dbo.Motorista
		(
		ID
		) ON UPDATE  NO ACTION 
		 ON DELETE  NO ACTION 
	

	ALTER TABLE dbo.MotoristaTipoProduto ADD CONSTRAINT
		FK_MotoristaTipoProduto_TipoProduto FOREIGN KEY
		(
		IDTipoProduto
		) REFERENCES dbo.TipoProduto
		(
		ID
		) ON UPDATE  NO ACTION 
		 ON DELETE  NO ACTION 
	

	ALTER TABLE dbo.MotoristaTipoProduto SET (LOCK_ESCALATION = TABLE)

END