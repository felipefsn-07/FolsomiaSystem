USE UniCad
GO

IF EXISTS(SELECT 1 FROM sys.columns WHERE  [object_id] = OBJECT_ID('[DBO].[PlacaArgentina]') AND UPPER(NAME) = 'PBTC') BEGIN
	ALTER TABLE [dbo].[PlacaArgentina] ALTER COLUMN PBTC FLOAT NULL;
END