USE UniCad
GO

IF NOT EXISTS (
		SELECT 1
		FROM SYS.COLUMNS
		WHERE NAME = 'TipoAcaoVencimento'
			AND OBJECT_ID = OBJECT_ID('TipoDocumento')
		)
BEGIN

	BEGIN TRANSACTION

	ALTER TABLE dbo.TipoDocumento ADD
			TipoAcaoVencimento int NULL

	COMMIT

END
