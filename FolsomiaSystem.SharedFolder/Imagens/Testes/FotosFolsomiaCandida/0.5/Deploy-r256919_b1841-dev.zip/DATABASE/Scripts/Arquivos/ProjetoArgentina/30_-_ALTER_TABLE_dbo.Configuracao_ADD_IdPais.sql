USE [UniCad]
GO

IF NOT EXISTS(SELECT 1 FROM sys.columns WHERE  [object_id] = OBJECT_ID('[DBO].[Configuracao]') AND NAME = 'IdPais')
BEGIN
	ALTER TABLE dbo.Configuracao ADD IdPais INT NULL;
	ALTER TABLE dbo.Configuracao ADD CONSTRAINT FK_Configuracao_Pais FOREIGN KEY (IdPais) REFERENCES Pais(id);
END
GO