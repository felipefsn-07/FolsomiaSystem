USE UniCad
GO

IF NOT EXISTS(SELECT * FROM sys.columns WHERE [object_id] = OBJECT_ID('[dbo].[Composicao]') AND UPPER(NAME) = 'IDPAIS') BEGIN
	ALTER TABLE [dbo].[Composicao] ADD IdPais INT NOT NULL DEFAULT 1;
	ALTER TABLE [dbo].[Composicao] ADD CONSTRAINT [FK_Composicao_Pais] FOREIGN KEY ([IdPais]) REFERENCES [dbo].[Pais] ([ID]);
END
