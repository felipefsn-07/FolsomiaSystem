USE Unicad

GO

IF EXISTS (SELECT 1 FROM SYS.COLUMNS WHERE NAME = 'DocumentoPossuiVencimento' AND OBJECT_ID = OBJECT_ID('TipoDocumento'))
BEGIN
	UPDATE TipoDocumento SET DocumentoPossuiVencimento = 1 WHERE DocumentoPossuiVencimento IS NULL
END

GO

IF EXISTS (SELECT 1 FROM SYS.COLUMNS WHERE NAME = 'DocumentoPossuiVencimento' AND OBJECT_ID = OBJECT_ID('TipoDocumento'))
BEGIN
	ALTER TABLE [dbo].[TipoDocumento] ALTER COLUMN DocumentoPossuiVencimento bit NOT NULL
END

GO 

IF EXISTS(SELECT * FROM information_schema.columns WHERE table_name = 'TipoDocumento' AND column_name = 'DocumentoPossuiVencimento' AND Table_schema = 'dbo' AND Column_default is NULL)
BEGIN
	ALTER TABLE [dbo].[TipoDocumento] ADD DEFAULT 1 FOR DocumentoPossuiVencimento
END