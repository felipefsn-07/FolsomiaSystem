Use UniCad


IF ( (SELECT count(*) FROM Configuracao WHERE NmVariavel = 'CadastroUsuariosBrasil') < 1)
	INSERT INTO Configuracao (NmVariavel,Descricao,Valor,DtCriacao,DtAtualizacao,IdPais) 
	VALUES ('CadastroUsuariosBrasil',
	'E-mail cadastro de usu�rios Brasil',
	'<html style="font-family:calibri">Caro Usu�rio,<br>
    Seu acesso foi criado com sucesso! A partir de agora voc� conseguir� realizar a gest�o de seus ve�culos atrav�s do UNICAD.<br>
    Seu usu�rio e senha de acesso ao UNICAD s�o os mesmos j� utilizados nos demais sistemas Ra�zen. </b><br>
    {0}<br><br>
    <b>D�vidas? Entre em contato com a Ra�zen!</b><html>', 
	GETDATE(),
	GETDATE(),
	1);


IF ( (SELECT count(*) FROM Configuracao WHERE NmVariavel = 'CadastroUsuariosSenhaBrasil') < 1)
	INSERT INTO Configuracao (NmVariavel,Descricao,Valor,DtCriacao,DtAtualizacao,IdPais) 
	VALUES ('CadastroUsuariosSenhaBrasil',
	'E-mail cadastro de usu�rios com senha Brasil',
	'<html style="font-family:calibri">Caro Usu�rio,<br>
    Seu acesso foi criado com sucesso! A partir de agora voc� conseguir� realizar a gest�o de seus ve�culos atrav�s do UNICAD.<br>
    Usu�rio: <b>{0}</b><br>
    Senha: <b>{1}</b><br>
    {2}<br><br>
    <b>D�vidas? Entre em contato com a Ra�zen!</b><html>',
	GETDATE(),
	GETDATE(),
	1);


IF ( (SELECT count(*) FROM Configuracao WHERE NmVariavel = 'CadastroUsuariosArgentina') < 1)
	INSERT INTO Configuracao (NmVariavel,Descricao,Valor,DtCriacao,DtAtualizacao,IdPais) 
	VALUES ('CadastroUsuariosArgentina',
	'E-mail cadastro de usu�rios Argentina',
	'<html style="font-family:calibri">Caro Usu�rio,<br>
    Seu acesso foi criado com sucesso! A partir de agora voc� conseguir� realizar a gest�o de seus ve�culos atrav�s do UNICAD.<br>
    Seu usu�rio e senha de acesso ao UNICAD s�o os mesmos j� utilizados nos demais sistemas Ra�zen. </b><br>
    {0}<br><br>
    <b>D�vidas? Entre em contato com a Ra�zen!</b><html>',
	GETDATE(),
	GETDATE(),
	2);


IF ( (SELECT count(*) FROM Configuracao WHERE NmVariavel = 'CadastroUsuariosSenhaArgentina') < 1)
	INSERT INTO Configuracao (NmVariavel,Descricao,Valor,DtCriacao,DtAtualizacao,IdPais) 
	VALUES ('CadastroUsuariosSenhaArgentina',
	'E-mail cadastro de usu�rios com senha Argentina',
	'<html style="font-family:calibri">Caro Usu�rio,<br>
    Seu acesso foi criado com sucesso! A partir de agora voc� conseguir� realizar a gest�o de seus ve�culos atrav�s do UNICAD.<br>
    Usu�rio: <b>{0}</b><br>
    Senha: <b>{1}</b><br>
    {2}<br><br>
    <b>D�vidas? Entre em contato com a Ra�zen!</b><html>',
	GETDATE(),
	GETDATE(),
	2);