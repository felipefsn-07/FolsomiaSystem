/***********************************************************
* 0) SELECAO DA BASE E CONFIGURACOES INICAIS
************************************************************/
USE Unicad
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/***********************************************************
* 1) AJUSTE NA PROCEDURE
************************************************************/

--1.1) Verifica se ja existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Pesquisa_Placa')
    DROP PROCEDURE [Proc_Pesquisa_Placa];
GO

--1.2) Recriar a procedure ajustada
/*
	[dbo].[Proc_Pesquisa_Placa]
	@IdEmpresa = null,
	@IdPlacaOficial = null,
	@Placa = null,
	@Operacao = null,
	@DataInicio = '01-10-2018 00:00:00',
	@DataFim = '10-10-2018 00:00:00',
	@IDTransportadora  = null,
	@IDCLiente = null,
	@IDStatus = 1,
	@IDUsuarioCliente = null,
	@IDUsuarioTransportadora = null,
	@Chamado = null,
	@IDTipoComposicao = null
*/
CREATE PROCEDURE  [dbo].[Proc_Pesquisa_Placa]
	@IdEmpresa INT = NULL,
	@IdPlacaOficial INT = NULL,
	@Placa VARCHAR(10) = NULL,
	@Operacao VARCHAR(10) = NULL,
	@DataInicio DATETIME = NULL,
	@DataFim DATETIME = NULL,
	@IDTransportadora INT = NULL,
	@IDCLiente INT = NULL,
	@IDStatus INT = NULL,
	@IDUsuarioCliente INT = NULL,
	@IDUsuarioTransportadora INT = NULL,
	@Chamado VARCHAR(20) = NULL,
	@IDTipoComposicao INT = NULL
AS
BEGIN

	DECLARE @cols AS NVARCHAR(4000)
	SET @cols = STUFF((SELECT distinct ',' + QUOTENAME(case when t.Sigla = 'C.A.' then 'CA' else t.Sigla end) 
			FROM TipoDocumento T WHERE T.TipoCadastro = 1
			FOR XML PATH(''), TYPE
			).value('.', 'NVARCHAR(4000)') 
		,1,1,'')


	DECLARE @StrSQL VARCHAR(MAX)
	IF (@Placa IS NOT NULL)
		SET @Placa = '%' + @Placa + '%'

	IF @DataFim IS NOT NULL
		SET @DataFim = DATEADD(MS, -1, DATEADD(D, 1, CONVERT(DATETIME2, @DataFim)))	
	
	SET @StrSQL =
	'SELECT 
		P.ID, 
		P.PlacaVeiculo, 
		P.Operacao, 
		P.IDTipoVeiculo,
		TV.Nome AS TipoVeiculo,
		P.IDTransportadora,
		P.IDTransportadora2,
		P.IDCategoriaVeiculo,
		CV.Nome AS CategoriaVeiculo,
		T.RazaoSocial AS Transportadora,
		T2.RazaoSocial AS Transportadora2,
		P.Renavam,
		P.Marca,
		P.Modelo,
		P.Chassi,
		P.AnoFabricacao,
		P.AnoModelo,
		P.Cor,
		P.TipoRastreador,
		P.NumeroAntena,
		P.Versao,
		P.CameraMonitoramento,
		P.BombaDescarga,
		P.NumeroEixos,
		P.EixosPneusDuplos,
		P.NumeroEixosPneusDuplos,
		P.IDTipoProduto,
		TP.Nome as TipoProduto,
		P.MultiSeta,
		P.IDTipoCarregamento,
		TC.Nome as TipoCarregamento,
		P.CPFCNPJ,
		P.DataNascimento,
		P.RazaoSocial,
		P.DataAtualizacao,
		P.Observacao,
		P.Principal,
		P.PossuiAbs,
		P.IDEstado,
		E.Nome AS Estado,
		P.Tara,
		c.IDStatus,
		VolumeCompartimento1 = 
			STUFF((SELECT ''/'' +CAST(A.VolumeCompartimento1 as varchar(1000))
				FROM PlacaSeta A 
				WHERE A.IDPlaca = P.ID 
				FOR XML PATH('''')), 1,1, ''''),
		VolumeCompartimento2 = 
			STUFF((SELECT ''/'' +CAST(A.VolumeCompartimento2 as varchar(1000))
				FROM PlacaSeta A 
				WHERE A.IDPlaca = P.ID 
				FOR XML PATH('''')), 1,1, ''''),
		VolumeCompartimento3 = 
			STUFF((SELECT '' / '' +CAST(A.VolumeCompartimento3 as varchar(1000))
				FROM PlacaSeta A 
				WHERE A.IDPlaca = P.ID 
				FOR XML PATH('''')), 1,1, ''''),
		VolumeCompartimento4 = 
			STUFF((SELECT ''/'' +CAST(A.VolumeCompartimento4 as varchar(1000))
				FROM PlacaSeta A 
				WHERE A.IDPlaca = P.ID 
				FOR XML PATH('''')), 1,1, ''''),
		VolumeCompartimento5 = 
			STUFF((SELECT ''/'' +CAST(A.VolumeCompartimento5 as varchar(1000))
				FROM PlacaSeta A 
				WHERE A.IDPlaca = P.ID 
				FOR XML PATH('''')), 1,1, ''''),
		VolumeCompartimento6 = 
			STUFF((SELECT ''/'' +CAST(A.VolumeCompartimento6 as varchar(1000))
				FROM PlacaSeta A 
				WHERE A.IDPlaca = P.ID 
				FOR XML PATH('''')), 1,1, ''''),
		VolumeCompartimento7 = 
			STUFF((SELECT ''/'' +CAST(A.VolumeCompartimento7 as varchar(1000))
				FROM PlacaSeta A 
				WHERE A.IDPlaca = P.ID 
				FOR XML PATH('''')), 1,1, ''''),
		VolumeCompartimento8 = 
			STUFF((SELECT ''/'' +CAST(A.VolumeCompartimento8 as varchar(1000))
				FROM PlacaSeta A 
				WHERE A.IDPlaca = P.ID 
				FOR XML PATH('''')), 1,1, ''''),
		VolumeCompartimento9 = 
			STUFF((SELECT ''/'' +CAST(A.VolumeCompartimento9 as varchar(1000))
				FROM PlacaSeta A 
				WHERE A.IDPlaca = P.ID 
				FOR XML PATH('''')), 1,1, ''''),
		VolumeCompartimento10 = 
			STUFF((SELECT ''/'' +CAST(A.VolumeCompartimento10 as varchar(1000))
				FROM PlacaSeta A 
				WHERE A.IDPlaca = P.ID 
				FOR XML PATH('''')), 1,1, ''''),
		CASE
			WHEN T.IBM IS NOT NULL THEN T.IBM
			WHEN CL.IBM IS NOT NULL THEN CL.IBM
			ELSE NULL
		END AS IBM,
		CASE
			WHEN T.IBM IS NOT NULL THEN T.RazaoSocial
			WHEN CL.IBM IS NOT NULL THEN CL.RazaoSocial
			ELSE NULL
		END AS RazaoSocialCliente,
		PD.DataVencimento DataVencimentoDoc, 
		CASE
			WHEN TD.Sigla = ''C.A.'' THEN ''CA''
			ELSE TD.Sigla
		END AS Sigla
	INTO #TEMP
	FROM VW_Placa P
	INNER JOIN TipoVeiculo TV WITH (NOLOCK) ON P.IDTipoVeiculo = TV.ID 
	LEFT JOIN Transportadora T WITH (NOLOCK) ON P.IDTransportadora = T.ID
	LEFT JOIN Transportadora T2 WITH (NOLOCK) ON P.IDTransportadora2 = T2.ID
	LEFT JOIN TipoProduto TP WITH (NOLOCK) ON P.IDTipoProduto = TP.ID
	LEFT JOIN TipoCarregamento TC WITH (NOLOCK) ON P.IDTipoCarregamento = TC.ID
	INNER JOIN CategoriaVeiculo CV WITH (NOLOCK) ON P.IDCategoriaVeiculo = CV.ID
	LEFT JOIN Estado E WITH (NOLOCK) ON P.IDEstado = E.ID
	INNER JOIN Composicao C WITH (NOLOCK) ON 
		   P.ID = C.IDPlaca1 
		OR P.ID = c.IDPlaca2 
		OR P.ID = c.IDPlaca3
		OR P.ID = c.IDPlaca4
	LEFT JOIN PlacaCliente PC WITH (NOLOCK) ON P.ID = PC.IDPlaca
	LEFT JOIN UsuarioTransportadora UT WITH (NOLOCK) ON P.IDTransportadora = UT.IDTransportadora
	LEFT JOIN UsuarioTransportadora UT2 WITH (NOLOCK) ON P.IDTransportadora2 = UT.IDTransportadora		
	LEFT JOIN UsuarioCliente UC WITH (NOLOCK) ON PC.IDCliente = UC.IDCliente 
	LEFT JOIN Cliente CL ON CL.Id = PC.IdCliente
	LEFT JOIN PlacaDocumento PD ON PD.IDPlaca = P.ID
	LEFT JOIN TipoDocumento TD ON TD.ID = PD.IDTipoDocumento
	WHERE C.IDStatus != 3 
	AND TD.TipoCadastro = 1 '
	IF (@IdPlacaOficial IS NOT NULL)
		SET @StrSQL += ' AND (P.ID = ' + CONVERT(VARCHAR(6),@IdPlacaOficial) + ') '
	IF (@Placa IS NOT NULL)
		SET @StrSQL += ' AND (P.PlacaVeiculo LIKE ''' + @Placa + ''') '
	IF (@IdEmpresa IS NOT NULL)
		SET @StrSQL += ' AND (C.IDEmpresa = ' + CONVERT(VARCHAR(1),@IdEmpresa) + ') '
	IF (@Operacao IS NOT NULL)
		SET @StrSQL += ' AND (C.Operacao = ''' + CONVERT(VARCHAR(3),@Operacao) + ''') '
	IF (@DataInicio IS NOT NULL)
	SET @StrSQL += ' AND  (C.DataAtualizacao >= ''' + CONVERT(VARCHAR(19),@DataInicio) + ''') '
	IF (@DataFim IS NOT NULL)
	SET @StrSQL += ' AND  (C.DataAtualizacao <= ''' + CONVERT(VARCHAR(19),@DataFim) + ''') '
	IF (@IDTransportadora IS NOT NULL)
		SET @StrSQL += ' AND  (P.IDTransportadora = ' + CONVERT(VARCHAR(8),@IDTransportadora) + ') '
	IF (@IDCliente IS NOT NULL)
		SET @StrSQL += ' AND  (PC.IDCliente = ' + CONVERT(VARCHAR(8),@IDCliente) + ') '
	IF (@IDStatus IS NOT NULL)
		SET @StrSQL += ' AND  (c.IDStatus = ' + CONVERT(VARCHAR(1),@IDStatus) + ') '
	IF (@IDUsuarioTransportadora IS NOT NULL)
		SET @StrSQL += ' AND  (UT.IDUsuario = ' + CONVERT(VARCHAR(8),@IDUsuarioTransportadora) + ') '
	IF (@IDUsuarioTransportadora IS NOT NULL)	
		SET @StrSQL += ' AND  ((C.IDEmpresa = 3 
			AND    (UT2.IDUsuario = ' + CONVERT(VARCHAR(8),@IDUsuarioTransportadora) +'))
			OR (C.IDEmpresa <> 3)) '
	IF (@IDUsuarioCliente IS NOT NULL)
		SET @StrSQL += ' AND  (UC.IDUsuario = ' + CONVERT(VARCHAR(8),@IDUsuarioCliente) + ') '
	IF (@Chamado IS NOT NULL)
		SET @StrSQL += ' AND  (C.CodigoEasyQuery LIKE ''' + @Chamado + ''') '
	IF (@IDTipoComposicao IS NOT NULL)	
		SET @StrSQL += ' AND  (C.IDTipoComposicao = ' + CONVERT(VARCHAR(8),@IDTipoComposicao) + ') '

	SET @StrSQL +=
	'GROUP BY
	P.ID, 
		P.PlacaVeiculo, 
		P.Operacao, 
		P.IDTipoVeiculo,
		TV.Nome,
		P.IDTransportadora,
		P.IDTransportadora2,
		P.IDCategoriaVeiculo,
		CV.Nome,
		T.RazaoSocial,
		T2.RazaoSocial,
		P.Renavam,
		P.Marca,
		P.Modelo,
		P.Chassi,
		P.AnoFabricacao,
		P.AnoModelo,
		P.Cor,
		P.TipoRastreador,
		P.NumeroAntena,
		P.Versao,
		P.CameraMonitoramento,
		P.BombaDescarga,
		P.NumeroEixos,
		P.EixosPneusDuplos,
		P.NumeroEixosPneusDuplos,
		P.IDTipoProduto,
		TP.Nome,
		P.MultiSeta,
		P.IDTipoCarregamento,
		TC.Nome,
		P.CPFCNPJ,
		P.DataNascimento,
		P.RazaoSocial,
		P.DataAtualizacao,
		P.Observacao,
		P.Principal,
		P.PossuiAbs,
		P.IDEstado,
		E.Nome,
		P.Tara,
		c.IDStatus, 
		CASE
			WHEN T.IBM IS NOT NULL THEN T.IBM
			WHEN CL.IBM IS NOT NULL THEN CL.IBM
			ELSE NULL
		END,
		CASE
			WHEN T.IBM IS NOT NULL THEN T.RazaoSocial
			WHEN CL.IBM IS NOT NULL THEN CL.RazaoSocial
			ELSE NULL
		END,
		PD.DataVencimento, 
		TD.Sigla
		order by P.ID'

	SET @StrSQL += ' SELECT * FROM #TEMP '

	SET @StrSQL += 'PIVOT(MAX(DataVencimentoDoc) FOR Sigla IN (' + @cols + ')) AS DataPorDoc'

	EXEC(@strSQL)

	PRINT(@strSQL)
END
GO


