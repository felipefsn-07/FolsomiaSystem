﻿USE UniCad
GO

-- [CSON-2698 - Inicio]

IF COL_LENGTH('dbo.MotoristaDocumento', 'Processado') IS NULL 
BEGIN
	ALTER TABLE dbo.MotoristaDocumento ADD Processado BIT 
	CONSTRAINT MotoristaDocumento_Processado_Default DEFAULT 0 NOT NULL
END

-- [CSON-2698 - Fim]
