﻿USE UniCad
GO

-- [CSON-2698 - Inicio]

IF COL_LENGTH('dbo.PlacaDocumento', 'Processado') IS NULL 
BEGIN
	ALTER TABLE dbo.PlacaDocumento ADD Processado BIT 
		CONSTRAINT PlacaDocumento_Processado_Default DEFAULT 0 NOT NULL
END

-- [CSON-2698 - Fim]
