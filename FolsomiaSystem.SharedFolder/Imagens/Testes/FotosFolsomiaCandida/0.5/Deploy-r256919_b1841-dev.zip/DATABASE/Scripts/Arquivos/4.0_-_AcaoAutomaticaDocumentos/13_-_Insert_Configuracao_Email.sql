USE UniCad
GO

IF COL_LENGTH('dbo.Configuracao', 'IdPais') IS NULL 
BEGIN
	-- Ve�culo Aprovado
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloVeiculoAprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloVeiculoAprovado'', ''T�tulo do e-mail para ve�culo aprovado'', 
		''Ra�zen -  Cadastro de Ve�culo Aprovado'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoVeiculoAprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoVeiculoAprovado'', ''Corpo do e-mail para ve�culo aprovado'', 
		''Ol�, informamos que a solicita��o para cadastro do seu ve�culo foi APROVADA. <br/><br/>
		As placas {0} j� poder�o realizar carregamentos em nossos terminais de distribui��o. <br/><br/>
		Lembrando que voc� dever� acompanhar as datas de vencimento do seu ve�culo para atualiza��o, pois caso o ve�culo se apresente nos terminais com algum documento vencido no sistema, poder� ter problemas no carregamento. <br/><br/>
		Para te ajudar e evitar o excesso de peso com seu  ve�culo, abaixo capacidade m�xima de carregamento por produto. <br/>
		Lembrando que a informa��o acima � uma estimativa, e o carregamento s� n�o ser� permitido se no momento do ingresso de pedido/carregamento acusar excesso de peso.<br/><br/>
		{1} <br/>
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Ve�culo Reprovado
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloVeiculoReprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloVeiculoReprovado'', ''T�tulo do e-mail para ve�culo reprovado'', 
		''Ra�zen -  Cadastro de Ve�culo Reprovado'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoVeiculoReprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoVeiculoReprovado'', ''Corpo do e-mail para ve�culo reprovado'', 
		''Ol�, informamos que a solicita��o para cadastro de seu ve�culo foi reprovada. <br/>
		O motivo poder� ser consultado via sistema Csonline no menu "Cadastro de Ve�culos". <br/><br/>
		Placas: {0} <br/><br/> 
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Motorista Aprovado
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloMotoristaAprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloMotoristaAprovado'', ''T�tulo do e-mail para motorista aprovado'', 
		''Ra�zen -  Cadastro de Motorista Aprovado'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoMotoristaAprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoMotoristaAprovado'', ''Corpo do e-mail para motorista aprovado'', 
		''Ol�, o cadastro para o motorista {0} CPF {1}  foi aprovado, permitindo o carregamento em nossos terminais de distribui��o. <br/><br/>
		Lembrando que voc� dever� acompanhar o vencimento da documenta��o de seu motorista para atualiza��o, pois caso o motorista se apresente nos terminais com algum documento vencido no sistema, poder� ter problemas no carregamento. <br/><br/>
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Motorista Reprovado
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloMotoristaReprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloMotoristaReprovado'', ''T�tulo do e-mail para motorista reprovado'', 
		''Ra�zen -  Cadastro de Motorista Reprovado'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoMotoristaReprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoMotoristaReprovado'', ''Corpo do e-mail para motorista reprovado'', 
		''Ol�, informamos que a solicita��o para cadastro de seu motorista foi reprovada. <br/>
		O motivo poder� ser consultado via sistema Csonline no menu "Cadastro de Motoristas". <br/><br/>
		Nome: {0} <br/>
		CPF: {1} <br/><br/> 
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Alerta Vencimento Documento Ve�culo
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloVeiculoAlertaVencimento')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloVeiculoAlertaVencimento'', ''T�tulo do e-mail para alerta de vencimento de documentos dos ve�culos'', 
		''Ra�zen -  Alerta de Vencimento de Documento'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoVeiculoAlertaVencimento')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoVeiculoAlertaVencimento'', ''Corpo do e-mail para alerta de vencimento de documentos dos ve�culos'', 
		''Ol�, informamos que os ve�culos que possuem o(s) documento(s) abaixo que ir�(�o) vencer, o que ir� impossibilitar o carregamento em nossos terminais a partir dessa data.<br/><br/>
		{0} <br/>
		Para regulariza��o da documenta��o, por gentileza, acessar o sistema Csonline e no menu "Solicita��es"  - "Cadastro de Ve�culos" realizar o envio dos documentos para atualiza��o. <br/><br/> 
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Alerta Vencimento Documento Motorista
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloMotoristaAlertaVencimento')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloMotoristaAlertaVencimento'', ''T�tulo do e-mail para alerta de vencimento de documentos dos motoristas'', 
		''Ra�zen -  Alerta de Vencimento de Documento'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoMotoristaAlertaVencimento')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoMotoristaAlertaVencimento'', ''Corpo do e-mail para alerta de vencimento de documentos dos motoristas'', 
		''Ol�, informamos que os cadastros dos motoristas possui o(s) documento(s) abaixo que ir�(�o) vencer, o que ir� impossibilitar o carregamento em nossos terminais a partir dessa data. <br/><br/>
		{0} <br/>
		Para regulariza��o do cadastro, por gentileza, acessar via sistema Csonline no menu "Cadastro de Motoristas" e realizar o envio dos documentos para atualiza��o. <br/><br/> 
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Checklist
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloChecklist')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloChecklist'', ''T�tulo do e-mail de checklist'', 
		''Ra�zen - CheckList'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoChecklist')
		EXEC('INSERT INTO Configuracao VALUES	
		(''CorpoChecklist'', ''Corpo do e-mail de checklist'', 
		''Caro {0}, <br/>
		Sua composi��o teve o checklist {1}. Seguem as informa��es: <br/>
		Placas: {2} <br/>
		Justificativa: {3} <br/>
		Caso tenha d�vidas, favor entrar em contato com a Central de Cadastros Ra�zen. <br/>
		D�vidas? Entre em contato com a Ra�zen!'',
		GETDATE(), GETDATE(), NULL)')
END
ELSE
BEGIN
	-- Ve�culo Aprovado
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloVeiculoAprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloVeiculoAprovado'', ''T�tulo do e-mail para ve�culo aprovado'', 
		''Ra�zen -  Cadastro de Ve�culo Aprovado'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoVeiculoAprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoVeiculoAprovado'', ''Corpo do e-mail para ve�culo aprovado'', 
		''Ol�, informamos que a solicita��o para cadastro do seu ve�culo foi APROVADA. <br/><br/>
		As placas {0} j� poder�o realizar carregamentos em nossos terminais de distribui��o. <br/><br/>
		Lembrando que voc� dever� acompanhar as datas de vencimento do seu ve�culo para atualiza��o, pois caso o ve�culo se apresente nos terminais com algum documento vencido no sistema, poder� ter problemas no carregamento. <br/><br/>
		Para te ajudar e evitar o excesso de peso com seu  ve�culo, abaixo capacidade m�xima de carregamento por produto. <br/>
		Lembrando que a informa��o acima � uma estimativa, e o carregamento s� n�o ser� permitido se no momento do ingresso de pedido/carregamento acusar excesso de peso.<br/><br/>
		{1} <br/>
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Ve�culo Reprovado
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloVeiculoReprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloVeiculoReprovado'', ''T�tulo do e-mail para ve�culo reprovado'', 
		''Ra�zen -  Cadastro de Ve�culo Reprovado'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoVeiculoReprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoVeiculoReprovado'', ''Corpo do e-mail para ve�culo reprovado'', 
		''Ol�, informamos que a solicita��o para cadastro de seu ve�culo foi reprovada. <br/>
		O motivo poder� ser consultado via sistema Csonline no menu "Cadastro de Ve�culos". <br/><br/>
		Placas: {0} <br/><br/> 
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Motorista Aprovado
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloMotoristaAprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloMotoristaAprovado'', ''T�tulo do e-mail para motorista aprovado'', 
		''Ra�zen -  Cadastro de Motorista Aprovado'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoMotoristaAprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoMotoristaAprovado'', ''Corpo do e-mail para motorista aprovado'', 
		''Ol�, o cadastro para o motorista {0} CPF {1}  foi aprovado, permitindo o carregamento em nossos terminais de distribui��o. <br/><br/>
		Lembrando que voc� dever� acompanhar o vencimento da documenta��o de seu motorista para atualiza��o, pois caso o motorista se apresente nos terminais com algum documento vencido no sistema, poder� ter problemas no carregamento. <br/><br/>
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Motorista Reprovado
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloMotoristaReprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloMotoristaReprovado'', ''T�tulo do e-mail para motorista reprovado'', 
		''Ra�zen -  Cadastro de Motorista Reprovado'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoMotoristaReprovado')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoMotoristaReprovado'', ''Corpo do e-mail para motorista reprovado'', 
		''Ol�, informamos que a solicita��o para cadastro de seu motorista foi reprovada. <br/>
		O motivo poder� ser consultado via sistema Csonline no menu "Cadastro de Motoristas". <br/><br/>
		Nome: {0} <br/>
		CPF: {1} <br/><br/> 
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Alerta Vencimento Documento Ve�culo
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloVeiculoAlertaVencimento')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloVeiculoAlertaVencimento'', ''T�tulo do e-mail para alerta de vencimento de documentos dos ve�culos'', 
		''Ra�zen -  Alerta de Vencimento de Documento'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoVeiculoAlertaVencimento')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoVeiculoAlertaVencimento'', ''Corpo do e-mail para alerta de vencimento de documentos dos ve�culos'', 
		''Ol�, informamos que os ve�culos que possuem o(s) documento(s) abaixo que ir�(�o) vencer, o que ir� impossibilitar o carregamento em nossos terminais a partir dessa data.<br/><br/>
		{0} <br/>
		Para regulariza��o da documenta��o, por gentileza, acessar o sistema Csonline e no menu "Solicita��es"  - "Cadastro de Ve�culos" realizar o envio dos documentos para atualiza��o. <br/><br/> 
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Alerta Vencimento Documento Motorista
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloMotoristaAlertaVencimento')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloMotoristaAlertaVencimento'', ''T�tulo do e-mail para alerta de vencimento de documentos dos motoristas'', 
		''Ra�zen -  Alerta de Vencimento de Documento'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoMotoristaAlertaVencimento')
		EXEC('INSERT INTO Configuracao VALUES
		(''CorpoMotoristaAlertaVencimento'', ''Corpo do e-mail para alerta de vencimento de documentos dos motoristas'', 
		''Ol�, informamos que os cadastros dos motoristas possui o(s) documento(s) abaixo que ir�(�o) vencer, o que ir� impossibilitar o carregamento em nossos terminais a partir dessa data. <br/><br/>
		{0} <br/>
		Para regulariza��o do cadastro, por gentileza, acessar via sistema Csonline no menu "Cadastro de Motoristas" e realizar o envio dos documentos para atualiza��o. <br/><br/> 
		Caso tenha alguma d�vida, por gentileza, entrar em contato com a nossa Central de Atendimento 0300 789 8282 / 0800 789 8282.'',
		GETDATE(), GETDATE(), NULL)')
	-- Checklist
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'TituloChecklist')
		EXEC('INSERT INTO Configuracao VALUES
		(''TituloChecklist'', ''T�tulo do e-mail de checklist'', 
		''Ra�zen - CheckList'', GETDATE(), GETDATE(), NULL)')
	IF NOT EXISTS (SELECT 1 FROM Configuracao WHERE NmVariavel = 'CorpoChecklist')
		EXEC('INSERT INTO Configuracao VALUES	
		(''CorpoChecklist'', ''Corpo do e-mail de checklist'', 
		''Caro {0}, <br/>
		Sua composi��o teve o checklist {1}. Seguem as informa��es: <br/>
		Placas: {2} <br/>
		Justificativa: {3} <br/>
		Caso tenha d�vidas, favor entrar em contato com a Central de Cadastros Ra�zen. <br/>
		D�vidas? Entre em contato com a Ra�zen!'',
		GETDATE(), GETDATE(), NULL)')
END