USE UniCad
GO

IF NOT EXISTS(SELECT 1 FROM sys.columns WHERE  [object_id] = OBJECT_ID('[DBO].[Usuario]') AND UPPER(NAME) = 'IDPais')
BEGIN

ALTER TABLE Usuario ADD IDPais int not null default 1;

ALTER TABLE [dbo].[Usuario]  WITH CHECK ADD  CONSTRAINT [FK_Usuario_Pais] FOREIGN KEY([IDPais])
REFERENCES [dbo].[Pais] ([ID])

ALTER TABLE [dbo].[Usuario] CHECK CONSTRAINT [FK_Usuario_Pais]

END