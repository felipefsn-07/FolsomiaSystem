/***********************************************************
* 0) SELE��O DO BD
************************************************************/
USE Unicad

GO

/***********************************************************
* 1) RECRIANDO AS FKS NA VEICULO
************************************************************/

--1.1) Dropando a constraint se ela existir caso ela NAO EXISTA
IF OBJECT_ID('dbo.[FK_PlacaBrasil_PlacaID]') IS NOT NULL 
    ALTER TABLE dbo.[PlacaBrasil] DROP CONSTRAINT [FK_PlacaBrasil_PlacaID]

--1.2) Criar a contrainst novamente com CASCADE DELETE
ALTER TABLE dbo.[PlacaBrasil] 
	ADD CONSTRAINT [FK_PlacaBrasil_PlacaID] FOREIGN KEY ([IDPlaca]) REFERENCES Placa(ID) ON DELETE CASCADE;

--1.3) Dropando a constraint se ela existir caso ela NAO EXISTA
IF OBJECT_ID('dbo.[FK_PlacaArgentina_PlacaID]') IS NOT NULL 
    ALTER TABLE dbo.[PlacaArgentina] DROP CONSTRAINT [FK_PlacaArgentina_PlacaID]

--1.4) Criar a contrainst novamente com CASCADE DELETE
ALTER TABLE dbo.[PlacaArgentina] 
	ADD CONSTRAINT [FK_PlacaArgentina_PlacaID] FOREIGN KEY ([IDPlaca]) REFERENCES Placa(ID) ON DELETE CASCADE;


/***********************************************************
* 2) RECRIANDO AS FKS NA MOTORISTA
************************************************************/

--1.1) Dropando a constraint se ela existir caso ela NAO EXISTA
IF OBJECT_ID('dbo.[FK_MotoristaBrasil_MotoristaID]') IS NOT NULL 
    ALTER TABLE dbo.[MotoristaBrasil] DROP CONSTRAINT [FK_MotoristaBrasil_MotoristaID]

--1.2) Criar a contrainst novamente com CASCADE DELETE
ALTER TABLE dbo.[MotoristaBrasil] 
	ADD CONSTRAINT [FK_MotoristaBrasil_MotoristaID] FOREIGN KEY ([IDMotorista]) REFERENCES Motorista(ID) ON DELETE CASCADE;

--1.3) Dropando a constraint se ela existir caso ela NAO EXISTA
IF OBJECT_ID('dbo.[FK_MotoristaArgentina_MotoristaID]') IS NOT NULL 
    ALTER TABLE dbo.[MotoristaArgentina] DROP CONSTRAINT [FK_MotoristaArgentina_MotoristaID]

--1.4) Criar a contrainst novamente com CASCADE DELETE
ALTER TABLE dbo.[MotoristaArgentina] 
	ADD CONSTRAINT [FK_MotoristaArgentina_MotoristaID] FOREIGN KEY ([IDMotorista]) REFERENCES Motorista(ID) ON DELETE CASCADE;
