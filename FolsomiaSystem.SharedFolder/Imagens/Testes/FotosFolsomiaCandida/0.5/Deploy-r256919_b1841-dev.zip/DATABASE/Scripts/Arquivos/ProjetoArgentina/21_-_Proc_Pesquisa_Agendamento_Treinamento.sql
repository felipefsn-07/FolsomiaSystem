/***********************************************************
* 0) SELECAO DA BASE E CONFIGURACOES INICAIS
************************************************************/
USE UniCad
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/***********************************************************
* 1) AJUSTE NA PROCEDURE
************************************************************/

--1.1) Verifica se ja existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Pesquisa_Agendamento_Treinamento')
    DROP PROCEDURE [Proc_Pesquisa_Agendamento_Treinamento];
GO

--1.2) Recriar a procedure ajustada
CREATE PROCEDURE [dbo].[Proc_Pesquisa_Agendamento_Treinamento]
	@IsCount BIT = 0,
	@PrimeiraPagina INT = NULL,
	@UltimaPagina INT = NULL,
	@ID INT = NULL,
	@IDEmpresa INT = NULL,
	@Operacao VARCHAR(3) = NULL,
	@Nome VARCHAR(100) = NULL,
	@DataInicio DATE = NULL,
	@DataFim DATE = NULL,
	@CPF VARCHAR(11) = NULL,
	@IDTerminal INT = NULL,
	@IDTipoTreinamento INT = NULL,
	@IDUsuarioTransportadora INT = NULL,
	@IDUsuarioCliente INT = NULL

AS
BEGIN
	--Utiliza��o de query din�mica conforme sugest�o de melhoria do DBA
	DECLARE @StrSQL VARCHAR(8000)  

	
	IF (@IsCount = 1) 
	BEGIN
		SET @strSQL = 
		'SELECT COUNT(*) AS Linhas '
	END
	ELSE
	BEGIN
		SET @StrSQL = 
		'SELECT 
			RowNum,
			ID,
            Data,
			Empresa,
			Operacao,
			Motorista,
            SiglaTerminal,
            Terminal,
            EnderecoTerminal,
            CidadeTerminal,
            EstadoTerminal,
			HoraInicio,
			HoraFim,
			TipoTreinamento,
			CPF,
			idSituacao,
			Usuario'		
	END
	SET @StrSQL +='
			FROM (
			SELECT 
				ROW_NUMBER() OVER ( ORDER BY Ag.Data DESC ) AS RowNum,
				ag.ID, 
				ag.Data,
				CASE WHEN ag.IdEmpresaCongenere > 0 THEN Empresa.Nome ELSE  Emp.Nome END AS Empresa,
				CASE WHEN ag.IdEmpresaCongenere > 0 THEN ''Cong�nere'' ELSE  mot.Operacao END AS Operacao, 			
				CASE WHEN ag.IdEmpresaCongenere > 0 THEN ag.NomeMotorista ELSE  mot.Nome END AS Motorista,	
				T.Sigla as SiglaTerminal,
				T.Nome as Terminal,
				T.Endereco as EnderecoTerminal,
				T.Cidade as CidadeTerminal,
				Estado.Nome as EstadoTerminal,
				agth.HoraInicio,
				agth.HoraFim,
				ta.Nome as TipoTreinamento,
				CASE WHEN ag.IdEmpresaCongenere > 0 THEN ag.CPFCongenere ELSE  mot.CPF END AS CPF,
				ag.idSituacao,
				U.Nome as Usuario
			FROM AgendamentoTreinamento ag WITH (NOLOCK)
			INNER JOIN AgendamentoTerminalHorario agth WITH (NOLOCK) ON ag.IDAgendamentoTerminalHorario = agth.ID
			INNER JOIN AgendamentoTerminal agt WITH (NOLOCK) ON agth.IDAgendamentoTerminal = agt.ID
			INNER JOIN TipoAgenda ta WITH (NOLOCK) ON agt.IDTipoAgenda = ta.ID
			INNER JOIN Terminal T WITH (NOLOCK) ON agt.IDTerminal = T.ID
			INNER JOIN Estado WITH (NOLOCK) ON T.IDEstado = Estado.ID
			LEFT JOIN VW_Motorista mot WITH (NOLOCK) ON ag.IDMotorista = mot.ID
			LEFT JOIN Empresa Emp WITH (NOLOCK) ON mot.IDEmpresa = Emp.ID
			LEFT JOIN Usuario U WITH (NOLOCK) ON ag.Usuario = U.Login
			LEFT JOIN UsuarioTransportadora UT WITH (NOLOCK) ON mot.IDTransportadora = UT.IDTransportadora
			LEFT JOIN MotoristaCliente MC WITH (NOLOCK) ON mot.ID = MC.IDMotorista
			LEFT JOIN UsuarioCliente UC WITH (NOLOCK) ON MC.IDCliente = UC.IDCliente
			LEFT JOIN Empresa  WITH (NOLOCK) ON agth.IDEmpresa = Empresa.ID
			WHERE agt.Ativo = 1'
			
		IF (@IDEmpresa IS NOT NULL)
			SET @StrSQL += ' AND (mot.IDEmpresa = ' +  CONVERT(VARCHAR(1),@IDEmpresa) +')'
		IF (@Operacao IS NOT NULL)
		BEGIN
			IF (@Operacao = 'CON')
			BEGIN
				SET @StrSQL += ' AND (agth.Operacao = '''  + @Operacao + ''')'
			END 
			ELSE
			BEGIN
				SET @StrSQL += ' AND (mot.Operacao = '''  + @Operacao + ''')'
			END
		END
		IF (@Nome IS NOT NULL)
			SET @StrSQL += ' AND (mot.Nome  LIKE ''%' + @Nome +'%'')'
		IF (@DataInicio IS NOT NULL)
			SET @StrSQL += ' AND (ag.Data >= ''' + CONVERT(VARCHAR(19),@DataInicio) +''')'
		IF (@DataFim IS NOT NULL)
			SET @StrSQL += ' AND (ag.Data  <= ''' + CONVERT(VARCHAR(19),@DataFim) +''')'
		IF (@CPF IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND (mot.CPF =  ''' + @CPF +''')'
		END
		IF (@ID IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND (ag.ID =  ' + CONVERT(VARCHAR(10),@ID) +')'
		END
		IF (@IDTerminal IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND (agt.IDTerminal =  ' + CONVERT(VARCHAR(10),@IDTerminal) +')'
		END
		IF (@IDTipoTreinamento IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND (ta.IDTipo =  ' + CONVERT(VARCHAR(10),@IDTipoTreinamento) +')'
		END 
		ELSE
		BEGIN
			SET @StrSQL += ' AND (ta.IDTipo IN (2,3))  ' --treinamento te�rico e pr�tico vide enum no c�digo
		END
		IF(@IDUsuarioTransportadora IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND (UT.IDUsuario =   '+ CONVERT(VARCHAR(10),@IDUsuarioTransportadora) +')'
		END
		IF (@IDUsuarioCliente IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND (UC.IDUsuario ='   + CONVERT(VARCHAR(10),@IDUsuarioCliente) +')'
		END
		SET @StrSQL += ' 
				GROUP BY	
					ag.ID, 
					ag.Data,
					ag.NomeMotorista,
					ag.CPFCongenere,
					ag.IdEmpresaCongenere,
					agth.Operacao,
					Emp.Nome,
					Empresa.Nome,
					mot.Operacao, 			
					mot.Nome,	
					T.Sigla,
					T.Nome,
					T.Endereco,
					T.Cidade,
					Estado.Nome,
					agth.HoraInicio,
					agth.HoraFim,
					ta.Nome,
					mot.CPF,
					ag.idSituacao,
					U.Nome
				)  AS Motorista '
		IF (@PrimeiraPagina IS NOT NULL)
			SET @StrSQL += 'WHERE Motorista.RowNum > ' + CONVERT(VARCHAR(5),@PrimeiraPagina) 
		IF (@UltimaPagina IS NOT NULL)
			SET @StrSQL += 'AND Motorista.RowNum <= '  + CONVERT(VARCHAR(5),@UltimaPagina)
	EXEC (@StrSQL)
	PRINT (@StrSql)
END

GO