USE [UniCad]
GO

IF EXISTS (SELECT 1 FROM SYS.TABLES WHERE NAME = 'Pais')
BEGIN
	IF(SELECT COUNT(1) FROM Pais WHERE Nome LIKE 'Padr�o' AND ID = 3) <= 0
	INSERT INTO [dbo].[Pais]
           ([ID]
           ,[Nome]
           ,[Sigla]
           ,[Bandeira]
           ,[LinguagemPadrao]
           ,[StAtivo])
     VALUES
           (3
           ,'Padr�o'
           ,''
           ,''
           ,''
           ,1);
END