/***********************************************************
* 0) SELEÇÃO DA BASE E CONFIGURAÇÕES INICAIS
************************************************************/
USE Unicad
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/***********************************************************
* 1) AJUSTE NA PROCEDURE
************************************************************/

--1.1) Verifica se já existe e dropa
IF EXISTS (SELECT 1 FROM sys.procedures WHERE Name = 'Proc_Pesquisa_Agendamento_Checklist')
    DROP PROCEDURE [Proc_Pesquisa_Agendamento_Checklist];
GO

--1.2) Recriar a procedure ajustada
--exec Proc_Pesquisa_Agendamento_Checklist 0, 0, 10,2,2
CREATE PROCEDURE [dbo].[Proc_Pesquisa_Agendamento_Checklist]
	@IsCount BIT = 0,
	@PrimeiraPagina INT = NULL,
	@UltimaPagina INT = NULL,
	@IDEmpresa INT = NULL,
	@IDStatus INT = NULL,
	@Operacao VARCHAR(3) = NULL,
	@IDTipoComposicao INT = NULL,
	@DataInicio DATE = NULL,
	@DataFim DATE = NULL,
	@Placa VARCHAR(10) = NULL,
	@IDTransportadora INT = NULL,
	@IDUsuarioTransportadora INT = NULL,	
	@IDCliente INT = NULL,
	@IDUsuarioCliente INT = NULL,
	@IDTerminal INT = NULL
AS
BEGIN
	--Utilização de query dinâmica conforme sugestão de melhoria do DBA
	DECLARE @StrSQL VARCHAR(8000)  
	DECLARE @DtInicio DATETIME = NULL
	DECLARE @DtFim DATETIME = NULL


	IF @DataInicio IS NOT NULL
		SET @DtInicio = @DataInicio
	IF @DataFim IS NOT NULL
		SET @DtFim = @DataFim	
	IF (@IsCount = 1) 
	BEGIN
		SET @strSQL = 
		'SELECT COUNT(*) AS Linhas '
	END
	ELSE
	BEGIN
		SET @StrSQL = 
		'SELECT 
			RowNum,
			ID, 
			Data,
			Horario,
			HoraInicio,
			Empresa,		
			Operacao, 				
			TipoComposicao,
			Placa1,
			Placa2,
			Placa3,
			Placa4,			
			Terminal'		
	END
	SET @StrSQL +='
			FROM (
			SELECT 
			ROW_NUMBER() OVER ( ORDER BY Data DESC ) AS RowNum,
			ID, 
			Data,
			Horario,
			HoraInicio,
			Empresa,		
			Operacao, 				
			TipoComposicao,
			Placa1,
			Placa2,
			Placa3,
			Placa4,			
			Terminal
			FROM (
			SELECT 
				Ag.ID, 
				Ag.Data as Data,
				convert(varchar(5), agth.HoraInicio) as Horario,
				agth.HoraInicio as HoraInicio,
				Emp.Nome AS Empresa,
				Comp.Operacao, 		
				agth.Operacao AS OperacaoFiltro,		
				Comp.IDStatus,
				TC.ID AS IdTipoComposicao,
				TC.Nome AS TipoComposicao,
				CE.Codigo AS TipoComposicaoEixo,
				CV.Nome AS CategoriaVeiculo,
				Placa1.PlacaVeiculo AS Placa1,
				Placa2.PlacaVeiculo AS Placa2,
				Placa3.PlacaVeiculo AS Placa3,
				Placa4.PlacaVeiculo AS Placa4,
				Terminal.Nome as Terminal,
				EMP.ID AS IDEmpresa,
				Placa1.IDTransportadora AS IDTransportadora1,
				Placa2.IDTransportadora AS IDTransportadora2,
				Placa3.IDTransportadora AS IDTransportadora3,
				Placa4.IDTransportadora AS IDTransportadora4,
				UT1.IDUsuario AS IDUsuario1, 
				UT2.IDUsuario AS IDUsuario2,
				UT3.IDUsuario AS IDUsuario3,
				UT4.IDUsuario AS IDUsuario4,
				UT5.IDUsuario AS IDUsuario5, 
				UT6.IDUsuario AS IDUsuario6,
				UT7.IDUsuario AS IDUsuario7,
				UT8.IDUsuario AS IDUsuario8,
				PC1.IDCliente AS IDCliente1,
				PC2.IDCliente AS IDCliente2,
				PC3.IDCliente AS IDCliente3,
				PC4.IDCliente AS IDCliente4,
				UC1.IDUsuario AS IDUsuarioCliente1,
				UC2.IDUsuario AS IDUsuarioCliente2,
				UC3.IDUsuario AS IDUsuarioCliente3,
				UC4.IDUsuario AS IDUsuarioCliente4 
			FROM AgendamentoChecklist ag WITH (NOLOCK)
			INNER JOIN AgendamentoTerminalHorario agth WITH (NOLOCK) ON ag.IDAgendamentoTerminalHorario = agth.ID
			INNER JOIN AgendamentoTerminal agt WITH (NOLOCK) ON agth.IDAgendamentoTerminal = agt.ID
			INNER JOIN Terminal Terminal WITH (NOLOCK) ON agt.IDTerminal = Terminal.ID
			INNER JOIN Composicao Comp WITH (NOLOCK) ON ag.IDComposicao = comp.ID
			INNER JOIN Empresa Emp WITH (NOLOCK) ON Comp.IDEmpresa = Emp.ID
			INNER JOIN TipoComposicao TC WITH (NOLOCK) ON Comp.IDTipoComposicao = TC.ID
			INNER JOIN ComposicaoEixo CE WITH (NOLOCK) ON Comp.IDTipoComposicaoEixo = CE.ID
			INNER JOIN CategoriaVeiculo CV WITH (NOLOCK) ON Comp.IDCategoriaVeiculo = CV.ID
			LEFT JOIN VW_Placa Placa1 WITH (NOLOCK) ON Comp.IDPlaca1 = Placa1.ID
			LEFT JOIN VW_Placa Placa2 WITH (NOLOCK) ON Comp.IDPlaca2 = Placa2.ID
			LEFT JOIN VW_Placa Placa3 WITH (NOLOCK) ON Comp.IDPlaca3 = Placa3.ID
			LEFT JOIN VW_Placa Placa4 WITH (NOLOCK) ON Comp.IDPlaca4 = Placa4.ID
			LEFT JOIN UsuarioTransportadora UT1 WITH (NOLOCK) ON Placa1.IDTransportadora = UT1.IDTransportadora
			LEFT JOIN UsuarioTransportadora UT2 WITH (NOLOCK) ON Placa2.IDTransportadora = UT2.IDTransportadora
			LEFT JOIN UsuarioTransportadora UT3 WITH (NOLOCK) ON Placa3.IDTransportadora = UT3.IDTransportadora
			LEFT JOIN UsuarioTransportadora UT4 WITH (NOLOCK) ON Placa4.IDTransportadora = UT4.IDTransportadora
			LEFT JOIN UsuarioTransportadora UT5 WITH (NOLOCK) ON Placa1.IDTransportadora2 = UT5.IDTransportadora
			LEFT JOIN UsuarioTransportadora UT6 WITH (NOLOCK) ON Placa2.IDTransportadora2 = UT6.IDTransportadora
			LEFT JOIN UsuarioTransportadora UT7 WITH (NOLOCK) ON Placa3.IDTransportadora2 = UT7.IDTransportadora
			LEFT JOIN UsuarioTransportadora UT8 WITH (NOLOCK) ON Placa4.IDTransportadora2 = UT8.IDTransportadora
			LEFT JOIN PlacaCliente PC1 WITH (NOLOCK) ON Comp.IDPlaca1 = PC1.IDPlaca
			LEFT JOIN PlacaCliente PC2 WITH (NOLOCK) ON Comp.IDPlaca2 = PC2.IDPlaca
			LEFT JOIN PlacaCliente PC3 WITH (NOLOCK) ON Comp.IDPlaca3 = PC3.IDPlaca
			LEFT JOIN PlacaCliente PC4 WITH (NOLOCK) ON Comp.IDPlaca4 = PC4.IDPlaca   
			LEFT JOIN UsuarioCliente UC1 WITH (NOLOCK) ON PC1.IDCliente = UC1.IDCliente
			LEFT JOIN UsuarioCliente UC2 WITH (NOLOCK) ON PC2.IDCliente = UC2.IDCliente
			LEFT JOIN UsuarioCliente UC3 WITH (NOLOCK) ON PC3.IDCliente = UC3.IDCliente
			LEFT JOIN UsuarioCliente UC4 WITH (NOLOCK) ON PC4.IDCliente = UC4.IDCliente
			UNION 
			SELECT
				Ag.ID, 
				Ag.Data as Data,
				convert(varchar(5), agth.HoraInicio) as Horario,
				agth.HoraInicio as HoraInicio,
				Emp.Nome AS Empresa,
				''Congênere'' AS Operacao, 	
				agth.Operacao AS OperacaoFiltro,			
				2 AS IDStatus,
				TC.ID AS IdTipoComposicao,
				TC.Nome AS TipoComposicao,
				NULL AS TipoComposicaoEixo,
				NULL AS CategoriaVeiculo,
				ag.PlacaCongenere AS Placa1,
				NULL AS Placa2,
				NULL AS Placa3,
				NULL AS Placa4,
				Terminal.Nome as Terminal,
				EMP.ID AS IDEmpresa,
				NULL AS IDTransportadora1,
				NULL AS IDTransportadora2,
				NULL AS IDTransportadora3,
				NULL AS IDTransportadora4,
				NULL AS IDUsuario1, 
				NULL AS IDUsuario2,
				NULL AS IDUsuario3,
				NULL AS IDUsuario4,
				NULL AS IDUsuario5, 
				NULL AS IDUsuario6,
				NULL AS IDUsuario7,
				NULL AS IDUsuario8,
				NULL AS IDCliente1,
				NULL AS IDCliente2,
				NULL AS IDCliente3,
				NULL AS IDCliente4,
				NULL AS IDUsuarioCliente1,
				NULL AS IDUsuarioCliente2,
				NULL AS IDUsuarioCliente3,
				NULL AS IDUsuarioCliente4 
			FROM AgendamentoChecklist ag WITH (NOLOCK)
			INNER JOIN AgendamentoTerminalHorario agth WITH (NOLOCK) ON ag.IDAgendamentoTerminalHorario = agth.ID
			INNER JOIN AgendamentoTerminal agt WITH (NOLOCK) ON agth.IDAgendamentoTerminal = agt.ID
			INNER JOIN Terminal Terminal WITH (NOLOCK) ON agt.IDTerminal = Terminal.ID
			INNER JOIN Empresa Emp WITH (NOLOCK) ON agth.IDEmpresa = Emp.ID
			INNER JOIN TipoComposicao TC WITH (NOLOCK) ON ag.IDTipoComposicaoCongenere = TC.ID 
		) AS Comp 
		WHERE 1=1 '
		IF (@IDEmpresa IS NOT NULL)
			SET @StrSQL += ' AND (IDEmpresa = ' +  CONVERT(VARCHAR(10),@IDEmpresa) +')'
		IF (@IDStatus IS NOT NULL)
			SET @StrSQL += ' AND (Comp.IDStatus =  ' + CONVERT(VARCHAR(10),@IDStatus) + ')'
		IF (@Operacao IS NOT NULL)
			SET @StrSQL += ' AND (OperacaoFiltro = '''  + @Operacao + ''')'
		IF (@IDTerminal IS NOT NULL)
			SET @StrSQL += ' AND (Terminal.ID =  ' + CONVERT(VARCHAR(10),@IDTerminal) + ')'
		IF (@IDTipoComposicao IS NOT NULL)
			SET @StrSQL += ' AND (IDTipoComposicao =  ' + CONVERT(VARCHAR(10),@IDTipoComposicao) +')'
		IF (@DtInicio IS NOT NULL)
			SET @StrSQL += ' AND (Data >= ''' + CONVERT(VARCHAR(19),@DtInicio) +''')'
		IF (@DtFim IS NOT NULL)
			SET @StrSQL += ' AND (Data  <= ''' + CONVERT(VARCHAR(19),@DtFim) +''')'
		IF (@Placa IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND (Placa1 =  ''' + @Placa +''''
			SET @StrSQL += '	OR Placa2 = ''' + @Placa +''''
			SET @StrSQL += '	OR Placa3 = ''' + @Placa +''''
			SET @StrSQL += '	OR Placa4 = ''' + @Placa +''')'
		END
		IF (@IDTransportadora IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND  (IDTransportadora1 =  ' + CONVERT(VARCHAR(10),@IDTransportadora)
			SET @StrSQL += '    OR IDTransportadora2 = ' + CONVERT(VARCHAR(10),@IDTransportadora)
			SET @StrSQL += '	OR IDTransportadora3 = ' + CONVERT(VARCHAR(10),@IDTransportadora)
			SET @StrSQL += '	OR IDTransportadora4 = ' + CONVERT(VARCHAR(10),@IDTransportadora) +')'
		END
		IF(@IDUsuarioTransportadora IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND  (IDUsuario1 =   '+ CONVERT(VARCHAR(10),@IDUsuarioTransportadora) 
			SET @StrSQL += '	OR IDUsuario2 = ' + CONVERT(VARCHAR(10),@IDUsuarioTransportadora)
			SET @StrSQL += '	OR IDUsuario3 = ' + CONVERT(VARCHAR(10),@IDUsuarioTransportadora)
			SET @StrSQL += '	OR IDUsuario4 = ' + CONVERT(VARCHAR(10),@IDUsuarioTransportadora) +')' 
		END
		IF(@IDUsuarioTransportadora IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND ((Comp.IDEmpresa = 3 '
			SET @StrSQL += '	AND    IDUsuario5 = ' +	CONVERT(VARCHAR(10),@IDUsuarioTransportadora)
			SET @StrSQL += '		OR IDUsuario6 = ' +	CONVERT(VARCHAR(10),@IDUsuarioTransportadora)
			SET @StrSQL += '		OR IDUsuario7 = ' +	CONVERT(VARCHAR(10),@IDUsuarioTransportadora)
			SET @StrSQL += '		OR IDUsuario8 = ' +	CONVERT(VARCHAR(10),@IDUsuarioTransportadora) +')'
			SET @StrSQL += '	OR Comp.IDEmpresa <> 3)'						
		END
		IF (@IDCliente IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND  (IDCliente1 = ' + CONVERT(VARCHAR(10),@IDCliente)
			SET @StrSQL += '	OR IDCliente2 =' + CONVERT(VARCHAR(10),@IDCliente)
			SET @StrSQL += '	OR IDCliente3 =' + CONVERT(VARCHAR(10),@IDCliente)
			SET @StrSQL += '	OR IDCliente4 =' + CONVERT(VARCHAR(10),@IDCliente) +')'			
		END
		IF (@IDUsuarioCliente IS NOT NULL)
		BEGIN
			SET @StrSQL += ' AND  (IDUsuarioCliente1 ='   + CONVERT(VARCHAR(10),@IDUsuarioCliente)
			SET @StrSQL += ' 	OR IDUsuarioCliente2 =' + CONVERT(VARCHAR(10),@IDUsuarioCliente)
			SET @StrSQL += ' 	OR IDUsuarioCliente3 =' + CONVERT(VARCHAR(10),@IDUsuarioCliente)
			SET @StrSQL += ' 	OR IDUsuarioCliente4 =' + CONVERT(VARCHAR(10),@IDUsuarioCliente) +')'
		END
		SET @StrSQL += ' 
			GROUP BY	
				Data,
				convert(varchar(5), HoraInicio),
				HoraInicio,
				Horario,
				TipoComposicao,
				ID, 
				Empresa,
				Operacao, 				
				IDStatus,
				Placa1,
				Placa2,
				Placa3,
				Placa4,
				Terminal 
	)  AS Composicao '
	IF (@PrimeiraPagina IS NOT NULL)
		SET @StrSQL += 'WHERE Composicao.RowNum > ' + CONVERT(VARCHAR(5),@PrimeiraPagina) 
	IF (@UltimaPagina IS NOT NULL)
		SET @StrSQL += 'AND Composicao.RowNum <= '  + CONVERT(VARCHAR(5),@UltimaPagina)
	EXEC (@StrSQL)
	print @StrSQL
END
