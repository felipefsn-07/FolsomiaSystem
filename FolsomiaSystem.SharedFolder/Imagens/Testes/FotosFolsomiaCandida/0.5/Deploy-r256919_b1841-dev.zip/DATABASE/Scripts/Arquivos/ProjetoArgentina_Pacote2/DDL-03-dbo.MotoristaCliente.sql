﻿USE UniCad
GO

-- [CSON-2851 - Inicio]

IF COL_LENGTH('dbo.MotoristaCliente', 'DataAprovacao') IS NULL 
BEGIN
	ALTER TABLE dbo.MotoristaCliente ADD DataAprovacao DATETIME NULL	
END

-- [CSON-2851 - Fim]