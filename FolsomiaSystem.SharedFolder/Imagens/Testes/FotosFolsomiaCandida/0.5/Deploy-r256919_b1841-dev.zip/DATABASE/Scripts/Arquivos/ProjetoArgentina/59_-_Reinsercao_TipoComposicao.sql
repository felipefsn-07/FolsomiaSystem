USE [UniCad]

GO

IF EXISTS(SELECT 1 FROM SYSCOLUMNS WHERE [ID] = OBJECT_ID('[dbo].[TipoComposicao]') AND UPPER([NAME]) = 'IDPAIS') 
BEGIN

	IF ((SELECT COUNT(*) FROM [dbo].[TipoComposicao] WHERE [ID] = 5) = 1)
		UPDATE [dbo].[TipoComposicao] SET [Nome] = 'Semirremolque Chico (M�nimo 20 m� /M�ximo 29 m�)', [IdPais] = 2, [NumeroPlacas] = 2 WHERE [ID] = 5;

	IF ((SELECT COUNT(*) FROM [dbo].[TipoComposicao] WHERE [ID] = 6) = 1)
		UPDATE [dbo].[TipoComposicao] SET [Nome] = 'Semirremolque Grande (M�nimo 30 m� /M�ximo 39 m�)', [IdPais] = 2, [NumeroPlacas] = 2 WHERE [ID] = 6;

	IF ((SELECT COUNT(*) FROM [dbo].[TipoComposicao] WHERE [ID] = 7) = 1)
		UPDATE [dbo].[TipoComposicao] SET [Nome] = 'Escalado (M�nimo 40 m� /M�ximo 49 m�)', [IdPais] = 2, [NumeroPlacas] = 2  WHERE [ID] = 7;

	IF ((SELECT COUNT(*) FROM [dbo].[TipoComposicao] WHERE [ID] = 8) = 1)
		UPDATE [dbo].[TipoComposicao] SET [Nome] = 'Bitren Chico  (M�nimo 45 m� /M�ximo 55 m�)', [IdPais] = 2, [NumeroPlacas] = 3 WHERE [ID] = 8;

	IF ((SELECT COUNT(*) FROM [dbo].[TipoComposicao] WHERE [ID] = 9) = 1)
		UPDATE [dbo].[TipoComposicao] SET [Nome] = 'Bitren Grande  (M�nimo 60 m� /M�ximo 70 m�)', [IdPais] = 2, [NumeroPlacas] = 3 WHERE [ID] = 9;
	
	
	IF ((SELECT COUNT(*) FROM [dbo].[TipoComposicao] WHERE [ID] = 5) = 0)
		INSERT INTO [dbo].[TipoComposicao] ([ID], [Nome], [IdPais], [NumeroPlacas]) VALUES (5, 'Semirremolque Chico (M�nimo 20 m� /M�ximo 29 m�)', 2, 2);

	IF ((SELECT COUNT(*) FROM [dbo].[TipoComposicao] WHERE [ID] = 6) = 0)
		INSERT INTO [dbo].[TipoComposicao] ([ID], [Nome], [IdPais], [NumeroPlacas]) VALUES (6, 'Semirremolque Grande (M�nimo 30 m� /M�ximo 39 m�)', 2, 2);

	IF ((SELECT COUNT(*) FROM [dbo].[TipoComposicao] WHERE [ID] = 7) = 0)
		INSERT INTO [dbo].[TipoComposicao] ([ID], [Nome], [IdPais], [NumeroPlacas]) VALUES (7, 'Escalado (M�nimo 40 m� /M�ximo 49 m�)', 2, 2);

	IF ((SELECT COUNT(*) FROM [dbo].[TipoComposicao] WHERE [ID] = 8) = 0)
		INSERT INTO [dbo].[TipoComposicao] ([ID], [Nome], [IdPais], [NumeroPlacas]) VALUES (8, 'Bitren Chico  (M�nimo 45 m� /M�ximo 55 m�)', 2, 3);

	IF ((SELECT COUNT(*) FROM [dbo].[TipoComposicao] WHERE [ID] = 9) = 0)
		INSERT INTO [dbo].[TipoComposicao] ([ID], [Nome], [IdPais], [NumeroPlacas]) VALUES (9, 'Bitren Grande  (M�nimo 60 m� /M�ximo 70 m�)', 2, 3);

END

GO
