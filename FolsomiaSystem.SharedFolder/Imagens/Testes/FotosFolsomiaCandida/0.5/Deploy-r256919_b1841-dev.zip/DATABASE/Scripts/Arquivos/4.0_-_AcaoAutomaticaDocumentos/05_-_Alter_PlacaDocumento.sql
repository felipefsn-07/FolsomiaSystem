USE UniCad
GO

IF NOT EXISTS (
		SELECT 1
		FROM SYS.COLUMNS
		WHERE NAME = 'TipoAcaoVencimento'
			AND OBJECT_ID = OBJECT_ID('PlacaDocumento')
		)
BEGIN

	BEGIN TRANSACTION

	ALTER TABLE dbo.PlacaDocumento ADD
			TipoAcaoVencimento int NULL

	COMMIT

END

IF NOT EXISTS (
		SELECT 1
		FROM SYS.COLUMNS
		WHERE NAME = 'UsuarioAlterouStatus'
			AND OBJECT_ID = OBJECT_ID('PlacaDocumento')
		)
BEGIN

	BEGIN TRANSACTION

	ALTER TABLE dbo.PlacaDocumento ADD
			UsuarioAlterouStatus varchar(50) NULL

	COMMIT

END