USE [UniCad]
GO

IF EXISTS(SELECT 1 FROM sys.columns WHERE  [object_id] = OBJECT_ID('[dbo].[MotoristaArgentina]') AND NAME = 'CUITTransportista')
ALTER TABLE [dbo].[MotoristaArgentina]
	ALTER COLUMN CUITTransportista VARCHAR(11) NOT NULL