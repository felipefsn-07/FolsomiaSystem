﻿USE UniCad
GO

-- [CSON-2698 - Inicio]

IF COL_LENGTH('dbo.PlacaDocumento', 'Processado') IS NOT NULL
	AND NOT EXISTS (SELECT * FROM dbo.PlacaDocumento WHERE Processado <> 0)
BEGIN
	UPDATE PD
	SET Processado = 1
	FROM dbo.PlacaDocumento AS PD
	JOIN dbo.TipoDocumento AS TD ON PD.IDTipoDocumento = TD.ID
	WHERE 
		PD.Processado = 0
		AND	((PD.Vencido = 1 AND PD.Bloqueado = 1) 
			OR (PD.Vencido = 1 AND TD.TipoAcaoVencimento = 0))
END

-- [CSON-2698 - Fim]
