USE UniCad

DECLARE 
	@cCorpoEmail VARCHAR(1000),
	@idBrasil INT = (SELECT ID FROM Pais WHERE Nome = 'Brasil'),
	@idArgentina INT = (SELECT ID FROM Pais WHERE Nome = 'Argentina')

IF NOT EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'TituloAlertaDocumentoComposicao' AND IdPais = @idBrasil)
BEGIN
	INSERT INTO Configuracao VALUES (
		'TituloAlertaDocumentoComposicao', 
		'T�tulo do e-mail de alerta documento composi��o',
		'Ra�zen - Alerta de Documento vencido',
		GETDATE(),
		GETDATE(),
		NULL,
		@idBrasil);
END

IF NOT EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'TituloAlertaDocumentoComposicao' AND IdPais = @idArgentina)
BEGIN
	INSERT INTO Configuracao VALUES (
		'TituloAlertaDocumentoComposicao', 
		'T�tulo do e-mail de alerta documento composi��o',
		'Ra�zen - Alerta de Documento vencido',
		GETDATE(),
		GETDATE(),
		NULL,
		@idArgentina);
END

IF NOT EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoAlertaDocumentoComposicao' AND IdPais = @idBrasil)
BEGIN

	SET @cCorpoEmail = 'Ol�, informamos que o(s) ve�culo(s) abaixo possui(em) documento(s) vencido(s).
						<br/><br/>
						{0}
						<br/><br/>
						Caso n�o seja regularizado, o ve�culo ser� bloqueado ou reprovado, o que ir� impossibilitar o carregamento em nossos terminais a partir dessa data.
						<br/><br/>
						Para regulariza��o da documenta��o, por gentileza, acessar o sistema Csonline e no menu "Chamados" - "Cadastro de Ve�culos" realizar o envio dos documentos para atualiza��o. 
						<br/><br/>
						Caso tenha alguma d�vida, por gentileza, entrar em contato com a Ra�zen.';

	INSERT INTO Configuracao VALUES (
		'CorpoAlertaDocumentoComposicao', 
		'Corpo do e-mail de alerta documento composi��o',
		@cCorpoEmail,
		GETDATE(),
		GETDATE(),
		NULL,
		@idBrasil);
END

IF NOT EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoAlertaDocumentoComposicao' AND IdPais = @idArgentina)
BEGIN
	SET @cCorpoEmail = 'Ol�, informamos que o(s) ve�culo(s) abaixo possui(em) documento(s) vencido(s).
						<br/><br/>
						{0}
						<br/><br/>
						Caso n�o seja regularizado, o ve�culo ser� bloqueado ou reprovado, o que ir� impossibilitar o carregamento em nossos terminais a partir dessa data.
						<br/><br/>
						Para regulariza��o da documenta��o, por gentileza, acessar o sistema Csonline e no menu "Chamados" - "Cadastro de Ve�culos" realizar o envio dos documentos para atualiza��o. 
						<br/><br/>
						Caso tenha alguma d�vida, por gentileza, entrar em contato com a Ra�zen.';

	INSERT INTO Configuracao VALUES (
		'CorpoAlertaDocumentoComposicao', 
		'Corpo do e-mail de alerta documento composi��o',
		@cCorpoEmail,
		GETDATE(),
		GETDATE(),
		NULL,
		@idArgentina);
END

-- [CSON-2843 - Inicio]

-- TituloAlertaDocumentoMotorista

IF NOT EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'TituloAlertaDocumentoMotorista' AND IdPais = @idBrasil)
BEGIN
	INSERT INTO Configuracao VALUES (
		'TituloAlertaDocumentoMotorista', 
		'T�tulo do e-mail de alerta documento vencido motorista',
		'Ra�zen - Alerta de Documento vencido',
		GETDATE(),
		GETDATE(),
		NULL,
		@idBrasil);
END

IF NOT EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'TituloAlertaDocumentoMotorista' AND IdPais = @idArgentina)
BEGIN
	INSERT INTO Configuracao VALUES (
		'TituloAlertaDocumentoMotorista', 
		'T�tulo do e-mail de alerta documento vencido motorista',
		'Ra�zen - Alerta de Documento vencido',
		GETDATE(),
		GETDATE(),
		NULL,
		@idArgentina);
END

-- CorpoAlertaDocumentoMotorista

IF NOT EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoAlertaDocumentoMotorista' AND IdPais = @idBrasil)
BEGIN

	SET @cCorpoEmail = 'Ol�, informamos que o(s) motorista(s) abaixo possui(em) documento(s) vencido(s).<br/><br/>
						{0}
						Caso n�o seja regularizado, o motorista ser� bloqueado ou reprovado, o que ir� impossibilitar o carregamento em nossos terminais a partir dessa data.
						<br/><br/>
						Para regulariza��o da documenta��o, por gentileza, acessar o sistema Csonline e no menu "Chamados" - "Cadastro de Motoristas" realizar o envio dos documentos para atualiza��o.
						<br/><br/>
						Caso tenha alguma d�vida, por gentileza, entrar em contato com a Ra�zen.';

	INSERT INTO Configuracao VALUES (
		'CorpoAlertaDocumentoMotorista', 
		'Corpo do e-mail de alerta documento vencido motorista',
		@cCorpoEmail,
		GETDATE(),
		GETDATE(),
		NULL,
		@idBrasil);
END

IF NOT EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoAlertaDocumentoMotorista' AND IdPais = @idArgentina)
BEGIN
	SET @cCorpoEmail = 'Ol�, informamos que o(s) motorista(s) abaixo possui(em) documento(s) vencido(s).<br/><br/>
						{0}
						Caso n�o seja regularizado, o motorista ser� bloqueado ou reprovado, o que ir� impossibilitar o carregamento em nossos terminais a partir dessa data.
						<br/><br/>
						Para regulariza��o da documenta��o, por gentileza, acessar o sistema Csonline e no menu "Chamados" - "Cadastro de Motoristas" realizar o envio dos documentos para atualiza��o.
						<br/><br/>
						Caso tenha alguma d�vida, por gentileza, entrar em contato com a Ra�zen.';

	INSERT INTO Configuracao VALUES (
		'CorpoAlertaDocumentoMotorista', 
		'Corpo do e-mail de alerta documento vencido motorista',
		@cCorpoEmail,
		GETDATE(),
		GETDATE(),
		NULL,
		@idArgentina);
END

-- [CSON-2843 - Fim]

-- [CSON-3381] - INICIO

-- CorpoPlacaAlertaDocumentoComposicao

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoPlacaAlertaDocumentoComposicao' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoPlacaAlertaDocumentoComposicao' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoPlacaAlertaDocumentoComposicao' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoPlacaAlertaDocumentoComposicao' AND IdPais = @idArgentina

-- CorpoDocumentoAlertaDocumentoComposicao

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoDocumentoAlertaDocumentoComposicao' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoDocumentoAlertaDocumentoComposicao' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoDocumentoAlertaDocumentoComposicao' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoDocumentoAlertaDocumentoComposicao' AND IdPais = @idArgentina

-- CorpoDiasAcaoAlertaDocumentoComposicao

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoDiasAcaoAlertaDocumentoComposicao' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoDiasAcaoAlertaDocumentoComposicao' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoDiasAcaoAlertaDocumentoComposicao' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoDiasAcaoAlertaDocumentoComposicao' AND IdPais = @idArgentina

-- CorpoNomeDocumentoMotoristaAlertaVencimento

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoNomeDocumentoMotoristaAlertaVencimento' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoNomeDocumentoMotoristaAlertaVencimento' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoNomeDocumentoMotoristaAlertaVencimento' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoNomeDocumentoMotoristaAlertaVencimento' AND IdPais = @idArgentina

-- CorpoDiasVencimentoMotoristaAlertaVencimento

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoDiasVencimentoMotoristaAlertaVencimento' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoDiasVencimentoMotoristaAlertaVencimento' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoDiasVencimentoMotoristaAlertaVencimento' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoDiasVencimentoMotoristaAlertaVencimento' AND IdPais = @idArgentina

-- CorpoMotoristaAlertaDocumentoMotorista

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoMotoristaAlertaDocumentoMotorista' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoMotoristaAlertaDocumentoMotorista' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoMotoristaAlertaDocumentoMotorista' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoMotoristaAlertaDocumentoMotorista' AND IdPais = @idArgentina

-- CorpoDocumentoAlertaDocumentoMotorista

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoDocumentoAlertaDocumentoMotorista' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoDocumentoAlertaDocumentoMotorista' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoDocumentoAlertaDocumentoMotorista' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoDocumentoAlertaDocumentoMotorista' AND IdPais = @idArgentina

-- CorpoDiasAcaoAlertaDocumentoMotorista

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoDiasAcaoAlertaDocumentoMotorista' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoDiasAcaoAlertaDocumentoMotorista' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoDiasAcaoAlertaDocumentoMotorista' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoDiasAcaoAlertaDocumentoMotorista' AND IdPais = @idArgentina

-- CorpoNomeEmailReprovaAutomaticaMotorista

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoNomeEmailReprovaAutomaticaMotorista' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoNomeEmailReprovaAutomaticaMotorista' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoNomeEmailReprovaAutomaticaMotorista' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoNomeEmailReprovaAutomaticaMotorista' AND IdPais = @idArgentina

-- CorpoVencidoEmailReprovaAutomaticaMotorista

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoVencidoEmailReprovaAutomaticaMotorista' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoVencidoEmailReprovaAutomaticaMotorista' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoVencidoEmailReprovaAutomaticaMotorista' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoVencidoEmailReprovaAutomaticaMotorista' AND IdPais = @idArgentina

-- CorpoNomeEmailBloqueioAutomaticoMotorista

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoNomeEmailBloqueioAutomaticoMotorista' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoNomeEmailBloqueioAutomaticoMotorista' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoNomeEmailBloqueioAutomaticoMotorista' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoNomeEmailBloqueioAutomaticoMotorista' AND IdPais = @idArgentina

-- CorpoVencidoEmailBloqueioAutomaticoMotorista

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoVencidoEmailBloqueioAutomaticoMotorista' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoVencidoEmailBloqueioAutomaticoMotorista' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoVencidoEmailBloqueioAutomaticoMotorista' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoVencidoEmailBloqueioAutomaticoMotorista' AND IdPais = @idArgentina

-- CorpoVeiculoEmailBloqueioAutomaticoComposicao

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoVeiculoEmailBloqueioAutomaticoComposicao' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoVeiculoEmailBloqueioAutomaticoComposicao' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoVeiculoEmailBloqueioAutomaticoComposicao' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoVeiculoEmailBloqueioAutomaticoComposicao' AND IdPais = @idArgentina

-- CorpoVeiculoEmailReprovaAutomaticaComposicao

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoVeiculoEmailReprovaAutomaticaComposicao' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoVeiculoEmailReprovaAutomaticaComposicao' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoVeiculoEmailReprovaAutomaticaComposicao' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoVeiculoEmailReprovaAutomaticaComposicao' AND IdPais = @idArgentina

-- VeiculoSingularEmailReprovaBloqueioAutomatico

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'VeiculoSingularEmailReprovaBloqueioAutomatico' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'VeiculoSingularEmailReprovaBloqueioAutomatico' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'VeiculoSingularEmailReprovaBloqueioAutomatico' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'VeiculoSingularEmailReprovaBloqueioAutomatico' AND IdPais = @idArgentina

-- VeiculoPluralEmailReprovaBloqueioAutomatico

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'VeiculoPluralEmailReprovaBloqueioAutomatico' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'VeiculoPluralEmailReprovaBloqueioAutomatico' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'VeiculoPluralEmailReprovaBloqueioAutomatico' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'VeiculoPluralEmailReprovaBloqueioAutomatico' AND IdPais = @idArgentina

-- MotoristaSingularEmailReprovaBloqueioAutomatico

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'MotoristaSingularEmailReprovaBloqueioAutomatico' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'MotoristaSingularEmailReprovaBloqueioAutomatico' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'MotoristaSingularEmailReprovaBloqueioAutomatico' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'MotoristaSingularEmailReprovaBloqueioAutomatico' AND IdPais = @idArgentina

-- MotoristaPluralEmailReprovaBloqueioAutomatico

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'MotoristaPluralEmailReprovaBloqueioAutomatico' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'MotoristaPluralEmailReprovaBloqueioAutomatico' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'MotoristaPluralEmailReprovaBloqueioAutomatico' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'MotoristaPluralEmailReprovaBloqueioAutomatico' AND IdPais = @idArgentina

-- CorpoPlacaDiasVencimentoVeiculoAlertaVencimento

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoPlacaDiasVencimentoVeiculoAlertaVencimento' AND IdPais = @idBrasil)
DELETE Configuracao WHERE NmVariavel = 'CorpoPlacaDiasVencimentoVeiculoAlertaVencimento' AND IdPais = @idBrasil

IF EXISTS (SELECT TOP 1 ID FROM Configuracao WHERE NmVariavel = 'CorpoPlacaDiasVencimentoVeiculoAlertaVencimento' AND IdPais = @idArgentina)
DELETE Configuracao WHERE NmVariavel = 'CorpoPlacaDiasVencimentoVeiculoAlertaVencimento' AND IdPais = @idArgentina


-- [CSON-3381] - FIM

GO